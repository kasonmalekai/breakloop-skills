#!/usr/bin/env python3
"""The self-check. Runs on every draft before the coach sees it.

Usage:
    python3 scripts/check.py drafts.md --source source.txt [--voice voice.txt] [--buyer buyer.txt]
                             [--cta "DM me the word X"] [--json]

drafts.md   what you're about to show. Spoken lines start with "> " (reel scripts).
source.txt  the material the drafts were made from (the transcript, the posts they pasted).
voice.txt   optional: lines the person actually said or wrote, one per line, to compare voice.
buyer.txt   optional: the buyer's own lines from the call, so no post copies them.

It checks five things and prints PASS or FAIL with the line of every problem:
  1. em dashes and en dashes, anywhere (they read as AI and nobody says them)
  2. stock AI phrases ("delve", "game-changer", "in today's fast-paced world"...)
  3. numbers that aren't in the source material (an invented number is the fastest way
     to lose a buyer's trust). Write [YOUR NUMBER] instead of guessing.
  4. headline fragments in spoken lines ("Three steps." is something you print, not say)
  5. voice drift: sentence length and contractions compared with how they really talk
  6. the week as a whole (posts start with a "## " heading):
     - the "it isn't X, it's Y" frame more than once in the week
     - template lines ("nobody checks the...", "here's the thing", "the truth is")
     - claims about "a lot of coaches" or "most people" the material never makes
     - a reel whose second sentence starts the lesson (an example, "let's say", a number)
     - words copied from the buyer's lines into a post (pass --buyer buyer.txt)
     - two posts sharing the same line
  7. with --ads: a primary text that leads with a question or a name, anything personal said
     about the viewer (money, health, identity), a promised income, and a price

It can't tell a good post from a bad one. It catches the mechanical tells, so the
judgment goes into what's left. Standard library only.
"""
import argparse
import json
import os
import re
import sys

DASHES = re.compile("[" + chr(0x2014) + chr(0x2013) + r"]|(?<=\w) -- (?=\w)")

# Phrases that mark text as machine-written. Kept short on purpose: every entry here
# has to be something a real coach would almost never say on camera.
AI_PHRASES = [
    "delve", "game-changer", "game changer", "in today's fast-paced", "in today's world",
    "in the ever-evolving", "ever-changing landscape", "unlock your", "unlock the power",
    "unleash", "supercharge", "revolutionize", "elevate your", "take it to the next level",
    "embark on", "journey of", "navigate the", "a testament to", "tapestry", "it's worth noting",
    "it is worth noting", "let's dive in", "let's dive into", "dive deep", "deep dive",
    "buckle up", "here's the kicker", "the secret sauce", "harness the", "leverage your",
    "seamless", "seamlessly", "robust", "cutting-edge", "pivotal", "crucial", "foster",
    "in conclusion", "moreover", "furthermore", "additionally", "not only", "whether you're a",
    "look no further", "say goodbye to", "imagine a world", "picture this", "fast-paced",
    "realm", "synergy", "holistic", "empower", "thrive in", "at the end of the day, it's",
]

VERBS = set("""
am is are was were be been being do does did done have has had having go goes went gone
going get gets got getting make makes made making say says said take takes took taken want
wants wanted know knows knew see sees saw seen come comes came think thinks thought give
gives gave find finds found tell tells told feel feels felt let lets leave leaves left buy
buys bought sell sells sold lose loses lost stop stops stopped keep keeps kept pay pays paid
can could will would should may might must need needs needed works work worked book booked
books show shows showed close closes closed run runs ran start starts started try tries tried
use uses used build builds built call calls called post posts posted ask asks asked
""".split())
SUBJECTS = {"i", "you", "he", "she", "it", "we", "they", "that", "this", "there", "here",
            "who", "what", "nobody", "everybody", "everyone", "people"}
IMPERATIVES = {"look", "watch", "listen", "stop", "start", "keep", "let", "go", "take", "put",
               "check", "think", "tell", "ask", "try", "picture", "write", "save", "send",
               "follow", "comment", "read", "see", "hit", "grab", "use", "make", "pick",
               "drop", "remember", "imagine", "notice", "count", "open", "film", "post",
               "dm", "message", "text", "call", "book", "join", "register", "reply", "click",
               "tap", "swipe", "share", "subscribe", "come", "give", "bring"}
CONTRACTION = re.compile(r"\b\w+['’](s|re|m|ve|ll|d|t)\b", re.I)

# Numbers that are structure, not claims: "Reel 2", "Day 3", "slide 4", "0:45", "3 options".
STRUCTURAL = re.compile(
    r"(?i)\b(reel|post|slide|day|step|option|hook|beat|clip|week|part|carousel|caption|"
    r"version|v|#|no\.)\s*\d+\b|\b\d{1,2}:\d{2}(:\d{2})?\b|\b\d+\s*(s|sec|secs|seconds)\b")
# a unit letter only counts when it ends the token: "$131K" is a number, "5 minutes" is just 5
NUMBER = re.compile(r"\$?\d[\d,]*(\.\d+)?(%|[kKmM](?![A-Za-z])|x(?![A-Za-z]))?")

# The week as a whole. These catch what a line-by-line check can't: the same move made
# over and over until the whole week reads like a template.
CONTRAST = [re.compile(p, re.I) for p in (
    r"\b(isn'?t|is not|wasn'?t|was not|was never|is never|never was|aren'?t)\s+(really\s+|actually\s+)?"
    r"(the|your|a|an)\s+(real\s+)?(\w+\s+){0,2}problem\b",
    r"\byou don'?t have an?\s+(\w+\s+){1,3}problem\b",
    r"\bthe problem (isn'?t|is not|was never)\b",
    r"\bit'?s not\s+[^.!?]{1,60}?[,.]\s*it'?s\b",
    r"\bisn'?t (about|the issue)\b",
    r"\byou don'?t need\s+[^.!?]{1,60}?[.,;]\s*(you need|what you need|you just need)\b",
    r"\byou'?re not\s+[^.!?]{1,60}?[.,;]\s*you'?re\b",
    r"\b(it|this|that)\s+(doesn'?t|isn'?t|wasn'?t)\b[^.!?]{0,50}?[,;]\s*(it|this|that|the)\s",
    r"\bnot\s+\w+(\s+\w+){0,4},\s*but\b",
    r"\bthe (fix|answer|problem|issue) (isn'?t|is not)\b",
    r"\b\w+(\s\w+)?,\s+not\s+\w+(\s\w+)?[.!?]",
)]
FRAME_LIMIT = 2  # the move is strong twice a week; after that the week reads like a template
TEMPLATE_SHAPES = [re.compile(r"\bsame \w+, same \w+", re.I), re.compile(r"\bbefore you (even )?say hello\b", re.I)]
TEMPLATES = ["nobody checks the", "nobody names the", "the part nobody", "that's the whole difference",
             "and that's the difference", "here's the thing", "here's the truth", "the truth is",
             "that's the secret", "nobody talks about", "no one talks about", "most people don't realize",
             "what nobody tells you", "and that changes everything", "let that sink in",
             "every week you wait", "here's what happens next", "and that's fine"]
GENERAL = re.compile(r"\b(a lot of|lots of|most|so many|every|all)\s+(coaches|people|founders|creators|"
                     r"business owners|my clients|of you|clients|buyers)\s+(tell me|say|said|think|ask|"
                     r"struggle|do|make|believe|want)\b", re.I)
LESSON_START = re.compile(r"\b(let'?s say|for example|for instance|imagine|say you|picture|because|"
                          r"that'?s why|here'?s how|here'?s why|the reason)\b|\d", re.I)
STOP = set("""a an the and or but so to of in on at for with is are was were be been it that this
you your i my me we our they them their he she his her its as if then than just do does did not no
yes have has had am can will would what how when there here up out about like get got""".split())
TIME_CLAIM = re.compile(r"\b(last week|yesterday|this morning|last month|the other day|last night|"
                        r"earlier today|this week|a few days ago)\b", re.I)
ANECDOTE = re.compile(r"\b(someone|somebody|a (client|prospect|coach|guy|woman|lady|buyer))\s+"
                      r"(told me|said to me|asked me|messaged me|on a call)\b", re.I)
NUMBER_WORDS = {"half", "double", "twice", "triple", "quarter", "third", "dozen", "hundred", "thousand",
                "grand", "million", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty",
                "ninety"}
EXAMPLE = re.compile(r"\b(let'?s say|say you|say a|say there|imagine|for example|for instance|suppose|like,)\s", re.I)
MEMORY = re.compile(r"\bI (thought|felt|believed|used to (think|believe)|realized|realised|counted|assumed|figured|"
                    r"was sure|was convinced|told myself|remember)\b|\buntil I (looked|saw|checked|realized|realised|noticed)\b", re.I)
HEDGE = re.compile(r"\b(probably|maybe|might|kind of|sort of|perhaps|possibly|somewhere|some of them)\b", re.I)
IS_SPOKEN = re.compile(r"\b(reel|ad|video|clip)\b", re.I)  # sections whose lines are said out loud
PIVOT = re.compile(r"^(so,?\s+)?(here'?s|look|let me show you|let'?s look|now,? here'?s)\b", re.I)
OPENER_SKIP = {"face to", "cut to", "screen recording", "close up", "b roll", "wide shot", "same shot", "dm me", "slide 1", "slide 2", "slide 3", "slide 4", "slide 5", "slide 6", "slide 7", "slide 8",
               "slide 9", "slide 10", "on screen", "hook a", "hook b", "hook c", "caption:", "hook:"}
BUYER_SECTION = re.compile(r"(what your (buyer|audience|video|call)|told you|is asking|why it worked|the breakdown|how their funnel works|their ads|what.s working|take the model|never take|front door|proven opening)", re.I)
CLIP_SECTION = re.compile(r"clip map|the clips", re.I)
META = re.compile(r"^(answers|source|why|from|notes?|shape|length|show|film|on screen)\s*:", re.I)
WORKING_NOTE = re.compile(r"^(answers|source|notes?|shape)\s*:", re.I)  # notes the coach never needs
SLIDE_PREFIX = re.compile(r"^(slide|day)\s*\d+\s*[:.]\s*", re.I)


def split_posts(lines):
    posts, cur = [], None
    for i, raw in enumerate(lines, 1):
        if raw.startswith("## "):
            cur = {"title": raw[3:].strip(), "lines": [], "skip": bool(BUYER_SECTION.search(raw)),
                   "clips": bool(CLIP_SECTION.search(raw))}
            posts.append(cur)
        elif cur is not None:
            cur["lines"].append((i, raw.strip()))
    return [p for p in posts if not p["skip"]]


def stem(w):
    return w[:-1] if len(w) > 4 and w.endswith("s") and not w.endswith("ss") else w


def grams(text, n, min_content):
    w = [stem(x) for x in re.findall(r"[a-z0-9']+", text.lower())]
    out = set()
    for k in range(len(w) - n + 1):
        g = w[k:k + n]
        if sum(1 for x in g if x not in STOP) >= min_content:
            out.add(" ".join(g))
    return out


def week_checks(lines, source, buyer_lines, cta="", avoid=(), max_seconds=None, frame_limit=2, fixed=(), cost_numbers=False,
                opener_limit=4, plan_mode=False):
    fails = []
    fixed = [f.lower() for f in ([cta] + list(fixed)) if f]  # lines meant to be the same everywhere
    posts = split_posts(lines)
    src = source.lower()
    contrast_hits = []
    for p in posts:
        spoken_sents = []
        for i, line in p["lines"]:
            if not line:
                continue
            low = line.lower()
            for rx in CONTRAST:
                if rx.search(line):
                    contrast_hits.append((i, line))
                    break
            for tpl in TEMPLATES:
                if tpl in low:
                    fails.append((i, "template", f'template line "{tpl}": say the specific thing instead', line))
            for rx in TEMPLATE_SHAPES:
                m = rx.search(line)
                if m:
                    fails.append((i, "template", f'template shape "{m.group(0)}": say the specific thing instead', line))
            for word in avoid:
                if re.search(r"(?<![a-z])" + re.escape(word) + r"s?(?![a-z])", low):
                    fails.append((i, "borrowed", f'"{word}" is the original\'s picture: use one from their own world', line))
            for m in ([] if plan_mode else TIME_CLAIM.finditer(line)):
                if m.group(0).lower() not in src:
                    fails.append((i, "claim", f'"{m.group(0)}" says when something happened, and the material '
                                  "doesn't say that", line))
            for m in MEMORY.finditer(line):
                if m.group(0).lower() not in src:
                    fails.append((i, "claim", f'"{m.group(0)}" gives the coach a memory or belief the material never '
                                  "mentions: say only what they said they did or thought", line))
            if ANECDOTE.search(line) and not ANECDOTE.search(source):
                fails.append((i, "anecdote", "this retells the call as a story about one person; "
                              "generalise it instead, so the buyer can't recognise herself", line))
            for w in set(re.findall(r"[a-z]+", low)) & NUMBER_WORDS - {"half", "double", "twice", "third", "quarter"}:
                if not re.search(r"(?<![a-z])" + w + r"(?![a-z])", src):
                    fails.append((i, "number", f'"{w}" is a number the material never gives; use [YOUR NUMBER]', line))
            for m in GENERAL.finditer(line):
                if (m.group(1) + " " + m.group(2)).lower() not in src:
                    fails.append((i, "claim", f'"{m.group(0)}" is a claim the material never makes', line))
            if line.startswith(">"):
                spoken_sents += [(i, s) for s in sentences(line.lstrip("> ").strip())]
        if max_seconds and IS_SPOKEN.search(p["title"]) and spoken_sents:
            words = sum(len(s.split()) for _, s in spoken_sents)
            secs = words / 2.5  # about 150 spoken words a minute
            if secs > max_seconds:
                fails.append((spoken_sents[0][0], "length", f"about {round(secs)} seconds spoken, over the "
                              f"{round(max_seconds)} allowed: cut it to match the original's length", ""))
        if IS_SPOKEN.search(p["title"]) and spoken_sents and HEDGE.search(spoken_sents[0][1]):
            fails.append((spoken_sents[0][0], "hook", "the hook hedges (\"probably\", \"maybe\", \"might\"): "
                          "a hook makes a claim", spoken_sents[0][1]))
        if IS_SPOKEN.search(p["title"]) and len(spoken_sents) >= 2:
            i2, s2 = spoken_sents[1]
            if cost_numbers and numbers_in(s2) and numbers_in(s2) <= numbers_in(source):
                s2 = NUMBER.sub(" ", s2)  # in an ad, a real cost from the material may carry the lock-in
            if LESSON_START.search(s2):
                fails.append((i2, "lock-in", "sentence two starts the lesson (an example, a number or the "
                              "reason why); make it say what this is costing them right now", s2))
        if IS_SPOKEN.search(p["title"]) and len(spoken_sents) >= 3:
            i3, s3 = spoken_sents[2]
            if PIVOT.match(s3.strip()):
                fails.append((i3, "lock-in", "sentence three pivots into the lesson (\"so here's...\"); "
                              "keep it on a concrete cost from the material", s3))
    openers = {}
    for p in posts:
        for i, line in p["lines"]:
            body = re.sub(r"^(>\s*|-\s*|\*\*?[^*]+\*\*?:?\s*|hook\s*[abc123]?\s*[:.)-]\s*)", "", line, flags=re.I)
            body = re.sub(r"^[A-Za-z0-9 ]{1,24}:\s*", "", body)  # a label like "Why it stands alone:"
            body = re.sub(r"^[\"\u201c]", "", body).strip()
            w = re.findall(r"[a-z']+", body.lower())[:2]
            if re.match(r"^(clip|slide|day|reel|post|hook|ad)\s*\d+", body, re.I) or re.fullmatch(r"\[[^\]]+\]", body):
                continue
            if any(f in line.lower() for f in fixed):
                continue
            if len(w) == 2 and " ".join(w) not in OPENER_SKIP and not META.match(line.lstrip("> ")):
                if line not in openers.setdefault(" ".join(w) + "\n", []):
                    openers[" ".join(w) + "\n"].append(line)
                    openers.setdefault(" ".join(w), []).append(i)
    for op, where in openers.items():
        if op.endswith("\n"):
            continue
        if len(where) > opener_limit:
            fails.append((where[opener_limit], "opener", f'{len(where)} lines open with "{op}": vary how lines start', ""))
    seen_frames, distinct = set(), []
    for i, line in contrast_hits:  # a line run word for word in several ads (the proven opening) counts once
        if line not in seen_frames:
            seen_frames.add(line)
            distinct.append((i, line))
    for i, line in distinct[frame_limit:]:
        fails.append((i, "frame", "the \"it isn't X, it's Y\" move again (\"you don't need X, you need Y\" "
                      "counts too): twice a week at most", line))

    if buyer_lines:
        bg = set()
        for bl in buyer_lines:
            bg |= grams(bl, 4, 2)
        coach_text = source.lower()
        for bl in buyer_lines:
            coach_text = coach_text.replace(bl.lower(), " ")
        coach_bigrams = grams(coach_text, 2, 2)
        buyer_bigrams = set()
        for bl in buyer_lines:
            for g in grams(bl, 2, 2):
                if all(len(x) > 3 for x in g.split()) and g not in coach_bigrams:
                    buyer_bigrams.add(g)
        buyer_numwords = {w for bl in buyer_lines for w in re.findall(r"[a-z]+", bl.lower()) if w in NUMBER_WORDS}
        coach_numwords = {w for w in re.findall(r"[a-z]+", coach_text) if w in NUMBER_WORDS}
        buyer_numwords -= coach_numwords
        for p in posts:
            if p["clips"]:
                continue
            for i, line in p["lines"]:
                if META.match(line.lstrip("> ")):
                    continue
                hit = (grams(line, 4, 2) & bg) or (grams(line, 2, 2) & buyer_bigrams)
                if hit:
                    fails.append((i, "buyer-words", f'copies the buyer: "{sorted(hit)[0]}". Paraphrase it', line))
                nums = {w for w in re.findall(r"[a-z]+", line.lower())} & buyer_numwords
                if nums:
                    fails.append((i, "buyer-number", f'uses the buyer\'s own number ("{sorted(nums)[0]}")', line))

    def norm(line):
        return re.sub(r"[^a-z0-9' ]", "", SLIDE_PREFIX.sub("", line.lstrip("> ").strip()).lower()).strip()
    short_count = {}
    for p in posts:
        for n in {norm(l) for _, l in p["lines"] if l and len(l.split()) <= 12}:
            short_count[n] = short_count.get(n, 0) + 1
    shared_short = {n for n, c in short_count.items() if c >= 2}
    for _, line in [(0, l) for p in posts for _, l in p["lines"]]:
        if line.startswith(">") and len(line.split()) > 12:
            n = norm(line)
            if sum(1 for p in posts if any(norm(l) == n for _, l in p["lines"])) >= 3:
                shared_short.add(n)  # a line run word for word in three or more ads is the proven opening
    seen = {}
    for idx, p in enumerate(posts):
        if p["clips"] or "new opening" in p["title"].lower():  # a hook test reuses its body on purpose
            continue
        g6 = set()
        for _, line in p["lines"]:
            if not line or META.match(line.lstrip("> ")) or norm(line) in shared_short:
                continue
            body = SLIDE_PREFIX.sub("", line.lstrip("> "))
            if any(f in body.lower() for f in fixed):
                continue
            g6 |= grams(body, 6, 3)
        for g in g6:
            seen.setdefault(g, set()).add(idx)
    pairs = set()
    for g, where in ({} if plan_mode else seen).items():
        if len(where) == 2:
            a, b = sorted(where)
            if (a, b) not in pairs:
                pairs.add((a, b))
                fails.append((0, "repeat", f'"{posts[a]["title"]}" and "{posts[b]["title"]}" share a line: "{g}"', ""))
    return fails


PRIMARY = re.compile(r"^\W*primary text\W*:?\s*(.*)$", re.I)
NAME_LEAD = re.compile(r"^(hi|hey|hello)\b|^(i'?m|i am|my name is)\s+[A-Z]", re.I)
PERSONAL = re.compile(r"\b(are you|you'?re|you are|if you'?re|if you are)\s+(broke|in debt|poor|overweight|obese|fat|"
                      r"depressed|anxious|divorced|lonely|unemployed|struggling (financially|with money|with (your )?weight))\b|"
                      r"\byour (debt|weight|credit score|bank account|anxiety|depression|divorce|religion|race|ethnicity|"
                      r"salary|income|paycheck|savings|finances|health|body)\b|"
                      r"\b(you'?re|you are)\s+(still\s+)?not paying yourself\b|\byou can'?t afford\b", re.I)
INCOME = re.compile(r"\byou('ll| will| can| could| are going to| would)?\s+(make|earn|bank|clear|hit|add|take home)\s+\$?\d|"
                    r"\b(guaranteed results?|guarantee you|overnight|easy money|get rich|passive income)\b", re.I)
LENGTH = re.compile(r"^\W*length\W*:\s*(about\s*)?(\d+)\s*sec", re.I)
HEADLINE = re.compile(r"^\W*headline\W*:\s*(.+)$", re.I)
PRICE = re.compile(r"\b(only|just|costs?|priced at|investment( of)?|price( is)?|pay)\s+\$\d", re.I)
TIE = re.compile(r"\b(funnel|business|numbers?|results?|clinic|program|one) like (his|hers|theirs)\b|"
                 r"\bresults? like (these|this|that|his|hers|theirs)\b|\bsame results?\b", re.I)
SUMMARY_CLOSE = re.compile(r"^that'?s (the|how|where|what|why|exactly)\b", re.I)
SCENARIO = re.compile(r"^(say|let'?s say|imagine|picture|suppose|pretend)\b", re.I)
HOOK_LINE = re.compile(r"^\W*hook\s*\d\s*[:.)-]\s*(.+)$", re.I)


def content_words(text):
    return {stem(w) for w in re.findall(r"[a-z0-9']+", text.lower()) if w not in STOP and len(w) > 2}


def overlap(a, b):
    a, b = content_words(a), content_words(b)
    return len(a & b) / max(1, min(len(a), len(b)))


LOOKS_LIKE = re.compile(r"\b(looks|feels|sounds) like\b[^.]{3,80}, and\b", re.I)


def ad_checks(lines, opening="", proof="", buyer_nouns=(), min_seconds=None):
    """Meta's review and the ad canon: run with --ads."""
    fails = []
    headlines = []
    looks_like = []
    joins = []
    nouns = [n.strip().lower() for n in buyer_nouns if n.strip()]
    proof_numbers = set()
    for m in NUMBER.finditer(proof or ""):
        tok, v = m.group(0), norm_number(m.group(0))
        if v is not None and ("%" in tok or "$" in tok or re.search(r"[kKmM]$", tok) or v >= 100):
            proof_numbers.add(v)  # the result itself, not the days or the team size
    for p in split_posts(lines):
        want_primary = False
        hooks, spoken, primary_first = [], [], None
        for i, line in p["lines"]:
            if line.startswith(">"):
                spoken.append((i, line.lstrip("> ").strip()))
            hm = HOOK_LINE.match(line)
            if hm:
                hooks.append((i, re.sub(r"\s*\(pick(ed)?\)\s*$", "", hm.group(1).strip(), flags=re.I)))
            if not line:
                continue
            m = PRIMARY.match(line)
            first = None
            if m:
                if m.group(1).strip():
                    first = m.group(1).strip()
                else:
                    want_primary = True
            elif want_primary:
                first, want_primary = line, False
            if first:
                primary_first = (i, first)
                lead = sentences(first.lstrip("-*> ").strip())
                if lead and lead[0].rstrip().endswith("?"):
                    fails.append((i, "primary-text", "the primary text leads with a question: lead with the hook "
                                  "as a statement", first))
                if NAME_LEAD.search(first.lstrip("-*> ").strip()):
                    fails.append((i, "primary-text", "the primary text leads with the coach's name or a greeting: "
                                  "lead with the hook", first))
            h = HEADLINE.match(line)
            if h:
                headlines.append((i, p["title"], h.group(1).strip().strip('"')))
            if h and len(h.group(1).strip().strip('"')) > 40:
                fails.append((i, "headline", f"the headline runs {len(h.group(1).strip())} characters: "
                              "40 at most, so it isn't cut off", line))
            body = line.lstrip("> ")
            if LOOKS_LIKE.search(body) and not META.match(body):
                looks_like.append((i, line))
            if PERSONAL.search(body):
                fails.append((i, "meta-personal", f'"{PERSONAL.search(body).group(0)}" says something personal about '
                              "the viewer (money, health, identity), which Meta rejects: talk about the situation or "
                              "about your clients instead", line))
            if INCOME.search(body):
                fails.append((i, "meta-income", f'"{INCOME.search(body).group(0)}" promises the viewer a result: '
                              "show a real, labelled result of a client instead", line))
            if PRICE.search(body):
                fails.append((i, "price", "a price in an ad: the price belongs on the call", line))
            if TIE.search(body):
                fails.append((i, "meta-income", f'"{TIE.search(body).group(0)}" ties a client\'s result to the viewer: '
                              "show the result, labelled, and let it stand on its own", line))
        picks = [h for h in hooks if re.search(r"\(pick(ed)?\)\s*$", next((l for i2, l in p["lines"] if i2 == h[0]), ""), re.I)]
        for si, st in spoken:
            for sent in sentences(st):
                if SUMMARY_CLOSE.match(sent.strip()) and len(sent.split()) <= 9:
                    fails.append((si, "summary", "a summary line (\"that's the order we work in\"): say why this "
                                  "makes the call worth booking instead", sent))
        if hooks and not picks:
            fails.append((hooks[0][0], "hooks", "no hook is marked (pick): mark the one the script films", hooks[0][1]))
        if picks and spoken and not (opening and spoken[0][1].lower() == opening.lower()):
            norm_h = lambda t: re.sub(r"[^a-z0-9' ]", "", t.lower()).strip()
            if not norm_h(spoken[0][1]).startswith(norm_h(picks[0][1])[:60]):
                fails.append((picks[0][0], "hooks", "the picked hook isn't the script's first line: film the pick, "
                              "word for word", picks[0][1]))
        for hi, ht in hooks:
            first_h = (sentences(ht) or [ht])[0]
            if len(first_h.split()) > 20:
                fails.append((hi, "hook", f"this hook runs {len(first_h.split())} words: 20 at most", ht))
            w5 = re.findall(r"[a-z0-9']+", ht.lower())
            five = [" ".join(w5[k:k + 5]) for k in range(len(w5) - 4)]
            if len(five) != len(set(five)):
                fails.append((hi, "hook", "this hook says the same words twice: rewrite it as one clean sentence", ht))
        for a in range(len(hooks)):
            for b in range(a + 1, len(hooks)):
                if overlap(hooks[a][1], hooks[b][1]) >= 0.6:
                    fails.append((hooks[b][0], "hooks", f"hooks {a + 1} and {b + 1} say the same thing: "
                                  "make the three hooks three different kinds", hooks[b][1]))
        if min_seconds and spoken:
            secs_all = sum(len(t.split()) for _, t in spoken) / 2.5
            if secs_all < min_seconds:
                fails.append((spoken[0][0], "length", f"about {round(secs_all)} seconds spoken, under the {round(min_seconds)} "
                              "a video ad needs to make its point", ""))
        stated = next((int(LENGTH.match(l).group(2)) for _, l in p["lines"] if LENGTH.match(l)), None)
        if stated and spoken:
            secs = sum(len(t.split()) for _, t in spoken) / 2.5
            if abs(secs - stated) > max(6, stated * 0.25):
                fails.append((next(i2 for i2, l in p["lines"] if LENGTH.match(l)), "length", f"the script says about "
                              f"{stated} seconds, but its words take about {round(secs)}: fix the Length line", ""))
        if spoken and opening and spoken[0][1].lower() == opening.lower() and len(spoken) >= 2:
            nxt = (sentences(spoken[1][1]) or [spoken[1][1]])[0]
            if not (content_words(nxt) & content_words(opening)) and not numbers_in(nxt):
                fails.append((spoken[1][0], "join", "the line after the proven opening doesn't pick up its thread: "
                              "repeat its key word or give its cost as a number", nxt))
            joins.append((spoken[1][0], p["title"], nxt))
        if spoken:
            i0, first_line = spoken[0]
            first_sent = (sentences(first_line) or [first_line])[0]
            if nouns:
                on_screen = " ".join(l for _, l in p["lines"] if re.match(r"^\W*on screen\W*:", l, re.I))
                seen = (first_sent + " " + on_screen).lower()
                if not any(re.search(r"(?<![a-z])" + re.escape(stem(n)), seen) for n in nouns):
                    fails.append((i0, "call-out", "neither the hook's first sentence nor the on-screen text says who "
                                  f"this is for (\"{nouns[0]}\"): name the buyer by their work", first_sent))
            if first_line.lower() != ("" if not opening else opening.lower()):
                if len(first_sent.split()) > 20:
                    fails.append((i0, "hook", f"the hook's first sentence runs {len(first_sent.split())} words: "
                                  "20 at most, with the topic in its first half", first_sent))
                if SCENARIO.match(first_sent):
                    fails.append((i0, "hook", "the hook opens on a made-up scenario: open on a verdict about "
                                  "something they own", first_sent))
            if primary_first and grams(primary_first[1], 6, 3) & grams(first_sent, 6, 3):
                fails.append((primary_first[0], "primary-text", "the primary text's first line repeats the spoken "
                              "hook: same idea, different words, so it works with the sound off", primary_first[1]))
        if proof_numbers:
            text = " ".join(l for _, l in p["lines"] if not META.match(l.lstrip("> ")))
            if numbers_in(text) & proof_numbers and "results vary" not in text.lower():
                fails.append((p["lines"][0][0] if p["lines"] else 0, "proof", f'"{p["title"]}" carries the result '
                              'without "results vary" beside it', ""))
    for a in range(len(joins)):
        for b in range(a + 1, len(joins)):
            if grams(joins[a][2], 4, 2) & grams(joins[b][2], 4, 2) or overlap(joins[a][2], joins[b][2]) >= 0.6:
                fails.append((joins[b][0], "join", f'"{joins[a][1]}" and "{joins[b][1]}" join the opening the same way: '
                              "each body picks up the thread with its own cost or number", joins[b][2]))
    for i, line in looks_like[2:]:
        fails.append((i, "template", "the \"it looks like X, and Y\" shape again: twice a batch at most", line))
    for a in range(len(headlines)):
        for b in range(a + 1, len(headlines)):
            if overlap(headlines[a][2], headlines[b][2]) >= 0.6:
                fails.append((headlines[b][0], "headline", f'"{headlines[a][1]}" and "{headlines[b][1]}" have the '
                              "same headline: each ad's headline says its own angle", headlines[b][2]))
    return fails


def sentences(text):
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p for p in parts if re.search(r"[A-Za-z]", p)]


def is_clause(s):
    if CONTRACTION.search(s):
        return True
    words = re.findall(r"[a-z']+", s.lower())
    if not words:
        return True
    if words[0] in IMPERATIVES:
        return True
    if any(w in VERBS or w.endswith("ed") or w.endswith("ing") for w in words):
        return True
    return any(w in SUBJECTS for w in words) and len(words) > 3


def norm_number(tok):
    t = tok.replace(",", "").replace("$", "").strip().lower()
    mult = 1
    if t.endswith("k"):
        mult, t = 1000, t[:-1]
    elif t.endswith("m"):
        mult, t = 1000000, t[:-1]
    t = t.rstrip("%x").strip()
    try:
        return float(t) * mult
    except ValueError:
        return None


def numbers_in(text):
    found = set()
    for m in NUMBER.finditer(text):
        v = norm_number(m.group(0))
        if v is not None:
            found.add(v)
    return found


def voice_stats(lines):
    sents = [s for line in lines for s in sentences(line)]
    if not sents:
        return None
    words = [len(re.findall(r"[A-Za-z']+", s)) for s in sents]
    contractions = sum(len(CONTRACTION.findall(s)) for s in sents)
    total_words = max(1, sum(words))
    return {"avg_sentence_words": round(sum(words) / len(words), 1),
            "contractions_per_100_words": round(100 * contractions / total_words, 1)}


def opening_text(lines):
    opening, inside = [], False
    for raw in lines:
        if raw.startswith("## "):
            inside = "proven opening" in raw.lower()
        elif inside and raw.strip().startswith(">"):
            opening.append(raw.strip().lstrip("> ").strip())
    return " ".join(opening)


def expand_opening(lines):
    """Put the proven opening's real words wherever an ad runs it as "> [THE PROVEN OPENING]",
    so its hook, lock-in and Meta checks see what the viewer hears. Line numbers stay the same."""
    opening, inside = [], False
    for raw in lines:
        if raw.startswith("## "):
            inside = "proven opening" in raw.lower()
        elif inside and raw.strip().startswith(">"):
            opening.append(raw.strip().lstrip("> ").strip())
    if not opening:
        return lines
    said = "> " + " ".join(opening)
    out = []
    for raw in lines:
        out.append(said if re.fullmatch(r">\s*\[the proven opening\]", raw.strip(), re.I) else raw)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("drafts")
    ap.add_argument("--source", required=True)
    ap.add_argument("--voice")
    ap.add_argument("--buyer")
    ap.add_argument("--cta", default="", help="their call to action, ignored by the repeat check")
    ap.add_argument("--avoid", help="a file of words or phrases that must not appear in any post, one per line "
                    "(for a remix: the original's central picture)")
    ap.add_argument("--max-seconds", type=float, help="fail any reel whose spoken script runs longer than this")
    ap.add_argument("--voice-floor", type=float, default=0.6, help="fail when sentences run shorter than this share "
                    "of theirs (a long spoken script can ask for 0.75)")
    ap.add_argument("--not-from", help="a folder of the skill's own rule files: fail any line that repeats one of them "
                    "word for word (say it for this person, don't recite the rules)")
    ap.add_argument("--plan", action="store_true", help="a plan, not posts: 'this week' is an instruction, not a "
                    "claim about when something happened, and sections may share a line")
    ap.add_argument("--opener-limit", type=int, default=4, help="how many lines may open with the same two words "
                    "(a long script, like a webinar's, can allow more)")
    ap.add_argument("--min-seconds", type=float, help="ads: fail any video whose spoken script runs shorter than this")
    ap.add_argument("--frame-limit", type=int, default=2, help="how many times the 'it isn't X, it's Y' move may appear")
    ap.add_argument("--dashboard", help="your-week.html: check the filled-in dashboard too")
    ap.add_argument("--ads", action="store_true", help="ads: also check the primary text and Meta's ad rules")
    ap.add_argument("--buyer-noun", default="", help="ads: who it's for, by their work (e.g. \"coaches\"); "
                    "comma-separate several. Every video names them in its hook or its on-screen text")
    ap.add_argument("--signature", default="", help="their signature words or check-ins, comma-separated: "
                    "the drafts' spoken lines use them at a third of their rate in the source or more")
    ap.add_argument("--proof", default="", help="their proof line, word for word: it may repeat across ads, "
                    "and any ad carrying its numbers needs \"results vary\"")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    drafts = open(a.drafts, encoding="utf-8").read().splitlines()
    source = open(a.source, encoding="utf-8").read()
    # timestamps ("[12:31]") are not facts a post can quote
    source_numbers = numbers_in(re.sub(r"\[?\b\d{1,2}:\d{2}(:\d{2})?\b\]?", " ", source))
    APPROX = re.compile(r"\b(about|around|roughly|nearly|almost|close to|over|under|more than|less than|up to)\s+(" + NUMBER.pattern + ")", re.I)
    approx_values = {norm_number(m.group(2)) for m in APPROX.finditer(source)} - {None}
    bare = numbers_in(APPROX.sub(" ", source))
    approx_only = {v for v in approx_values - bare if v > 10}
    fact_numbers = set()
    for sent in re.split(r"(?<=[.!?])\s+", source):
        if not EXAMPLE.search(sent):
            fact_numbers |= numbers_in(sent)

    fails, warns = [], []
    spoken = []
    # numbers the material only gives as an example ("let's say a thousand people") are not facts
    example_numbers = set()
    for sent in re.split(r"(?<=[.!?])\s+", source):
        if EXAMPLE.search(sent):
            example_numbers |= {v for v in numbers_in(sent) if v > 10}
    for i, raw in enumerate(drafts, 1):
        line = raw.strip()
        if not line:
            continue
        if DASHES.search(line):
            fails.append((i, "dash", "em or en dash: rewrite with a period, a comma or 'and'", line))
        low = line.lower()
        for p in AI_PHRASES:
            if re.search(r"(?<![a-z])" + re.escape(p) + r"(?![a-z])", low):
                fails.append((i, "ai-phrase", f'stock AI phrase "{p}"', line))
        if "[your number]" not in low:
            cleaned = STRUCTURAL.sub(" ", line)
            for m in NUMBER.finditer(cleaned):
                v = norm_number(m.group(0))
                if v is None or (v <= 10 and float(v).is_integer()):
                    continue
                if v not in source_numbers:
                    fails.append((i, "number", f'"{m.group(0).strip()}" is not in the source; '
                                  "use [YOUR NUMBER] or a number from the material", line))
                elif v in approx_only and not re.search(r"\b(about|around|roughly|nearly|almost|close to|over|under|"
                                                        r"more than|less than|up to|~)\s*$", cleaned[:m.start()], re.I):
                    fails.append((i, "number", f'the material says about {m.group(0).strip()}, not exactly: '
                                  "keep its \"about\"", line))
                elif v in example_numbers and v not in fact_numbers and not EXAMPLE.search(line):
                    fails.append((i, "number", f'"{m.group(0).strip()}" was an example in the material, not a fact: '
                                  "don't state it as one", line))
        if line.startswith(">"):
            text = line.lstrip("> ").strip()
            spoken.append(text)
            for s in sentences(text):
                if not is_clause(s) and len(s.split()) <= 6 and not re.search(r"results vary", s, re.I):
                    warns.append((i, "fragment", f'headline fragment "{s}": say it as a sentence', line))

    frag_count = sum(1 for w in warns if w[1] == "fragment")
    if frag_count > 3:
        fails.append((0, "fragments", f"{frag_count} headline fragments in spoken lines (3 max)", ""))

    buyer_lines = []
    if a.buyer and os.path.exists(a.buyer):
        buyer_lines = [l for l in open(a.buyer, encoding="utf-8").read().splitlines() if l.strip()]
    elif a.buyer:
        warns.append((0, "missing", f"{a.buyer} not found, so the copied-words check was skipped", ""))
    avoid = []
    if a.avoid and os.path.exists(a.avoid):
        avoid = [l.strip().lower() for l in open(a.avoid, encoding="utf-8").read().splitlines() if l.strip()]
    checked = expand_opening(drafts)
    fails += week_checks(checked, source, buyer_lines, a.cta, avoid, a.max_seconds, a.frame_limit, [a.proof], a.ads,
                         a.opener_limit, a.plan)
    if a.ads:
        fails += ad_checks(checked, opening_text(drafts), a.proof, a.buyer_noun.split(","), a.min_seconds)

    if a.dashboard:
        html = open(a.dashboard, encoding="utf-8").read()
        m = re.search(r'<script id="data" type="application/json">(.*?)</script>', html, re.S)
        try:
            data = json.loads(m.group(1)) if m else None
        except ValueError:
            data = None
        if not data:
            fails.append((0, "dashboard", "the dashboard's DATA block is missing or isn't valid JSON", ""))
        else:
            if not data.get("posts"):
                fails.append((0, "dashboard", "the dashboard has no posts", ""))
            for k, post in enumerate(data.get("posts", []), 1):
                for field in ("hook", "on_screen", "body", "title"):
                    for bl in str(post.get(field, "")).splitlines():
                        if WORKING_NOTE.match(bl.strip().lstrip("> ")):
                            fails.append((0, "dashboard", f"post {k}'s {field} still holds a working note: "
                                          f'"{bl.strip()[:60]}"', ""))
                        if DASHES.search(bl):
                            fails.append((0, "dashboard", f"post {k}'s {field} has an em or en dash", ""))

    voice_report = None
    if a.voice and not os.path.exists(a.voice):
        warns.append((0, "missing", f"{a.voice} not found, so the voice check was skipped", ""))
    if a.signature and spoken:
        ref_text = source.lower()  # their whole material, so a short voice.txt can't hide the rate
        mine_text = " ".join(spoken).lower()
        rate = lambda text, w: 100 * len(re.findall(r"(?<![a-z])" + re.escape(w) + r"(?![a-z])", text)) / max(1, len(text.split()))
        theirs_total = sum(rate(ref_text, w.strip().lower()) for w in a.signature.split(",") if w.strip())
        mine_total = sum(rate(mine_text, w.strip().lower()) for w in a.signature.split(",") if w.strip())
        if theirs_total and mine_total < theirs_total / 3:
            fails.append((0, "voice", f"their signature words ({a.signature}) come about {theirs_total:.1f} times per "
                          f"100 words in their material and {mine_total:.1f} in the drafts: put them back where they'd say them", ""))
    if a.voice and spoken and os.path.exists(a.voice):
        # short acknowledgements ("got it", "talk soon") would drag the benchmark down
        ref = [l for l in open(a.voice, encoding="utf-8").read().splitlines() if len(l.split()) >= 6]
        mine, theirs = voice_stats(spoken), voice_stats(ref)
        if mine and theirs:
            voice_report = {"drafts": mine, "their_voice": theirs}
            r = mine["avg_sentence_words"] / max(1, theirs["avg_sentence_words"])
            if r > 1.4 or r < a.voice_floor:
                fails.append((0, "voice", f"sentences average {mine['avg_sentence_words']} words; "
                              f"they talk in about {theirs['avg_sentence_words']}", ""))
            c_m, c_t = mine["contractions_per_100_words"], theirs["contractions_per_100_words"]
            if c_t >= 2 and c_m < c_t * 0.5:
                fails.append((0, "voice", f"{c_m} contractions per 100 words; they use about {c_t}. "
                              "Write it the way they say it", ""))

    if a.not_from and os.path.isdir(a.not_from):
        rule_text = " ".join(open(os.path.join(a.not_from, f), encoding="utf-8").read()
                             for f in os.listdir(a.not_from) if f.endswith(".md"))
        rule_grams = grams(rule_text, 6, 3)
        for i, raw in enumerate(drafts, 1):
            hit = grams(raw, 6, 3) & rule_grams
            if hit:
                fails.append((i, "recited", f'repeats the skill\'s own rules word for word ("{sorted(hit)[0]}"): '
                              "say it for this person, in plain words", raw.strip()))
    if a.plan:
        week_re = re.compile(r"^\W*week\s*\d", re.I)
        blocks, cur = [], None
        for i, raw in enumerate(drafts, 1):
            if week_re.match(raw):
                cur = [i, raw]
                blocks.append(cur)
            elif raw.startswith("#"):
                cur = None
            elif cur is not None:
                cur[1] += " " + raw
        for i, text in blocks:
            if not re.search(r"done when", text, re.I):
                fails.append((i, "week", 'this week has no "done when": the result, with a number, that ends it', ""))
            if re.search(r"\b(plus|and add|adding|also add|as well as)\b", text, re.I):
                fails.append((i, "week", "this week looks like two changes: one change per week", ""))
        for i, text in blocks:
            if re.search(r"\bor you know\b", text, re.I):
                fails.append((i, "week", '"or you know..." is an end that can\'t fail: give the number that ends it', ""))
        for i, raw in enumerate(drafts, 1):
            if re.search(r"worth about \$[\d,]+", raw, re.I) and not re.search(r"at (its|the) floor", raw, re.I):
                fails.append((i, "plan", 'a "worth about $..." without "at the floor": say what it\'s worth at its floor', raw.strip()))
            if re.search(r"\bthe script\b", raw, re.I):
                fails.append((i, "plan", 'talks about "the script": say what the numbers show, not the tool', raw.strip()))
    once, kept = set(), []
    for f in fails:  # the same problem on the same words is reported once
        key = (f[1], f[2], f[3]) if f[3] else f
        if key not in once:
            once.add(key)
            kept.append(f)
    fails = kept
    result = {"pass": not fails, "fails": [dict(zip(("line", "kind", "why", "text"), f)) for f in fails],
              "warnings": [dict(zip(("line", "kind", "why", "text"), w)) for w in warns],
              "voice": voice_report}
    if a.json:
        print(json.dumps(result, indent=2))
    else:
        print("PASS" if result["pass"] else f"FAIL ({len(fails)} to fix)")
        for f in fails:
            loc = f"line {f[0]}" if f[0] else "overall"
            print(f"  [{f[1]}] {loc}: {f[2]}" + (f"\n      {f[3][:140]}" if f[3] else ""))
        for w in warns[:12]:
            print(f"  (warning) line {w[0]}: {w[2]}")
        if voice_report:
            print(f"  voice: drafts {voice_report['drafts']} vs theirs {voice_report['their_voice']}")
    sys.exit(0 if result["pass"] else 1)


if __name__ == "__main__":
    main()
