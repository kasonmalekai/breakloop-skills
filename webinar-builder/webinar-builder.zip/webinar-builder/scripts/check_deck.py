#!/usr/bin/env python3
"""Check the webinar's structure before anyone sees it, and write notes.md for the voice check.

Usage:
    python3 scripts/check_deck.py deck.json

It checks what a webinar needs to sell the call: the plan is complete, the clock lands the ask
at 45 to 50 minutes, 3 to 5 steps each carry their four beats, the map comes back after every
step, a commitment comes by minute 5, the doubts are named early, the stay-to-end gift is
announced, reminded and revealed after the ask, the close asks more than once and never shows
a price, and each slide holds one idea. It prints PASS or FAIL with what to fix, lists every
[ASSET NEEDED] and [CONFIRM] for the coach, and writes notes.md (every spoken line and every
word on the slides) so scripts/check.py can check the voice, the numbers and the claims.
Standard library only.
"""
import json
import re
import sys

BEATS = ("context", "vision", "strategy", "commitment")
TREATMENTS = ("ignore", "disagree", "agree")
PRICE = re.compile(r"\b(only|just|costs?|priced at|investment|price( is)?|pay|for)\s+\$\d", re.I)
MONEY = re.compile(r"\$\s?\d[\d,]*(\.\d+)?\s*[kKmM]?")
PLACEHOLDER = re.compile(r"\[(ASSET NEEDED|CONFIRM)[^\]]*\]")
LIVE = re.compile(r"\blive\b", re.I)


def words(t):
    return len(str(t or "").split())


def slide_text(s):
    keys = ("title", "sub", "text", "eyebrow", "label", "number", "qualifier", "quote", "name", "detail",
            "prompt", "caption", "needed", "link", "left", "right")
    out = [str(s[k]) for k in keys if s.get(k)]
    for k in ("items", "left_items", "right_items", "steps"):
        out += [str(x) for x in s.get(k, [])]
    return out


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    plan, slides = spec.get("plan", {}), spec.get("slides", [])
    fails, notes_out = [], []

    def fail(where, why):
        fails.append(f"[{where}] {why}")

    # the plan, locked before the slides
    o = plan.get("outcome", {})
    if not all(o.get(k) for k in ("audience", "feeling", "result")):
        fail("plan", "the outcome needs all three: who it's for, the feeling, and the result")
    for k in ("central_idea", "beliefs", "steps", "gaps", "objections", "magnet"):
        if not plan.get(k):
            fail("plan", f"the plan is missing {k}")
    steps = plan.get("steps", [])
    if steps and not 3 <= len(steps) <= 5:
        fail("plan", f"{len(steps)} steps: teach 3 to 5 (fewer means steps were merged, more means the promise is too big)")
    gaps = plan.get("gaps", [])
    if any(not (g.get("teaching") and g.get("call")) for g in gaps):
        fail("plan", "every gap needs both sides: the teaching moment, and what the call gives them for it")
    if steps and len(gaps) < len(steps):
        fail("plan", "fewer gaps than steps: each step should leave something the call is for")
    obj = plan.get("objections", [])
    if obj and not 3 <= len(obj) <= 6:
        fail("plan", f"{len(obj)} doubts: name 3 to 6")
    for x in obj:
        if str(x.get("treatment", "")).lower() not in TREATMENTS:
            fail("plan", f'the doubt "{x.get("name")}" needs a treatment: ignore, disagree or agree')
    for p in plan.get("proof", []):
        if not (p.get("result") and p.get("span") and p.get("qualifier")):
            fail("plan", f'the result for "{p.get("who")}" needs its span and its qualifier, kept with it everywhere')

    # the clock: each slide lasts as long as its words take to say (about 140 a minute), plus time for
    # the chat to answer and for anything played or shown (the slide's "extra" minutes)
    def slide_min(s):
        n_ = s.get("notes") or {}
        chat = 0.5 if (n_.get("interaction") or s.get("type") == "prompt" or s.get("commitment")) else 0
        return words(n_.get("say")) / 140 + chat + float(s.get("extra") or 0)
    for s in slides:
        s["min"] = round(slide_min(s), 2)
    t, starts = 0.0, []
    for s in slides:
        starts.append(t)
        t += s["min"]
    total = t
    mins = {}
    for s in slides:
        mins[s.get("block")] = mins.get(s.get("block"), 0) + s["min"]
    if not 35 <= len(slides) <= 90:
        fail("deck", f"{len(slides)} slides: a 60-minute webinar runs about 40 to 80")
    bands = {"intro": (7, 13), "content": (34, 45), "transition": (3, 7), "close": (10, 16)}
    for b, (lo, hi) in bands.items():
        if not lo <= mins.get(b, 0) <= hi:
            fail("clock", f"the {b} runs {mins.get(b, 0):.0f} minutes: aim for {lo} to {hi}")
    first_ask = next((i for i, s in enumerate(slides) if s.get("ask") and s.get("block") == "close"), None)
    if first_ask is None:
        fail("close", "no slide in the close is marked as an ask")
    elif not 43 <= starts[first_ask] <= 52:
        fail("clock", f"the call is first asked for at minute {starts[first_ask]:.0f}: land it at 45 to 50")
    content = [s for s in slides if s.get("block") == "content"]
    one = sum(float(s.get("min") or 0) for s in content if s.get("step") == 1)
    if mins.get("content") and not 0.295 <= one / mins["content"] <= 0.36:
        fail("clock", f"step 1 takes {100 * one / mins['content']:.0f}% of the teaching: give it 30 to 35%")

    # the steps, their beats, and the map after each one
    for k in range(1, len(steps) + 1):
        idx = [i for i, s in enumerate(slides) if s.get("step") == k]
        if not idx:
            fail(f"step {k}", "has no slides")
            continue
        missing = [b for b in BEATS if not any(slides[i].get("beat") == b for i in idx)]
        if missing:
            fail(f"step {k}", f"missing its {', '.join(missing)} beat")
        nxt = next((i for i, s in enumerate(slides) if s.get("step") == k + 1), None)
        if nxt is None:
            nxt = next((i for i, s in enumerate(slides) if s.get("block") in ("transition", "close")), len(slides))
        want = k + 1
        if not any(s.get("type") == "map" and int(s.get("current", 0)) >= want for s in slides[idx[-1]:nxt + 1]):
            fail(f"step {k}", f"the map doesn't come back after it, showing step {k} done")
    first_step = next((i for i, s in enumerate(slides) if s.get("step") == 1), None)
    if first_step is not None and not any(s.get("type") == "map" for s in slides[:first_step + 1]):
        fail("content", "show the whole map before step 1")

    # the threads
    if not any(s.get("commitment") and starts[i] <= 5 for i, s in enumerate(slides)):
        fail("intro", "no typed commitment by minute 5")
    intro_obj = [s for s in slides if s.get("block") == "intro" and (s.get("objection") or (s.get("notes") or {}).get("objection"))]
    if obj and len(intro_obj) < min(3, len(obj)):
        fail("intro", f"only {len(intro_obj)} doubts named in the introduction: name at least 3 early")
    if plan.get("not_for") and not any(s.get("not_for") for s in slides):
        fail("deck", "say who it isn't for before the close")
    if plan.get("not_for"):
        nf = [i for i, s in enumerate(slides) if s.get("not_for")]
        if nf and first_ask is not None and min(nf) > first_ask:
            fail("deck", "say who it isn't for before the close, not after it")
    people = {}
    for s in slides:
        if s.get("testimonial"):
            people.setdefault(s["testimonial"], set()).add(s.get("block"))
    for who, blocks in people.items():
        if len(blocks) < 2:
            fail("proof", f'{who} appears once: bring the same person back in the teaching and the close')
    tr = [s for s in slides if s.get("block") == "transition"]
    if not tr:
        fail("transition", "there's no transition between the teaching and the close")
    elif not any(s.get("type") == "prompt" for s in tr):
        fail("transition", "the transition needs its one honest question to the room")
    asks = [i for i, s in enumerate(slides) if s.get("ask")]
    early = [i for i in asks if slides[i].get("block") in ("intro", "content")]
    if len(early) > 1:
        fail("asks", "more than one ask before the close: one early soft ask at most")
    if len([i for i in asks if slides[i].get("block") in ("close", "qa")]) < 3:
        fail("asks", "the close asks fewer than 3 times: ask, answer a doubt, ask again")
    mag = {s.get("magnet") for s in slides if s.get("magnet")}
    if "announce" not in {s.get("magnet") for s in slides if s.get("block") == "intro"}:
        fail("gift", "announce the stay-to-end gift in the introduction")
    if "remind" not in {s.get("magnet") for s in slides if s.get("block") == "content"}:
        fail("gift", "remind them of the gift during the teaching (the map slides are the place)")
    rev = [i for i, s in enumerate(slides) if s.get("magnet") == "reveal"]
    if not rev or (first_ask is not None and min(rev) < first_ask):
        fail("gift", "reveal the gift in the close, after the first ask, for the people still there")

    # the close: no price; one idea per slide; live only if it's live
    proof_money = set()
    for p in plan.get("proof", []):
        for k in ("start", "result", "public_wording"):  # where they began counts too
            proof_money |= {m.group(0).replace(" ", "").lower() for m in MONEY.finditer(str(p.get(k, "")))}
    for n, s in enumerate(slides, 1):
        text = " ".join(slide_text(s)) + " " + str((s.get("notes") or {}).get("say", ""))
        if s.get("block") in ("close", "qa", "transition"):
            if PRICE.search(text):
                fail(f"slide {n}", "a price in the close: the price belongs on the call")
            for m in MONEY.finditer(text):
                if m.group(0).replace(" ", "").lower() not in proof_money:
                    fail(f"slide {n}", f'"{m.group(0)}" in the close: no figures here except a labelled result')
        if s.get("type") == "number" and not s.get("qualifier"):
            fail(f"slide {n}", "a result with no qualifier beside it")
        if s.get("type") == "statement" and words(s.get("text")) > 16:
            fail(f"slide {n}", f"{words(s.get('text'))} words on a statement slide: one idea, 16 words at most")
        for it in s.get("items", []):
            if words(it) > 14:
                fail(f"slide {n}", f'"{it[:40]}..." runs {words(it)} words: 14 at most a line')
        if plan.get("live") is False and any(LIVE.search(x) for x in slide_text(s)):
            fail(f"slide {n}", 'the webinar is recorded, so the slides never say "live"')
        if not (s.get("notes") or {}).get("say"):
            fail(f"slide {n}", "no speaker notes: say what to say on this slide")

    # enough to rehearse from: the notes fill the minutes, the chat is used, nothing is left "to fill in"
    TACTIC = re.compile(r"\b(holding (the how )?back|hold(ing)? back the how|answer two|every answer (bends|ends)|"
                        r"the rest gets looked at|so you'?ll want to stay|keep you watching|bend(s)? back to the call)\b", re.I)
    DEFLECT = re.compile(r"\b(explain(ed)?|cover(ed)?|go (through|over)|walk (you )?through|look at|talk about) "
                         r"(it |that |this |them |those )?(all )?on the call\b", re.I)
    firsts = {}
    for n, s in enumerate(slides, 1):
        say = str((s.get("notes") or {}).get("say", ""))
        if TACTIC.search(say + " " + " ".join(slide_text(s))):
            fail(f"slide {n}", f'"{TACTIC.search(say + " " + " ".join(slide_text(s))).group(0)}" is a tactic said out loud: '
                 "keep how the webinar works out of what the room hears")
        if s.get("block") in ("close", "qa") and (s.get("objection") or (s.get("notes") or {}).get("objection")) and DEFLECT.search(say):
            fail(f"slide {n}", "this answer to a doubt points to the call instead of answering it: answer it here, from "
                 "the coach's numbers, story or a client's result")
        w1 = (re.findall(r"[A-Za-z']+", say)[:1] or [""])[0].lower()
        if w1:
            firsts[w1] = firsts.get(w1, 0) + 1
    for w1, c in firsts.items():
        if c > 8 and c > 0.2 * len(slides):
            fail("notes", f'{c} slides\' notes start with "{w1}": vary how they start')
    for n, s in enumerate(slides, 1):
        if re.search(r"\(?\b(fill in|tbd|to be added|add later)\b", str((s.get("notes") or {}).get("say", "")), re.I):
            fail(f"slide {n}", 'the notes say "fill in": write the line, with a [CONFIRM: ...] where something is unknown')
    last = None
    for i, s in enumerate(slides):
        if s.get("block") != "content":
            continue
        if (s.get("notes") or {}).get("interaction") or s.get("type") == "prompt" or s.get("commitment"):
            last = starts[i]
        elif last is not None and starts[i] - last > 5:
            fail(f"slide {i + 1}", f"{starts[i] - last:.0f} minutes since the chat was last asked anything: bring them in")
            last = starts[i]
    for n, s in enumerate(slides, 1):
        for m_ in re.finditer(r"\b(\d+)\s*(-\s*)?minutes?\b", " ".join(slide_text(s)) + " " +
                              str((s.get("notes") or {}).get("say", ""))):
            claimed = int(m_.group(1))
            if s.get("block") == "intro" and 20 <= claimed < total - 2:
                fail(f"slide {n}", f'says "{m_.group(0)}" but the webinar runs about {total:.0f}: say the real length')

    # the one idea is taught, the gaps come back in the close, and every early doubt is answered there
    def cw(t):
        return {w for w in re.findall(r"[a-z0-9']+", str(t).lower()) if len(w) > 3}
    everything = [cw(" ".join(slide_text(s)) + " " + str((s.get("notes") or {}).get("say", ""))) for s in slides]
    idea = cw(plan.get("central_idea", ""))
    if idea and not any(len(idea & e) >= 0.6 * len(idea) for e in everything):
        fail("teaching", "no slide teaches the one idea itself: give it a slide, with the coach's own numbers if there are any")
    teach_text = set().union(*[e for s, e in zip(slides, everything) if s.get("block") == "content"] or [set()])
    for g in gaps:
        planted = cw(g.get("teaching", ""))
        if planted and len(planted & teach_text) < 0.5 * len(planted):
            fail("teaching", f'the gap "{str(g.get("teaching"))[:40]}" is never planted in the teaching: name the hard '
                 "part, what it costs, and get agreement it's worth doing, in the step it belongs to")
    close_text = set().union(*[e for s, e in zip(slides, everything) if s.get("block") in ("close", "qa")] or [set()])
    for g in gaps:
        want_ = cw(g.get("call", ""))
        if want_ and len(want_ & close_text) < 0.5 * len(want_):
            fail("close", f'the close never offers what the call gives for "{str(g.get("teaching"))[:40]}": '
                 "list each gap's answer in what comes with the call")
    promise = cw(o.get("result", ""))
    for n, (s, e) in enumerate(zip(slides, everything), 1):
        if s.get("block") in ("close", "qa") and promise and len(promise & e) >= 0.7 * len(promise):
            fail(f"slide {n}", "the close offers what the webinar promised to teach: the teaching delivers the "
                 "promise, and the call offers going further (on their own numbers, with help)")

    # teaching teaches the viewer; proof keeps its wording; an unknown stays marked when it's said
    for n, s in enumerate(slides, 1):
        say = str((s.get("notes") or {}).get("say", ""))
        if s.get("beat") == "strategy":
            we = len(re.findall(r"\b(we|our|us)\b", say, re.I))
            you = len(re.findall(r"\b(you|your)\b", say, re.I))
            if we > you:
                fail(f"slide {n}", "this how-to describes what the coach does for clients: teach the viewer how to do it")
        if any(PLACEHOLDER.search(x) for x in slide_text(s)) and "[confirm" not in say.lower() and "[asset" not in say.lower():
            fail(f"slide {n}", "the slide has a [CONFIRM] but the spoken line states it as fact: keep the [CONFIRM] in the note too")
    def norm(t):
        return " ".join(re.findall(r"[a-z0-9$%]+", str(t).lower()))
    for p in plan.get("proof", []):
        pw = p.get("public_wording")
        if not pw:
            continue
        figs = {m.group(0).replace(" ", "").lower() for m in MONEY.finditer(pw)}
        core = norm(re.sub(r"(one client\.?\s*)?results vary\.?", "", pw, flags=re.I))
        for n, s in enumerate(slides, 1):
            shown = " ".join(slide_text(s))
            if figs & {m.group(0).replace(" ", "").lower() for m in MONEY.finditer(shown)} and core not in norm(shown):
                fail(f"slide {n}", "a result on screen that isn't in its public wording: show the whole line, word for word "
                     "(the big figure can sit above it)")

    def obj_of(s):
        return s.get("objection") or (s.get("notes") or {}).get("objection")
    named = {obj_of(s) for s in slides if s.get("block") == "intro" and obj_of(s)}
    answered = {obj_of(s) for s in slides if s.get("block") in ("close", "qa") and obj_of(s)}
    for o_ in sorted(named - answered):
        fail("close", f'the doubt "{o_}" is named early but never answered in the close')
    for o_ in sorted(answered - named):
        fail("intro", f'the doubt "{o_}" is answered in the close but never named in the introduction')
    for n, s in enumerate(slides, 1):
        if s.get("block") in ("close", "qa") and obj_of(s):
            say = str((s.get("notes") or {}).get("say", ""))
            bare = re.sub(r"\[(CONFIRM|ASSET NEEDED)[^\]]*\]", "", say)
            if words(bare) < 25:
                fail(f"slide {n}", "this answer to a doubt is mostly a [CONFIRM]: give an answer from their material too")

    # the run of show, worked out here so the minutes always add up
    def clock(m):
        sec = int(round(m * 60))
        return f"{sec // 60}:{sec % 60:02d}"
    ros, cur = ["# Run of show", ""], None
    for i, s in enumerate(slides):
        part = s.get("block") if s.get("block") != "content" else f'step {s.get("step") or ""}'.strip()
        if part != cur:
            ros.append(f"\n## {clock(starts[i])} {part}")
            cur = part
        head = s.get("title") or s.get("text") or s.get("prompt") or s.get("number") or s.get("quote") or s.get("needed") or s.get("type")
        ros.append(f"- slide {i + 1} ({clock(starts[i])}): {str(head)[:80]}")
    ros.append(f"\nEnds about {clock(total)}. The call is first asked for at "
               f"{clock(starts[first_ask]) if first_ask is not None else 'no ask yet'}.")
    open("run-of-show.md", "w", encoding="utf-8").write("\n".join(ros) + "\n")

    # the proof, said out loud: only the coach's own result, whole, beside a slide that shows it
    MONTH = re.compile(r"\b(january|february|march|april|may|june|july|august|september|october|november|december)\b", re.I)
    EXAMPLE_SAY = re.compile(r"\b(let'?s say|say you|say a|say there|imagine|for example|for instance|suppose|picture)\b", re.I)
    public = [p.get("public_wording") for p in plan.get("proof", []) if p.get("public_wording")]
    who_money = {m.group(0).replace(" ", "").lower() for m in MONEY.finditer(" ".join(str(v) for v in o.values()))}
    for n, s in enumerate(slides, 1):
        say = str((s.get("notes") or {}).get("say", ""))
        shown = " ".join(slide_text(s))
        for sent in re.split(r"(?<=[.!?])\s+", say):
            figs = {m.group(0).replace(" ", "").lower() for m in MONEY.finditer(sent)}
            if not figs:
                continue
            if MONTH.search(sent) and not re.search(r"\bmay (be|have|not|i|you|we)\b", sent, re.I):
                fail(f"slide {n}", "a month beside a result: say the span instead (\"in the 45 days after\"), never the month")
            if "[confirm" in sent.lower() or EXAMPLE_SAY.search(sent):
                continue
            figs -= who_money  # who it's for ("coaches doing $50K to $200K a month") isn't a result
            if not figs:
                continue
            if not figs <= proof_money:
                fail(f"slide {n}", f'"{sorted(figs - proof_money)[0]}" said as a result that isn\'t in their proof: '
                     "only the proof line's figures are said as results; anything else is a [CONFIRM] or plainly an example")
            elif public and not any(norm(re.sub(r"(one client\.?\s*)?results vary\.?", "", pw, flags=re.I)) in norm(shown)
                                    for pw in public):
                fail(f"slide {n}", "the result is said on a slide that doesn't show it: say it where the whole proof line is on screen")
    # an answer to a doubt ends on the ask, and no sentence frame becomes a formula
    for n, s in enumerate(slides, 1):
        if s.get("block") in ("close", "qa") and (s.get("objection") or (s.get("notes") or {}).get("objection")) and not s.get("ask"):
            fail(f"slide {n}", "this answer to a doubt doesn't end on the ask: mark it as an ask and close on the link")
    frames = {}
    for n, s in enumerate(slides, 1):
        for sent in re.split(r"(?<=[.!?])\s+", str((s.get("notes") or {}).get("say", ""))):
            if sent.lstrip().startswith("["):
                continue  # a [CONFIRM] isn't a sentence frame
            w4 = " ".join(re.findall(r"[a-z']+", sent.lower())[:4])
            if len(w4.split()) == 4:
                frames.setdefault(w4, []).append(n)
    for w4, where in frames.items():
        if len(where) >= 3:
            fail(f"slide {where[2]}", f'"{w4}..." opens {len(where)} lines: a repeated frame reads as a formula, so vary it')

    # notes.md for check.py, and the list of things to gather
    holes = []
    notes_out.append("## The webinar")  # one section: a slide and the words said over it may share a line
    for n, s in enumerate(slides, 1):
        say = str((s.get("notes") or {}).get("say", "")).strip()
        if say:
            notes_out.append("> " + say)
            holes += [f"slide {n} (said): {m.group(0)}" for m in PLACEHOLDER.finditer(say)]
        for line in slide_text(s):
            if s.get("type") == "asset" and line == s.get("needed") and not s.get("image"):
                holes.append(f"slide {n}: [ASSET NEEDED: {line}]")
                continue
            notes_out.append(line)
            holes += [f"slide {n}: {m.group(0)}" for m in PLACEHOLDER.finditer(line)]
    open("notes.md", "w", encoding="utf-8").write("\n".join(notes_out) + "\n")

    print("PASS" if not fails else f"FAIL ({len(fails)} to fix)")
    for f in fails:
        print("  " + f)
    print("  (minutes are worked out from the words, at about 140 a minute, plus half a minute for each chat moment "
          "and any extra minutes set on a slide)")
    print(f"  clock: intro {mins.get('intro', 0):.0f} min, teaching {mins.get('content', 0):.0f}, "
          f"transition {mins.get('transition', 0):.0f}, first ask at "
          f"{(starts[first_ask] if first_ask is not None else 0):.0f}, {total:.0f} in all, {len(slides)} slides")
    if holes:
        print(f"  to gather before going live ({len(holes)}):")
        for h in holes:
            print("    " + h)
    print("  wrote run-of-show.md, and notes.md: now run scripts/check.py on notes.md")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
