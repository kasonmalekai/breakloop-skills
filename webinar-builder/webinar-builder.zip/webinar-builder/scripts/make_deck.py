#!/usr/bin/env python3
"""Build the webinar deck: an editable PowerPoint file and preview images of every slide.

Usage:
    python3 scripts/make_deck.py deck.json --out deck

Writes deck/deck.pptx (open it in PowerPoint, Keynote or Google Slides; the speaker notes hold
what to say), deck/preview/slide-01.png ... and deck/preview/contact-1.png (every slide, small,
to look over at once). Text that won't fit at the smallest readable size stops with FIX and the
slide number, so split the slide or cut words.

The PowerPoint file is written with Python's standard library alone. The previews need Pillow,
and use the Inter font in assets/fonts (SIL Open Font License); the deck itself is set in Arial
unless brand.font says otherwise, so it looks the same on any computer.

deck.json: see references/slides.md for every slide type and field.
"""
import argparse
import json
import os
import sys
import zipfile
from xml.sax.saxutils import escape

W, H = 1920, 1080             # the canvas, in preview pixels (16:9)
EMU = 6350                    # EMU per preview pixel: 12192000 / 1920
PX_PER_PT = 2                 # 1920 px across 13.333 in = 144 px an inch = 2 px a point
M = 128                       # side margin
HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "..", "assets", "fonts")
BOLD = os.path.join(FONTS, "Inter-Bold.ttf")
MED = os.path.join(FONTS, "Inter-Medium.ttf")
INK, MUTED, WASH, FIELD, HAIR = "#0B0B0C", "#6B6B70", "#F1F1F3", "#FFFFFF", "#D9D9DE"

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:  # the deck still builds; only the previews need Pillow
    Image = None


class TooLong(Exception):
    pass


# ---------------------------------------------------------------- measuring and fitting text

_font_cache = {}


def pil_font(bold, pt):
    key = (bold, pt)
    if key not in _font_cache:
        _font_cache[key] = ImageFont.truetype(BOLD if bold else MED, int(pt * PX_PER_PT))
    return _font_cache[key]


def text_w(s, bold, pt):
    if Image is None:  # a rough width when Pillow is missing: wide enough to stay safe
        return len(s) * pt * PX_PER_PT * (0.6 if bold else 0.56)
    return pil_font(bold, pt).getlength(s)


def wrap(text, width, bold, pt):
    lines = []
    for para in str(text).split("\n"):
        cur, start = "", len(lines)
        for w in para.split():
            test = (cur + " " + w).strip()
            if text_w(test, bold, pt) <= width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = w
        lines.append(cur)
        if len(lines) - start >= 2 and len(lines[-1].split()) == 1 and len(lines[-2].split()) >= 3:
            prev = lines[-2].split()
            joined = prev[-1] + " " + lines[-1]
            if text_w(joined, bold, pt) <= width:
                lines[-2], lines[-1] = " ".join(prev[:-1]), joined
    return lines


def fit(text, width, height, max_pt, min_pt, bold=False, spacing=1.15):
    pt = max_pt
    while pt >= min_pt:
        lines = wrap(text, width, bold, pt)
        if len(lines) * pt * PX_PER_PT * spacing <= height and all(text_w(l, bold, pt) <= width for l in lines):
            return pt, lines
        pt -= 2
    raise TooLong


def th(lines, pt, spacing):
    return int(len(lines) * pt * PX_PER_PT * spacing)


# ---------------------------------------------------------------- layout: one list of elements per slide

def T(x, y, w, h, text, pt, color, bold=False, align="l", spacing=1.15, lines=None):
    return {"k": "text", "box": (x, y, w, h), "text": text, "pt": pt, "color": color, "bold": bold,
            "align": align, "spacing": spacing, "lines": lines or wrap(text, w, bold, pt)}


def R(x, y, w, h, fill=None, line=None, radius=0, dash=False):
    return {"k": "rect", "box": (x, y, w, h), "fill": fill, "line": line, "radius": radius, "dash": dash}


def block(x, y, w, room, parts, align="l", bias=0.42):
    """Stack text parts vertically, centred in the room (a little above the middle)."""
    total = sum(th(p["lines"], p["pt"], p["sp"]) + p.get("gap", 0) for p in parts)
    cy = y + max(0, int((room - total) * bias))
    out = []
    for p in parts:
        h = th(p["lines"], p["pt"], p["sp"])
        out.append(T(x, cy, w, h, p["text"], p["pt"], p["color"], p.get("bold", False), align, p["sp"], p["lines"]))
        cy += h + p.get("gap", 0)
    return out


def part(text, width, height, max_pt, min_pt, color, bold=False, sp=1.15, gap=0):
    pt, lines = fit(text, width, height, max_pt, min_pt, bold, sp)
    return {"text": text, "pt": pt, "lines": lines, "color": color, "bold": bold, "sp": sp, "gap": gap}


def layout(s, brand, footer_link):
    acc, dark = brand["accent"], brand["dark"]
    t = s.get("type")
    els, bg = [], FIELD
    full = W - 2 * M
    if t == "title":
        if s.get("eyebrow"):
            els.append(T(M, 120, full, 60, s["eyebrow"], 28, acc, True))
        parts = [part(s["title"], full, 470, 80, 48, INK, True, 1.06, 36)]
        if s.get("sub"):
            parts.append(part(s["sub"], full * 0.85, 200, 36, 26, MUTED, False, 1.25))
        els += block(M, 230, full, 640, parts)
        if s.get("presenter"):
            els.append(T(M, H - 150, full, 50, s["presenter"], 26, INK, True))
    elif t == "statement":
        parts = [part(s["text"], full, 640, 64, 44, INK, True, 1.08, 40)]
        if s.get("sub"):
            parts.append(part(s["sub"], full * 0.85, 220, 32, 24, MUTED, False, 1.25))
        els += block(M, 100, full, 820, parts, bias=0.5)
    elif t == "section":
        bg = dark
        parts = []
        if s.get("eyebrow"):
            parts.append(part(s["eyebrow"], full, 80, 30, 24, acc_on_dark(acc), True, 1.2, 28))
        parts.append(part(s["title"], full, 520, 72, 48, FIELD, True, 1.06))
        els += block(M, 120, full, 820, parts)
    elif t == "map":
        steps = s["steps"]
        cur = int(s.get("current", 0))
        if s.get("title"):
            els.append(T(M, 110, full, 70, s["title"], 36, INK, True))
        n, gap = len(steps), 28
        bw = (full - gap * (n - 1)) / n
        y0, bh = 300, 380
        for i, name in enumerate(steps, 1):
            x = M + (i - 1) * (bw + gap)
            if cur and i < cur:
                fill, line, tc, nc = WASH, None, MUTED, MUTED
            elif i == cur:
                fill, line, tc, nc = acc, None, FIELD, FIELD
            else:
                fill, line, tc, nc = FIELD, INK, INK, acc
            els.append(R(x, y0, bw, bh, fill, line, 18))
            els.append(T(x + 32, y0 + 34, bw - 64, 70, f"{i:02d}", 32, nc, True))
            room = bh - 210 if (cur and i < cur) else bh - 150  # leave space for "done"
            pt, lines = fit(name, bw - 64, room, 34, 22, True, 1.15)
            els.append(T(x + 32, y0 + 120, bw - 64, room, name, pt, tc, True, "l", 1.15, lines))
            if cur and i < cur:
                els.append(T(x + 32, y0 + bh - 70, bw - 64, 40, "done", 22, MUTED))
        if s.get("caption"):
            pt, lines = fit(s["caption"], full, 140, 30, 24, False, 1.25)
            els.append(T(M, y0 + bh + 60, full, 140, s["caption"], pt, MUTED, False, "l", 1.25, lines))
    elif t == "list":
        title = part(s["title"], full, 200, 52, 36, INK, True, 1.08)
        els.append(T(M, 110, full, th(title["lines"], title["pt"], 1.08), s["title"], title["pt"], INK, True, "l", 1.08, title["lines"]))
        items = s["items"]
        if not 1 <= len(items) <= 5:
            raise TooLong
        top = 110 + th(title["lines"], title["pt"], 1.08) + 70
        room = H - top - 150
        pt = 36
        while pt >= 26:
            wrapped = [wrap(it, full - 100, False, pt) for it in items]
            total = sum(th(w, pt, 1.25) for w in wrapped) + 40 * (len(items) - 1)
            if total <= room:
                break
            pt -= 2
        else:
            raise TooLong
        y = top
        for i, (it, w) in enumerate(zip(items, wrapped), 1):
            els.append(T(M, y, 80, pt * 2, str(i), pt, acc, True))
            h = th(w, pt, 1.25)
            els.append(T(M + 100, y, full - 100, h, it, pt, INK, False, "l", 1.25, w))
            y += h + 40
    elif t == "number":
        parts = [part(s["number"], full, 260, 100, 64, acc, True, 1.0, 30),
                 part(s["label"], full, 300, 44, 28, INK, True, 1.12, 22)]
        if s.get("qualifier"):
            parts.append(part(s["qualifier"], full, 120, 26, 24, MUTED, False, 1.2))
        els += block(M, 120, full, 820, parts)
    elif t == "quote":
        parts = [part("“" + s["quote"] + "”", full, 520, 44, 28, INK, True, 1.18, 40),
                 part(s["name"], full, 60, 30, 24, INK, True, 1.2, 10)]
        if s.get("detail"):
            parts.append(part(s["detail"], full, 120, 26, 24, MUTED, False, 1.2))
        els += block(M, 120, full, 820, parts)
    elif t == "compare":
        title = part(s["title"], full, 140, 48, 34, INK, True, 1.08)
        els.append(T(M, 110, full, th(title["lines"], title["pt"], 1.08), s["title"], title["pt"], INK, True, "l", 1.08, title["lines"]))
        top = 110 + th(title["lines"], title["pt"], 1.08) + 70
        colw = (full - 120) / 2
        hpt, _ = fit(max((s["left"], s["right"]), key=len), colw, 140, 32, 24, True, 1.15)
        head_h = max(th(wrap(h_, colw, True, hpt), hpt, 1.15) for h_ in (s["left"], s["right"]))
        for ci, (head, items, hc) in enumerate(((s["left"], s["left_items"], MUTED), (s["right"], s["right_items"], acc))):
            x = M + ci * (colw + 120)
            els.append(T(x, top, colw, head_h, head, hpt, hc, True, "l", 1.15))
            pt = 32
            while pt >= 24:
                wrapped = [wrap(it, colw, False, pt) for it in items]
                if sum(th(w, pt, 1.25) for w in wrapped) + 30 * (len(items) - 1) <= H - top - 210 - head_h:
                    break
                pt -= 2
            else:
                raise TooLong
            y = top + head_h + 34
            for it, w in zip(items, wrapped):
                h = th(w, pt, 1.25)
                els.append(T(x, y, colw, h, it, pt, INK, False, "l", 1.25, w))
                y += h + 30
        els.append(R(M + colw + 59, top, 2, H - top - 200, HAIR))
    elif t == "asset":
        els.append(R(M, 120, full, 640, WASH, MUTED, 12, True))
        pt, lines = fit("[ASSET NEEDED: " + s["needed"] + "]", full - 160, 520, 32, 24, True, 1.2)
        hh = th(lines, pt, 1.2)
        els.append(T(M + 80, 120 + (640 - hh) // 2, full - 160, hh, "[ASSET NEEDED: " + s["needed"] + "]", pt, MUTED, True, "c", 1.2, lines))
        if s.get("caption"):
            pt, lines = fit(s["caption"], full, 140, 34, 24, True, 1.2)
            els.append(T(M, 800, full, 140, s["caption"], pt, INK, True, "l", 1.2, lines))
    elif t == "prompt":
        els.append(R(M, 250, full, 460, WASH, None, 36))
        pt, lines = fit(s["prompt"], full - 160, 360, 60, 40, True, 1.1)
        hh = th(lines, pt, 1.1)
        els.append(T(M + 80, 250 + (460 - hh) // 2, full - 160, hh, s["prompt"], pt, INK, True, "l", 1.1, lines))
        if s.get("sub"):
            pt, lines = fit(s["sub"], full, 160, 32, 24, False, 1.25)
            els.append(T(M, 770, full, 160, s["sub"], pt, MUTED, False, "l", 1.25, lines))
    elif t == "cta":
        parts = [part(s["title"], full, 300, 64, 44, INK, True, 1.06, 30),
                 part(s["link"], full, 120, 48, 32, acc, True, 1.1, 40)]
        for it in s.get("items", [])[:4]:
            parts.append(part(it, full, 120, 30, 24, MUTED, False, 1.25, 14))
        els += block(M, 110, full, 840, parts)
    else:
        raise KeyError(f'type "{t}"')
    if bg == FIELD and t != "title" and brand.get("name"):
        els.append(R(M, H - 78, 28, 6, acc))
        els.append(T(M + 44, H - 92, full / 2, 40, brand["name"], 20, MUTED, True))
    if footer_link and t != "cta":
        color = acc_on_dark(acc) if bg != FIELD else acc
        els.append(T(M, H - 92, full, 40, footer_link, 22, color, True, "r"))
    return bg, els


def acc_on_dark(acc):
    """The accent if it reads on the dark slides, otherwise a light grey."""
    r, g, b = (int(acc[i:i + 2], 16) for i in (1, 3, 5))
    return acc if (0.299 * r + 0.587 * g + 0.114 * b) > 110 else "#C8C8CE"


# ---------------------------------------------------------------- the preview images

def draw_preview(bg, els):
    img = Image.new("RGB", (W, H), bg)
    d = ImageDraw.Draw(img)
    for e in els:
        x, y, w, h = (int(v) for v in e["box"])
        if e["k"] == "rect":
            if e["dash"]:
                d.rounded_rectangle((x, y, x + w, y + h), radius=e["radius"], fill=e["fill"])
                for i in range(x, x + w, 28):
                    d.line((i, y, min(i + 14, x + w), y), fill=e["line"], width=3)
                    d.line((i, y + h, min(i + 14, x + w), y + h), fill=e["line"], width=3)
                for j in range(y, y + h, 28):
                    d.line((x, j, x, min(j + 14, y + h)), fill=e["line"], width=3)
                    d.line((x + w, j, x + w, min(j + 14, y + h)), fill=e["line"], width=3)
            else:
                d.rounded_rectangle((x, y, x + w, y + h), radius=e["radius"], fill=e["fill"],
                                    outline=e["line"], width=4 if e["line"] else 0)
        else:
            f = pil_font(e["bold"], e["pt"])
            step = int(e["pt"] * PX_PER_PT * e["spacing"])
            cy = y
            for line in e["lines"]:
                lw = f.getlength(line)
                lx = x if e["align"] == "l" else (x + (w - lw) / 2 if e["align"] == "c" else x + w - lw)
                d.text((lx, cy), line, font=f, fill=e["color"])
                cy += step
    return img


# ---------------------------------------------------------------- the PowerPoint file

NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"')
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
CT = "application/vnd.openxmlformats-officedocument.presentationml."
GRP = ('<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm>'
       '<a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>')


def hexv(c):
    return c.lstrip("#").upper()


def rels(items):
    body = "".join(f'<Relationship Id="{i}" Type="{t}" Target="{escape(g)}"/>' for i, t, g in items)
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{body}</Relationships>')


def theme(font):
    acc = "".join(f'<a:accent{i}><a:srgbClr val="{v}"/></a:accent{i}>' for i, v in
                  enumerate(("0B0B0C", "6B6B70", "9A7426", "3D3D42", "77777E", "BA5945"), 1))
    solid = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Webinar"><a:themeElements>'
            '<a:clrScheme name="Webinar"><a:dk1><a:srgbClr val="0B0B0C"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1>'
            '<a:dk2><a:srgbClr val="3D3D42"/></a:dk2><a:lt2><a:srgbClr val="F1F1F3"/></a:lt2>' + acc +
            '<a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>'
            f'<a:fontScheme name="Webinar"><a:majorFont><a:latin typeface="{escape(font)}"/><a:ea typeface=""/><a:cs typeface=""/>'
            f'</a:majorFont><a:minorFont><a:latin typeface="{escape(font)}"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont>'
            '</a:fontScheme><a:fmtScheme name="Webinar"><a:fillStyleLst>' + solid * 3 + '</a:fillStyleLst><a:lnStyleLst>' +
            ('<a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>' * 3) +
            '</a:lnStyleLst><a:effectStyleLst>' + ('<a:effectStyle><a:effectLst/></a:effectStyle>' * 3) +
            '</a:effectStyleLst><a:bgFillStyleLst>' + solid * 3 + '</a:bgFillStyleLst></a:fmtScheme></a:themeElements>'
            '<a:objectDefaults/><a:extraClrSchemeLst/></a:theme>')


CLRMAP = ('<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" '
          'accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>')


def sp_xml(e, sid, font):
    x, y, w, h = (int(round(v * EMU)) for v in e["box"])
    xfrm = f'<a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{max(w, EMU)}" cy="{max(h, EMU)}"/></a:xfrm>'
    if e["k"] == "rect":
        geom = "roundRect" if e["radius"] else "rect"
        av = (f'<a:avLst><a:gd name="adj" fmla="val {int(min(50000, e["radius"] * 100000 / max(1, min(e["box"][2], e["box"][3]))))}"/></a:avLst>'
              if e["radius"] else "<a:avLst/>")
        fill = f'<a:solidFill><a:srgbClr val="{hexv(e["fill"])}"/></a:solidFill>' if e["fill"] else "<a:noFill/>"
        if e["line"]:
            dash = '<a:prstDash val="dash"/>' if e["dash"] else ""
            line = f'<a:ln w="25400"><a:solidFill><a:srgbClr val="{hexv(e["line"])}"/></a:solidFill>{dash}</a:ln>'
        else:
            line = "<a:ln><a:noFill/></a:ln>"
        return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="Shape {sid}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
                f'<p:spPr>{xfrm}<a:prstGeom prst="{geom}">{av}</a:prstGeom>{fill}{line}</p:spPr></p:sp>')
    algn = {"l": "l", "c": "ctr", "r": "r"}[e["align"]]
    paras = []
    for para in str(e["text"]).split("\n"):
        run = (f'<a:r><a:rPr lang="en-US" sz="{int(e["pt"] * 100)}" b="{1 if e["bold"] else 0}" dirty="0">'
               f'<a:solidFill><a:srgbClr val="{hexv(e["color"])}"/></a:solidFill><a:latin typeface="{escape(font)}"/>'
               f'</a:rPr><a:t>{escape(para)}</a:t></a:r>')
        paras.append(f'<a:p><a:pPr algn="{algn}"><a:lnSpc><a:spcPct val="{int(e["spacing"] * 90000)}"/></a:lnSpc></a:pPr>{run}</a:p>')
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="Text {sid}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr>{xfrm}<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            '<p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:noAutofit/></a:bodyPr>'
            f'<a:lstStyle/>{"".join(paras)}</p:txBody></p:sp>')


def notes_xml(lines):
    paras = "".join(f'<a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>{escape(l)}</a:t></a:r></a:p>' for l in lines) or \
        '<a:p><a:endParaRPr lang="en-US"/></a:p>'
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<p:notes {NS}><p:cSld><p:spTree>{GRP}'
            '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/>'
            '</p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr><p:spPr/></p:sp>'
            '<p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
            '<p:nvPr><p:ph type="body" idx="3"/></p:nvPr></p:nvSpPr><p:spPr/>'
            f'<p:txBody><a:bodyPr/><a:lstStyle/>{paras}</p:txBody></p:sp>'
            '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>')


def notes_lines(s):
    n = s.get("notes") or {}
    out = []
    for key, label in (("job", "Job"), ("say", "Say"), ("interaction", "Chat"), ("objection", "Objection handled"),
                       ("proof", "Proof"), ("next", "Into the next slide")):
        if n.get(key):
            out.append(f"{label}: {n[key]}")
    tag = [x for x in (s.get("block"), f'step {s["step"]}' if s.get("step") else None, s.get("beat")) if x]
    said = len(str(n.get("say", "")).split())
    mins = said / 140 + (0.5 if (n.get("interaction") or s.get("type") == "prompt" or s.get("commitment")) else 0) + \
        float(s.get("extra") or 0)
    if tag:
        out.append(f'[{", ".join(tag)}, about {mins:.1f} min]')
    return out


def write_pptx(path, slides_xml, notes, title, font):
    n = len(slides_xml)
    master = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              f'<p:sldMaster {NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>'
              f'<p:spTree>{GRP}</p:spTree></p:cSld>{CLRMAP}'
              '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
              '<p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz="4400"/></a:lvl1pPr></p:titleStyle>'
              '<p:bodyStyle><a:lvl1pPr><a:defRPr sz="2800"/></a:lvl1pPr></p:bodyStyle>'
              '<p:otherStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>')
    layout_x = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                f'<p:sldLayout {NS} type="blank" preserve="1"><p:cSld name="Blank"><p:spTree>{GRP}</p:spTree></p:cSld>'
                '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>')
    nmaster = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               f'<p:notesMaster {NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>'
               f'<p:spTree>{GRP}'
               '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/>'
               '</p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="381000" y="685800"/>'
               '<a:ext cx="6096000" cy="3429000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr></p:sp>'
               '<p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
               '<p:nvPr><p:ph type="body" sz="quarter" idx="3"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="4343400"/>'
               '<a:ext cx="5486400" cy="4114800"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>'
               '<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>'
               f'</p:spTree></p:cSld>{CLRMAP}<p:notesStyle><a:lvl1pPr><a:defRPr sz="1200"/></a:lvl1pPr></p:notesStyle></p:notesMaster>')
    pres = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<p:presentation {NS} saveSubsetFonts="1">'
            '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
            '<p:notesMasterIdLst><p:notesMasterId r:id="rId2"/></p:notesMasterIdLst><p:sldIdLst>' +
            "".join(f'<p:sldId id="{256 + i}" r:id="rId{10 + i}"/>' for i in range(n)) +
            '</p:sldIdLst><p:sldSz cx="12192000" cy="6858000"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>')
    pres_rels = rels([("rId1", REL + "slideMaster", "slideMasters/slideMaster1.xml"),
                      ("rId2", REL + "notesMaster", "notesMasters/notesMaster1.xml"),
                      ("rId3", REL + "theme", "theme/theme1.xml"),
                      ("rId4", REL + "presProps", "presProps.xml"),
                      ("rId5", REL + "viewProps", "viewProps.xml"),
                      ("rId6", REL + "tableStyles", "tableStyles.xml")] +
                     [(f"rId{10 + i}", REL + "slide", f"slides/slide{i + 1}.xml") for i in range(n)])
    types = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
             '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
             '<Default Extension="xml" ContentType="application/xml"/>'
             f'<Override PartName="/ppt/presentation.xml" ContentType="{CT}presentation.main+xml"/>'
             f'<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="{CT}slideMaster+xml"/>'
             f'<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="{CT}slideLayout+xml"/>'
             f'<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="{CT}notesMaster+xml"/>'
             '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
             '<Override PartName="/ppt/theme/theme2.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
             f'<Override PartName="/ppt/presProps.xml" ContentType="{CT}presProps+xml"/>'
             f'<Override PartName="/ppt/viewProps.xml" ContentType="{CT}viewProps+xml"/>'
             f'<Override PartName="/ppt/tableStyles.xml" ContentType="{CT}tableStyles+xml"/>'
             '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
             '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>' +
             "".join(f'<Override PartName="/ppt/slides/slide{i + 1}.xml" ContentType="{CT}slide+xml"/>'
                     f'<Override PartName="/ppt/notesSlides/notesSlide{i + 1}.xml" ContentType="{CT}notesSlide+xml"/>'
                     for i in range(n)) + '</Types>')
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{escape(title)}</dc:title><dc:creator>Breakloop webinar builder</dc:creator></cp:coreProperties>')
    app = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
           f'<Application>Breakloop webinar builder</Application><Slides>{n}</Slides></Properties>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", types)
        z.writestr("_rels/.rels", rels([("rId1", REL + "officeDocument", "ppt/presentation.xml"),
                                        ("rId2", "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml"),
                                        ("rId3", REL + "extended-properties", "docProps/app.xml")]))
        z.writestr("docProps/core.xml", core)
        z.writestr("docProps/app.xml", app)
        z.writestr("ppt/presentation.xml", pres)
        z.writestr("ppt/_rels/presentation.xml.rels", pres_rels)
        z.writestr("ppt/presProps.xml", f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentationPr {NS}/>')
        z.writestr("ppt/viewProps.xml", f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:viewPr {NS}>'
                   '<p:normalViewPr><p:restoredLeft sz="15620"/><p:restoredTop sz="80000"/></p:normalViewPr></p:viewPr>')
        z.writestr("ppt/tableStyles.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                   'def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>')
        z.writestr("ppt/theme/theme1.xml", theme(font))
        z.writestr("ppt/theme/theme2.xml", theme(font))
        z.writestr("ppt/slideMasters/slideMaster1.xml", master)
        z.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels",
                   rels([("rId1", REL + "slideLayout", "../slideLayouts/slideLayout1.xml"), ("rId2", REL + "theme", "../theme/theme1.xml")]))
        z.writestr("ppt/slideLayouts/slideLayout1.xml", layout_x)
        z.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels([("rId1", REL + "slideMaster", "../slideMasters/slideMaster1.xml")]))
        z.writestr("ppt/notesMasters/notesMaster1.xml", nmaster)
        z.writestr("ppt/notesMasters/_rels/notesMaster1.xml.rels", rels([("rId1", REL + "theme", "../theme/theme2.xml")]))
        for i, (sx, nl) in enumerate(zip(slides_xml, notes), 1):
            z.writestr(f"ppt/slides/slide{i}.xml", sx)
            z.writestr(f"ppt/slides/_rels/slide{i}.xml.rels",
                       rels([("rId1", REL + "slideLayout", "../slideLayouts/slideLayout1.xml"),
                             ("rId2", REL + "notesSlide", f"../notesSlides/notesSlide{i}.xml")]))
            z.writestr(f"ppt/notesSlides/notesSlide{i}.xml", notes_xml(nl))
            z.writestr(f"ppt/notesSlides/_rels/notesSlide{i}.xml.rels",
                       rels([("rId1", REL + "notesMaster", "../notesMasters/notesMaster1.xml"),
                             ("rId2", REL + "slide", f"../slides/slide{i}.xml")]))


def slide_xml(bg, els, font):
    bgx = "" if bg == FIELD else (f'<p:bg><p:bgPr><a:solidFill><a:srgbClr val="{hexv(bg)}"/></a:solidFill>'
                                  '<a:effectLst/></p:bgPr></p:bg>')
    shapes = "".join(sp_xml(e, i + 2, font) for i, e in enumerate(els))
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<p:sld {NS}><p:cSld>{bgx}<p:spTree>{GRP}{shapes}</p:spTree></p:cSld>'
            '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>')


def hex_ok(c, default):
    c = str(c or "").strip()
    if len(c) == 4 and c.startswith("#"):
        c = "#" + "".join(ch * 2 for ch in c[1:])
    return c.upper() if len(c) == 7 and c.startswith("#") else default


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("--out", default="deck")
    a = ap.parse_args()
    spec = json.load(open(a.spec, encoding="utf-8"))
    b = spec.get("brand", {})
    brand = {"accent": hex_ok(b.get("accent"), INK), "dark": hex_ok(b.get("dark"), INK), "font": b.get("font") or "Arial",
             "name": b.get("name", "")}
    link = spec.get("link", "")
    os.makedirs(os.path.join(a.out, "preview"), exist_ok=True)
    for old in os.listdir(os.path.join(a.out, "preview")):  # no leftovers from an earlier, longer build
        if old.endswith(".png"):
            os.remove(os.path.join(a.out, "preview", old))
    slides, notes, previews, problems = [], [], [], []
    asked = False
    for n, s in enumerate(spec.get("slides", []), 1):
        try:
            bg, els = layout(s, brand, link if asked else "")
        except TooLong:
            problems.append(f"slide {n} ({s.get('type')}): the words don't fit at a readable size; cut them or split the slide")
            continue
        except KeyError as e:
            problems.append(f"slide {n}: missing or unknown {e}")
            continue
        if s.get("ask"):
            asked = True
        slides.append(slide_xml(bg, els, brand["font"]))
        notes.append(notes_lines(s))
        if Image is not None:
            img = draw_preview(bg, els)
            p = os.path.join(a.out, "preview", f"slide-{n:02d}.png")
            img.resize((960, 540)).save(p)
            previews.append(img)
    for p in problems:
        print("FIX", p)
    if problems:
        sys.exit(1)
    title = spec.get("title") or "Webinar"
    write_pptx(os.path.join(a.out, "deck.pptx"), slides, notes, title, brand["font"])
    if previews:
        per, cols, tw, thh = 30, 5, 384, 216
        for k in range(0, len(previews), per):
            chunk = previews[k:k + per]
            rows = (len(chunk) + cols - 1) // cols
            sheet = Image.new("RGB", (cols * tw + (cols + 1) * 16, rows * thh + (rows + 1) * 16), "#CFCFD4")
            for i, im in enumerate(chunk):
                sheet.paste(im.resize((tw, thh)), (16 + (i % cols) * (tw + 16), 16 + (i // cols) * (thh + 16)))
            sheet.save(os.path.join(a.out, "preview", f"contact-{k // per + 1}.png"))
    print(f"made {os.path.join(a.out, 'deck.pptx')} with {len(slides)} slides"
          + (f", previews in {os.path.join(a.out, 'preview')}" if previews else " (no previews: Pillow is missing)"))


if __name__ == "__main__":
    main()
