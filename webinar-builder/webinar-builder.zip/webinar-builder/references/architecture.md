# How a webinar that books calls is built

Every line below describes a move. None of it is wording to copy. Build every slide from the coach's own material, in their words.

## The clock
| Part | Its job | About |
|---|---|---|
| The introduction | Win the room and start the sale before any teaching | 10 minutes |
| The teaching | Change what they believe they can do, and let them see what they don't have yet | 35 to 40 minutes |
| The transition | Move the room from learning to wanting help | 3 to 6 minutes |
| The close | Offer the call (never a price) | 10 to 15 minutes |
| Q&A | The second chance to book: every answer bends back to the call | as long as it books |

The call is first asked for at 45 to 50 minutes. If time runs short, cut teaching, never the close.

## Four threads that run the whole way
- **Commitment:** small yeses all the way. One typed commitment in the chat by minute 5, worded around the call (they'll watch as the person who'd do this, and take the next step if it fits). A small honest commitment after each step. Booking is then the promise kept.
- **Proof:** the same person comes back. A glimpse in the introduction that raises a question, more of their story in the teaching, the payoff in the close. Each return adds something new from what the coach told you (where they started, the turning point, what changed); if there's nothing new to add, don't bring them back.
- **Doubts:** named lightly in the introduction, kept under pressure in the teaching, finished in the close.
- **Open loops:** things promised early and paid off later, and the gift for staying to the end, announced early and revealed after the ask.

## The introduction: five jobs in about 10 minutes
1. **Why this person:** a real result (their best and a recent one), and where they stand against what this room already knows.
2. **The commitment,** typed in the chat by minute 5.
3. **The doubts, named early:** assume time and money, add one or two that would distract if left unsaid. Handle each one of three ways: **ignore** it (small ones only), **disagree** (acknowledge it, reframe it, and tell them what to watch for as proof), or **agree** (agree, narrow it down, prove it, and give them a target). Telling a doubter what to watch for is the part most people miss.
4. **Hope:** people arrive privately doubting it'll work for them. Show them the other side, let them sit in it, and tie today to it.
5. **What's coming:** name what they'll get today with the how held back, and announce the gift for staying to the end.

For a room that's never heard of the coach, all five start from the first slide.

## The teaching
- **The outcome** is who it's for, the feeling, and the result, and it has to be reachable in about 40 minutes of teaching. Say it out loud.
- **One path.** People want one clear way through, not four options. Teach one.
- **3 to 5 steps on one map.** Show the whole map before step 1, and bring it back after every step with that step marked done. Those return visits are where the gift gets a reminder.
- **Step 1 takes 30 to 35% of the teaching time.** A room lost on step 1 stays lost.
- **Every step has four beats, in this order where you can:**
  - **Context:** why this step decides the result, and what it involves.
  - **Vision:** they see their own week **after** mastering it (a moment from a client's life after, the coach's own after). The pain belongs in context; vision is the other side.
  - **Strategy:** the how, either as steps inside the step, or as the things that must be true. One or the other.
  - **Commitment:** understanding turns into a stated intention: one small decision they can honestly agree to.
- **Write the teaching backward from the call.** For each step, name the part that's slow or hard alone, say what it really costs, get agreement it's worth doing, and let the close offer the shortcut. Plant only true gaps, and never hold back what the slide promised.
- **A gap is what's beyond the teaching,** never the teaching itself: if the step's how just showed them how to do it, that isn't a gap. The gap is the part that needs their own numbers looked at, the results tied together, or knowing which fix moves the number. Teach on the funnel the room runs today, not the one they'd have after the call.
- **Each vision is its own scene:** a different moment from the hope in the introduction and from the other steps.
- **The last step unlocks the earlier ones,** so the steps read as one system, and that's where the gap to the call shows.
- **Fear goes on doing nothing,** never on the method. If the room applauds but nobody books, the teaching entertained instead of moving them.

## The transition
A short part of its own, between the last step and the close:
1. **A fast recap:** the best things they now have, in a few quick slides, energy rising.
2. **One honest question:** would they like to go further, with help? (Skip the string of staged yeses: experienced buyers can tell.) This question is also the permission for the close, so the close doesn't ask for a second yes.
3. **An honest frame:** one session rarely changes how anyone works, so say what usually happens next.
4. **Name the next step:** the call.

## The locks, before any slide
- **Source:** everything comes from what the coach gave. What's missing is listed, not guessed.
- **Belief:** the numbered beliefs a buyer must hold before booking, and the one idea.
- **Proof:** each result with its qualifier, its time span, and one job, never merged. "Contracted", "about", "reported" stay attached wherever it's restated.
- **Claims:** a short list of what's never said for this offer.
- **Gaps:** anything missing becomes a visible `[ASSET NEEDED: ...]` or `[CONFIRM: ...]`.

## What proof is for
Each proof slide does one job: the problem is real, the method works, the process is real, the coach is credible, a client got there, it works in this market, or the risk is managed. Most decks only have client proof; the process and market proof is what a skeptical buyer wants.
