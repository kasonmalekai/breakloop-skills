# The slides and deck.json

## Slide rules
- **One job per slide,** understood in about 3 seconds.
- **Big words, few of them:** a statement slide holds 16 words at most, a list 2 to 5 lines of 14 words at most. Never shrink text to fit: add a slide.
- **Fast slides** for hooks, reframes, the cost and the doubts. **Slow slides** for stories, proof and walkthroughs.
- **No stock photos, no decorative icons.** Where a real screenshot or photo belongs, use an `asset` slide that says exactly what to put there.
- **Section slides are dark,** everything else light.

## deck.json
```json
{
  "title": "the webinar's name",
  "brand": {"name": "the coach's name", "accent": "#hex", "dark": "#hex, optional", "font": "optional, Arial by default"},
  "link": "their booking link",
  "plan": {
    "outcome": {"audience": "who", "feeling": "how they'll feel", "result": "what they'll be able to do"},
    "central_idea": "the one idea, one sentence",
    "beliefs": ["what they must believe before booking, numbered in order"],
    "steps": ["step 1 name", "step 2 name", "step 3 name"],
    "gaps": [{"teaching": "the part that's slow or hard alone", "call": "what the call gives them for it"}],
    "objections": [{"name": "the doubt, in their words", "treatment": "ignore | disagree | agree", "answers": ["two answers"]}],
    "proof": [{"who": "label", "start": "where they began", "result": "what changed", "span": "over how long", "qualifier": "e.g. results vary", "job": "which job this proof does", "public_wording": "the line exactly as they share it, if they gave one"}],
    "magnet": "the gift for staying to the end",
    "not_for": "who it isn't for",
    "banned": ["what's never claimed"],
    "live": "true or false, only if they said; leave it out otherwise"
  },
  "slides": [ ... ]
}
```

## Every slide
```json
{"type": "statement", "block": "intro | content | transition | close | qa", "extra": 0,
 "step": 1, "beat": "context | vision | strategy | commitment",
 "ask": false, "commitment": false, "magnet": "announce | remind | reveal", "objection": "the doubt it handles (the same words wherever that doubt comes up)",
 "testimonial": "the person, if it shows one", "not_for": false,
 "notes": {"job": "what this slide is for", "say": "what to say, in their voice",
           "interaction": "what to ask the chat", "objection": "the doubt handled", "proof": "the evidence and its qualifier",
           "next": "the line into the next slide"}}
```
`step` and `beat` go on teaching slides only. **The minutes come from the words:** each slide lasts as long as its `say` takes at about 140 words a minute, plus half a minute when the chat is asked something, plus `extra` minutes for anything played or demonstrated (a video, a screen walkthrough). So the run of show is honest: to ask for the call at 45 to 50 minutes, the notes before it hold roughly 5,500 to 6,500 words. Mark the first slide that asks for the call with `"ask": true` and every later ask too: from the first one, the booking link appears on every slide.

## The slide types and their fields
| type | fields | for |
|---|---|---|
| `title` | `eyebrow`, `title`, `sub`, `presenter` | the first slide |
| `statement` | `text`, `sub` | one big line: a hook, a reframe, a cost |
| `section` | `eyebrow`, `title` | a dark break: "step 2", a new part |
| `map` | `title`, `steps` (all of them, short names of 2 to 5 words), `current` (0 shows the whole map; 2 means step 1 is done and step 2 is next; one past the last step shows them all done), `caption` | the path, before step 1 and after every step |
| `list` | `title`, `items` (2 to 5) | steps inside a step, what comes with booking |
| `number` | `number`, `label`, `qualifier` | one real result; the qualifier is required |
| `quote` | `quote`, `name`, `detail` | a client's words, only if real |
| `compare` | `title`, `left`, `left_items`, `right`, `right_items` | the usual way against theirs |
| `asset` | `needed` (just what's needed: the deck adds the "ASSET NEEDED" label), `caption` | where a real screenshot, video or photo goes |
| `prompt` | `prompt`, `sub` | a question for the chat: the commitment, a check-in, the honest question |
| `cta` | `title`, `link`, `items` (up to 4) | the call: what it is, and what happens |
