# The close: offering the call

The webinar sells the call, not the program. The price, the package and the terms belong on the call, where they can be explained.

## In this order
1. **The bridge:** they'll be better off than when they arrived even if they do this alone, and help gets them there faster.
2. **Ask permission,** once: the transition's honest question already did this, so go straight on. If there was no such question, ask it here.
3. **Name the call:** who's on it, what happens on it, and what they leave with, even if they never buy. No numbers.
4. **It's free, and how long it takes:** say it, and make the first ask right here. Expect few to book on this one: it makes the later asks work.
5. **What comes with booking:** one thing at a time, each said as the problem, the thing, then "so you can..." and what they get. **Each gap planted in the teaching comes back here,** as what the call does about it. Save the best for near the end. **The gift for staying goes in the last slot,** revealed now, for the people still there.
6. **Take the risk out of the call:** what makes booking safe (they'll get something useful either way, no pressure, they can say no). Never invent a guarantee.
7. **Answer the doubts:** every doubt named in the introduction gets answered here, and nothing is answered here that the introduction never named (mark the slide with that doubt). An answer that's only a `[CONFIRM]` doesn't count. A money answer addresses the cost or the risk, never the proof again. A time answer can use what the coach says the client's side is ("you keep teaching, we...") with a `[CONFIRM]` if it describes the program. Start with money and time, then the specific ones. Two answers for each, built from the coach's own material (their numbers, their story, a client's result), never a deflection. Ask again after each one.
8. **Walk the booking page:** show the page, the questions it asks, and what happens after they book.
9. **Only real scarcity:** if call spots really run out, say how many and when. No countdown timers, no fake deadlines.

Then go round again: a doubt, the risk taken out, a question answered, the ask. Keep going while people are still there.

## The booking link
From the first ask on, the booking link is on every slide. (The deck does this for you once a slide is marked as the first ask.) Keep it short enough to say out loud.

## Q&A
Every answer bends back to the call and ends on the link. When someone asks for advice on their own situation, answer two, then say the call is where the rest gets looked at properly.

## Never
- Call people who don't book liars, or say "it's money or excuses".
- Tell anyone to borrow money or stretch to afford something.
- Disqualify anyone in the open chat. Say who it isn't for before the close, to the whole room.
