# Writing in their voice

The fastest way to lose a coach is to hand them posts that sound like a robot. Everything you write is said out loud by a real person, or read as if they said it.

## Build the voice card first
Before writing anything, pull their voice from their own material.
- **From a call or a video:** their own turns (never the buyer's). Copy the 8-12 lines that sound most like them into `voice.txt`, one per line, word for word, with only the filler sounds taken out ("um", "uh", false starts). Pick lines where they're explaining or telling something, at the length they usually talk in: not acknowledgements ("got it", "love it", "talk soon") and not their longest run-ons. The checker compares the posts against these lines, so they have to be typical.
- **From posts they pasted:** the captions and the spoken lines.
- Then note, in two or three lines: how long their sentences run, the words and phrases they repeat, how they start an explanation, the check-ins they use ("you know what I mean?", "make sense?"), and anything they'd never say.
- **List their 3-5 signature words or check-ins and roughly how often they use them** (once a minute, once a call). Use them in the posts at about the same rate, and the way they use them: in the same spot in the sentence they put them, never tacked onto the end of a line to hit a count. Don't polish them out, because they're what makes it sound like them, and don't pile them on so it reads like a parody.

If you have neither, ask for 3-5 of their posts. Don't guess a voice.

## How spoken lines read
- **Contractions everywhere:** you're, it's, don't, that's.
- **Sentences joined the way people talk:** with "so", "and", "because", "but", "now". Short sentences are fine. Headline fragments aren't. "Three steps." is printed on a slide, while "There are three steps, and the second one is where it breaks" is said.
- **No em dashes or en dashes, ever.** Use a period, a comma or "and".
- **Plain words, no metaphors standing in for the point.** Say the thing.
- **Their words for the buyer's pain**, taken from the call, not marketing words.
- **A check-in now and then,** if they use them. Don't overdo it.
- **Only what they actually said they did, felt or believed.** In their voice, never add a memory, a feeling, a turning point ("I thought...", "until I looked at...") or a detail about how they work that the material doesn't give. If a hook needs a belief they never stated, aim it at the buyer's situation instead.

## The tells that give it away
Never use these, in any post: delve, game-changer, unlock your, unleash, supercharge, revolutionize, elevate your, take it to the next level, embark, journey (as a metaphor), navigate the, testament, tapestry, landscape (as a metaphor), seamless, robust, cutting-edge, pivotal, crucial, foster, harness, leverage (as a verb), empower, holistic, synergy, realm, moreover, furthermore, additionally, in conclusion, "in today's fast-paced world", "let's dive in", "deep dive", "buckle up", "here's the kicker", "imagine a world", "picture this", "say goodbye to", "look no further", "whether you're a".

Also avoid the shapes: "It's not X, it's Y" more than once in a week; three adjectives in a row; a rhetorical question to open every post; ending every post on a one-word line.

## Before you show anything
Run the checker (`scripts/check.py`) and fix every failure it lists. Then read each reel's first two sentences alone. Is it obvious what the video is about, and is there a reason to keep watching? If not, rewrite those two sentences before anything else.
