# The business file

One small file the person keeps. Next time, they drop it in the chat and nothing gets asked twice. Every Breakloop skill reads it and adds to it.

## When to ask
Look in the chat first for a file called `my-business.md`. If it's there, read it and don't ask anything it already answers.

If it isn't there, ask **only what this task needs and the material can't tell you**, in one numbered message. These three come first; a skill adds its own when its output depends on more, and lists them in its steps:
1. Is this your own offer, or are you doing this for a client? (If a client, everything is written in the client's voice and about the client's offer.)
2. What do you sell, in one line, and who buys it?
3. Where do you post most (Instagram reels, carousels, LinkedIn, YouTube Shorts, TikTok)?

A sales call usually answers question 2 on its own. Never ask for revenue, prices or anything private. If they don't answer, make the sensible assumption, say it in one line, and carry on.

## What goes in it
Write it as a downloadable file called `my-business.md`, in this shape:

```
# my business
(keep this file. drop it into any Breakloop skill and it skips the questions)

whose offer: mine | a client's (who)
what I sell: <one line>
who buys it: <one line, in the buyer's own words where possible>
where I post: <platforms>
my call to action: <the one thing I ask people to do, e.g. "DM me the word X">
my proof line: <optional: one real result, worded exactly as I share it publicly, with its label>
my free thing: <optional: its name, and what people walk away with>
what the call gives them: <optional: one line>
what I do differently: <optional: one line, and my method's name>
who it isn't for: <optional: one line>

## how I talk
<two or three lines: sentence length, words I repeat, how I start an explanation, check-ins>
<5 lines I actually said, word for word>

## what my buyers keep asking
<questions found so far, newest first; add to this every run>
```

Add the new buyer questions every time a skill runs, so the file gets better with use.
