# Writing the reels

A reel is won or lost in its first two sentences. Spend most of the effort there.

Every line below describes a move. None of it is wording to copy. Build every sentence from the coach's own material and their own words. A line that could go in any coach's reel unchanged gets rewritten.

## The hook, three ways
Write three hook options for every reel, each a different kind:
- **The verdict:** the buyer's question turned into a straight answer about something the viewer owns.
- **The cost:** what it's costing the viewer right now (never the coach's own stake), said plainly, in a number from the material if there is one. A dollar figure always comes with what it's out of (the account, the month, the position).
- **The broken belief:** the thing they assume, named in their words and turned over.

Across the week's three reels, the three hooks you pick lead with three different kinds.

Every hook has three parts:
1. **Context in the first half of the first sentence.** Say what the video is about before anything else. If the topic only shows up at the end of the sentence, people swipe.
2. **The lean.** Something that pulls them one way: a real number from the material, a named pain or result, or something unexpected.
3. **The snapback.** Pull them the other way: the belief they hold, broken.

Put the strongest of the three in the script and list the other two above it.

## The lock-in, by about 5 seconds
The two or three sentences right after the hook keep the viewer. They say what this is costing them now, or what they want and aren't getting. **Sentences two and three never start the lesson:** no example, no "let's say", no number from a scenario, and no "because" explaining why it happens. They don't pivot either ("so here's...", "here's what...", "so look..."). They may restate the cost or raise the stakes, but they never give the reason. Instead they carry a concrete cost from the material: the minutes, the money, the buyers lost. The why comes once they're hooked, and it's said once, not repeated later in the script.

The same hook rules apply to a text post's first sentence and a carousel's slide 1.

## The script's shape
For a 30-60 second reel:
1. **The hook:** a verdict on something they own.
2. **The cost,** by about 5 seconds.
3. **The belief, broken,** in one line, then a promise of what's coming, with a count when the idea really has parts.
4. **The mechanism:** why it happens, said plainly.
5. **Their situation said back to them:** what they'll try next, and how that fails too.
6. **The fix, handed over** step by step, exactly as the coach gives it in the material.
7. **The last line of the idea:** the specific thing they'd repeat to a friend. Never a summary like "and that's the difference".
8. **The call to action:** their one door, from the business file. One ask only.

Under 45 seconds, keep 1, 2, 3, 6, 7 and 8. Past 30 seconds, give a new reason to stay every 10-15 seconds (a new number, the next step, a question answered), and hold one small payoff back for near the end.

## Moves to ration
- **"It isn't X, it's Y"** in any form ("you don't have an X problem", "X was never the problem", "you don't need X, you need Y", "you're not X, you're Y") is strong when it's rare. Use it twice a week at most, counting every form.
- **"Nobody checks the second one", "here's the thing", "the truth is", "the part nobody builds"** and similar stock lines are banned. Say the specific thing instead.
- **"A lot of coaches tell me" or "most people"** only if the coach said it. One call is one person.

## On-screen text
The text on screen in the first frame:
- names the subject plus one of these: a pain they feel now, the outcome they want, or a change ahead;
- uses a specific number only if it's real and in the material, never a made-up one;
- includes a short power phrase in the buyer's own words (one to three words);
- has no transition words (and, but, so) and no punctuation except quotes and parentheses;
- fits on two lines.

## The voice
Read `references/voice.md` and write every spoken line the way the coach talks in the material. Every spoken line starts with `> ` in `drafts.md`.

## In each reel's entry
Under its `## ` heading (for example `## Day 1, reel: <title>` or `## Version 1, reel: <title>`), give: what it answers, the three hooks (the pick marked), the on-screen text, the full script, the length in seconds, and one line on what to show on screen (face to camera, the screen, a whiteboard).
