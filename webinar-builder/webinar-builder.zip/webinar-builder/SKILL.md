---
name: webinar-builder
description: Tell Claude about your offer and get your whole webinar back as a PowerPoint deck, slide by slide, with what to say on each one, built to end on a booked call.
---

# The webinar builder

A webinar that books calls isn't a lecture with a pitch stuck on the end. It's built to one clock: win the room, teach one path so they believe they can do it, show them what they don't have yet, and ask for the call at about 45 minutes, with a reason to stay to the end. This skill builds that webinar around the coach's own offer: the plan, every slide, and what to say on each one, as a PowerPoint file they can open in PowerPoint, Keynote or Google Slides.

The person using this is busy and not technical. Ask what you need once, then hand back a deck they can rehearse this week.

## What to hand back
1. **The plan:** the promise, the one idea, what the room needs to believe, the 3 to 5 steps, the doubts to name early, the proof, and the gift for staying to the end.
2. **The deck:** `deck.pptx`, about 45 to 70 slides, with speaker notes on every slide (what to say, what the slide is for, what to ask the chat).
3. **The run of show:** which minute each part starts, so the call is asked for at about 45 minutes.
4. **What to gather before going live:** every screenshot, testimonial or detail the deck marks `[ASSET NEEDED]` or `[CONFIRM]`.
5. **The dashboard** (`assets/dashboard.html`, in webinar mode) and **their business file** (`my-business.md`).

## Steps

### 1. Get what you need
Read `references/business-file.md` and follow it. Read `my-business.md` if they dropped it in, and everything they pasted, before asking anything. A paragraph about their offer is enough to start. Then ask, in one numbered message, only the questions below that neither answers. A webinar leans on every one of them, so don't skip one and never guess an answer.

1. **What you sell, and who buys it,** a line each.
2. **The call they'll book:** what happens on it, who's on it, how long it takes, and what they leave with even if they don't buy.
3. **The one thing the webinar teaches them to do,** or the result they'll be able to see by the end.
4. **Your method:** the steps you take clients through, in your words. (If you don't have them written down, describe how you get results and the steps will be found from it.)
5. **Your story:** why you, and the moment it changed for you, told only as far as you're happy to say on camera.
6. **Proof:** real results with who, what changed and over how long, worded the way you share them, and any testimonial videos or screenshots you can show with the client's OK.
7. **What stops buyers:** the doubts they raise before buying, in their words.
8. **Who it isn't for.**
9. **A gift for staying to the end:** something real you can give everyone still there (a checklist, a template, a recording). If you don't have one, say so and one will be suggested from your material.
10. **Live or recorded, and when?** And is anything really limited (calls you can take a week, a date that ends)?
11. **For the slides:** your name, your brand colour (a hex code), and your booking link.

**The length.** A webinar built this way runs about 60 to 70 minutes with the close, because the call is asked for at 45 to 50. If they've already told people a shorter length, don't squeeze the clock: put `[CONFIRM: your page says 45 minutes; this runs about 65, so change the listed length]` at the top of the plan, and never print a length on a slide that the run of show contradicts.

Question 2 is the one the close can't be written without: if they skip it, ask it once more on its own. Leave `live` out of the plan unless they said whether it's live.

Then read their material for proof they mention but didn't attach (a screenshot, a dashboard, a before-and-after, a client message): each becomes an `asset` slide where it belongs. If they didn't tell their story, the introduction gets one `[CONFIRM: your turning point, in a sentence or two]` slot rather than a bio. A suggested gift is a tool the slides don't already contain (a calculator, a template, a script), never a recap of the deck.

Save their answers in `my-business.md`, and save everything they told you about their business, their method, their results and their story as `mine.txt`. If they skip a question, carry on: what it would have filled becomes `[CONFIRM: ...]` on the slide that needs it, and goes on the list to gather.

### 2. Lock the plan before any slide
Read `references/architecture.md`. Then write the plan into `deck.json` (its `plan` section, described in `references/slides.md`) and as plain words in `plan.md`:
- **The outcome:** who it's for, the feeling, the result, reachable in about 40 minutes of teaching.
- **The one idea** the whole webinar proves, and **what they need to believe** before they'd book (numbered).
- **The 3 to 5 steps,** one path, from their method.
- **The gaps:** for each step, the part that's slow or hard alone, and what the call gives them for it. Only true gaps.
- **The doubts:** 3 to 6, each with how it's handled (ignore, disagree or agree).
- **The proof:** each result with who, where they started, what changed, over how long, and its qualifier, never merged.
- **The gift** for staying, and **what's never claimed** (a short list for this offer).

### 3. Write the deck
Follow `references/architecture.md` for the shape and `references/close.md` for the close. Build it in this order, the way a webinar is really built: the teaching first, then the close, then the transition between them, then the introduction (it uses material from both), and last, go back and plant the gaps in the teaching. Then put the slides in delivery order in `deck.json`, following `references/slides.md`.

Every slide gets speaker notes. The `say` field is what to say, in the coach's own voice (read `references/voice.md`), written out fully: it's the script they rehearse. The run of show is worked out from these words (about 140 a minute), so a webinar that asks for the call at 45 to 50 minutes needs about 6,000 words of notes before the ask. Write the deck in parts (the introduction, each step, the transition, the close) and add each to `deck.json` as you go. Bring the chat in at least every few minutes of teaching. Never write "fill in" in a note: write the line, with a `[CONFIRM: ...]` inside it where something is unknown. Never say a tactic out loud ("I'm holding back the how", "every answer ends at the call").

**The rules that matter most:**
- **The webinar sells the call.** No price, no package, no payment terms, anywhere. The call is what's offered (if they didn't say it's free, say so only with a `[CONFIRM]`).
- **Every result is theirs and real,** with its qualifier beside it on the slide. Never a promise to the viewer.
- **Say only true things:** "live" only if it's live, "limited" only if it's limited, a deadline only if it's real.
- **One idea per slide.** If it doesn't fit, it's two slides.
- **Nothing invented:** no testimonial, screenshot, number, story or method the coach didn't give. If they didn't say how they do a step, its how is marked `[CONFIRM: ...]`, never filled in with bullets that sound right. Mark what's missing `[ASSET NEEDED: ...]` or `[CONFIRM: ...]`.
- **Teach the one idea outright,** on a slide of its own, with the coach's own numbers if they have them.
- **The teaching keeps the promise in full.** Whatever the first slides promise, the teaching delivers. The call offers going further (applying it to their own business, with help), never the thing they were promised for free.
- **Teach the viewer, don't describe the service.** Each step's how is said as what they can do ("you..."), never as what the coach does for clients ("we...").
- **Depth from their own numbers.** When their material gives a step only as a principle, work it through with their own figures, out loud, the way they'd show a client. Only the part of their method you truly don't know is a `[CONFIRM]`.
- **Each vision beat is one concrete moment after:** a scene from a client's week or the coach's own, from what they told you. If you don't have one, the slide is a single `[CONFIRM: a moment from after]`, not a statement with a placeholder stuck on.
- **Plant each gap in its step:** name the part that's hard alone, what it costs, and get agreement it's worth doing, during the teaching, so the close only has to answer it.
- **The call is the call, not the program.** What comes with booking is only what they said the call itself gives. What their material says happens "if we work together" is the program: it never goes on a booking slide without a `[CONFIRM]`. If they didn't say what the call gives, every line that says so keeps its `[CONFIRM]`.
- **The proof, said out loud, follows the same rules as on screen.** Say a result only on a slide that shows the whole proof line, keep its parts and its credit, and say a span, never a month. Other figures they mentioned in passing (a prediction, a best day, "we doubled it") stay out of the script and go on the gather list as `[CONFIRM: OK to say?]`.
- **An example stays an example.** Their illustrative math ("say 1,000 people register") is never described as something a client did.
- **In the final message, "you told me" only for what's in their material.**
- **The rival test, on the transition and the close too:** every one of those slides carries one thing only this coach has (their phrase, their number, their client). A line a rival could present unchanged gets rewritten.
- **Answer the doubts, don't defer them.** An answer that says "we'll go through that on the call" isn't an answer.
- **The proof line, word for word, wherever a result is on screen.** If they gave it as a set wording, put it in the plan as `public_wording`; a slide may show the biggest figure large, but the whole line sits under it. Never squeeze a result into "X to Y".
- **Say the real length:** if any slide says how long this takes, it matches the run of show.

### 4. Build the deck file
Run:

```
python3 scripts/make_deck.py deck.json --out deck
```

It writes `deck/deck.pptx` and a preview of every slide. If it prints `FIX`, cut words or split the slide and run it again. If you can view images, open `deck/preview/contact-1.png` (and contact-2, contact-3) and check that every slide reads at a glance and nothing is crowded.

### 5. Check it before they see it
Run the structure check:

```
python3 scripts/check_deck.py deck.json
```

It checks the clock, the steps, the beats, the map, the commitment, the doubts, the gift and the close, and writes `notes.md`. Then check the words:

```
python3 scripts/check.py notes.md --source mine.txt --voice voice.txt --proof "<their proof line>" --signature "<their 2 or 3 signature words or check-ins, comma-separated>" --opener-limit 10 --voice-floor 0.75
```

Save the coach's own lines as `voice.txt` if they gave any (otherwise leave out `--voice` and `--signature`), and leave out `--proof` if they have no result. Fix every failure in `deck.json`, rebuild, and run both again, three rounds at most.

**Then read it as the coldest person in the room.** Someone who has never heard of this coach:
1. **By minute 5, do they know** what they'll get, why this person, and why stay to the end?
2. **Could they follow each step,** and see their own life after it?
3. **Does each step leave a real gap** the call fills, without holding back what was promised?
4. **When the call is asked for,** does it feel like the obvious next step for someone who agreed to everything so far?
5. **Read every slide as their most skeptical buyer:** anything that sounds like hype, contradicts itself, or claims what the coach never said gets rewritten.

Then rebuild and run both checks once more.

### 6. Hand it over
- **The deck:** `deck/deck.pptx`, and say it opens in PowerPoint, Keynote or Google Slides, with what to say in the speaker notes under each slide.
- **The run of show:** `check_deck.py` writes `run-of-show.md` (each part with its start minute and its slides), so the minutes always add up.
- **The dashboard:** take `assets/dashboard.html` and replace `{{DATA}}` with the JSON below. Save it as `your-webinar.html` and show it as an HTML artifact. Don't change anything else in the template.
- **The business file:** save `my-business.md`.
- **Then one short message:** what to gather before going live (the `[ASSET NEEDED]` and `[CONFIRM]` list the check printed), and three things to do before the first run: rehearse the answers to money and time out loud, time the whole thing aloud once, and run it live before ever running it recorded. Nothing else: no pitch, no links.

The dashboard data:

```json
{
  "mode": "webinar",
  "coach": "their first name or brand, if they gave it",
  "source": "what it was built from, e.g. your offer and your answers",
  "note": "",
  "buyer": {
    "questions": ["what they need to believe, one per line"],
    "objections": ["each doubt, with how it's handled"],
    "words": ["the steps, in order"],
    "want": "the one idea"
  },
  "posts": [
    {"day": "0:00", "type": "intro", "title": "the introduction", "answers": "what this part does",
     "hook": "the first line said on the first slide", "body": "the slides in this part, one per line, with what each says"}
  ],
  "clips": [{"start": "slide 12", "end": "", "hook": "what to gather", "why": "what it's for"}]
}
```

One `posts` entry per part: the introduction, each step, the transition, the close and the Q&A, with its start minute as the `day`.

## If something's missing
- **No method written down:** find the steps in how they describe getting results. Name them in their words and mark the names `[CONFIRM]`.
- **No result yet:** build the proof from process and their story, and leave out any number slide. Never borrow a result.
- **No gift:** suggest one they could make in an hour from their own method (a checklist of the steps, for example), marked `[CONFIRM]`.
- **Recorded, not live:** nothing on any slide says "live", and nothing pretends to answer the chat in real time.
