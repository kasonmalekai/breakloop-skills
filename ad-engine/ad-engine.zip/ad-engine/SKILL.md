---
name: ad-engine
description: Turn your offer, or your best post, into ten new Meta ads in your voice. Video scripts with hooks and primary text, plus finished static images ready to upload.
---

# The ad engine

Meta groups ads that look alike and say the same thing, and spends on them as if they were one ad. So a batch of ten only tests anything when each ad brings a new reason to buy, or a new person to buy it. This skill writes that batch from the coach's own material: ten ads, each different where it counts, scripted to film, with the primary text and headline written, and the statics designed as finished images.

The person using this is busy and not technical. Ask little, work fast, and hand back ads they can film this week.

## Two ways in
- **From the offer (new angles):** they tell you what they sell. You find ten angles, each a reason to buy for one person at one stage of awareness, and write an ad for each.
- **From their best post or ad (the proven opening):** they paste their best few posts or ads with the numbers. You find the one whose opening has proved itself, keep its first five seconds word for word, and build the batch behind it. An ad with a cost per lead or per booked call is stronger proof than any post.

If they haven't said which, ask one question: "Do you have a post or an ad that did clearly better than the rest? If yes, paste it with a few others and their views. If not, tell me about your offer."

## What to hand back
1. **The plan:** the angles, one line each (the reason, the person, the stage). On the proven-opening route, which post won and why.
2. **Ten ads:** seven or eight videos and two or three statics. Each video has three hooks (the pick marked), the on-screen text, a script of 20 to 40 seconds, a filming note, the primary text and the headline. Each static has its image, primary text and headline.
3. **The statics as image files** (1080 by 1350, the feed size), zipped, with a contact sheet.
4. **Which three to five to launch first,** and how to read the first week.
5. **The dashboard** (`assets/dashboard.html`, in ads mode) and **their business file** (`my-business.md`).

## Steps

### 1. Get what you need
Read `references/business-file.md` and follow it. Read `my-business.md` if they dropped it in, and everything they pasted, before asking anything. Then ask, in one numbered message, only the questions below that neither of those answers. Every one of them changes the ads, so don't skip one the batch leans on, and never guess an answer.

1. **What you sell, and who buys it,** a line each.
2. **Where the ads send people:** a free training, a webinar, a free resource, or straight to a call? If it's a free thing, what's it called and what do people walk away with? If it's a call, what does the call itself give them?
3. **One real result** a client got: who, what changed, over how long, worded the way you share it publicly. Skip it if you don't have one yet.
4. **What buyers ask most before they buy, and what almost stops them:** two or three of each, in their words if you remember them.
5. **What you do that others in your space don't,** and the name of your method if it has one.
6. **Who it isn't for:** the people you'd rather the ads kept away.
7. **Have you run ads before?** If so, your best one (paste it or describe it) with its cost per lead or per booked call, and what flopped.
8. **What you can film:** you on camera? Where (a desk, the car, outside, a whiteboard)? Anyone who could be on camera with you?
9. **For the images:** the name and handle to show, and your brand colour as a hex code (otherwise black).

Save their answers in `my-business.md` so they're never asked twice, and save everything they tell you about their business, their results and their posts as `mine.txt`. Their own posts and ads go in it too, since every line in them is theirs. If they skip a question, carry on, and put a `[CONFIRM: ...]` line at the top of the ads wherever the batch leans on what they skipped. Every `[CONFIRM]` goes at the top, one line each, so they answer them in one go.

**Where each answer goes.** Their buyers' questions (4) set the ranking. What they do differently (5) is what makes each ad theirs. Who it isn't for (6) can be said plainly in a body. A past ad with numbers (7) beats any post as a proven opening, and what flopped isn't reworded and run again. The filming notes use only what they said they can film (8).

**The front door.** Ads to strangers work best when they sell a free thing, and the free thing sells the call. If the answer to 2 is "a call", write the ads for the call, and put one line at the top: `[CONFIRM: ads to strangers usually do better selling a free training first. Do you have one?]`.

### 2a. From the offer: find the angles
Follow `references/angles.md`. Write the ten in `plan.md`, one line each: the reason, the person, the stage, the format. Rank them, and mark the three to five to launch first.

### 2b. From their best post: find the proven opening
Follow `references/wrappers.md`. Write in `plan.md` which post won, by how much against their usual, and what its first five seconds do. Then plan the batch: which ads keep the opening with a new body, and which test a new opening on the strongest body.

If no post clearly beat the rest, say so plainly, and use the offer route instead.

### 3. Write the ads
Follow `references/ad-scripts.md`, the hook rules in `references/reels.md`, and `references/voice.md`. Read `references/meta-rules.md` before writing a line. Write everything in `drafts.md`, each ad under its own heading: `## Ad 1, video: <angle>` or `## Ad 8, static: <angle>`. Every spoken line starts with `> `.

On the proven-opening route, write the opening once, word for word, under `## The proven opening`. Each ad that keeps it starts its script with the line `> [THE PROVEN OPENING]` and goes straight into the new body.

**The rules that matter most:**
- **One reason to buy, for one person, per ad.** The same reason in different words is the same ad.
- **The ad sells the next step** (the free thing, or the call), never the program. **No price** for the program, anywhere. A price inside the buyer's own business (what their clients pay them) is fine when it's in `mine.txt`.
- **Every result is theirs and real,** labelled with who and over how long, with "results vary" beside it. Never promise the viewer a result. Every number comes from `mine.txt`, or it's `[YOUR NUMBER]`.
- **"You" can name their work, never their money, health or identity.** That's Meta's rule, and `references/meta-rules.md` has the rest.
- **Vary what Meta sees:** across the batch, no two videos share the same place and camera, and the formats spread out.

### 4. Design the statics
Follow the statics section of `references/ad-scripts.md`. Write `statics.json`, then run:

```
python3 scripts/make_statics.py statics.json --out statics
```

It prints `FIX` for any ad whose text won't fit, so shorten that text and run it again. If you can view images, open `statics/contact-sheet.png` and check that every image reads in two seconds on a phone and nothing is cut off. Then zip the folder as `statics.zip`.

### 5. Check it before they see it
Save the coach's voice lines as `voice.txt` if they gave any (otherwise leave out `--voice`). Then run:

```
python3 scripts/check.py drafts.md --source mine.txt --voice voice.txt --cta "<the fixed call-to-action line>" --proof "<their proof line>" --buyer-noun "<who buys, by their work, e.g. coaches>" --signature "<their 2 or 3 signature words, comma-separated>" --min-seconds 20 --max-seconds 40 --ads
```

Leave out `--proof` if they have no result, and `--signature` if there's no `voice.txt`.

Fix every failure and run it again, three rounds of fixes at most. Whatever's left, fix in the edit pass below.

**Then edit like a media buyer.** Pick the strongest of each ad's three hooks, not the first one written. The strongest names something the person owns or does, in a fact only this market knows. Then:
1. **Ten different ads?** Say each ad's reason and person in a few words, and what each ends on. Where two match, give one a different reason or a different person. A media buyer should count ten tests.
2. **Would the named person stop scrolling?** The first sentence says what the ad is about and who it's for.
3. **Is it theirs?** Read each ad without its call-to-action line. If a rival could run what's left unchanged, give it something only this coach has: their method's name, a real number, the way they work, the words they always use. Read the spoken lines aloud: anything that sounds written rather than said gets said their way.
4. **Read it as Meta's reviewer:** anything personal about the viewer, any promised result, any claim that isn't true when read. Rewrite it.
5. **Read it as their most skeptical buyer:** does anything contradict itself, or promise what the coach never said?

Then run the checker once more, and fix anything it finds.

### 6. Hand it over
- **The ads:** save them as `your-ads.md`, with no working notes (checker notes stay out; each ad's Length, Film and Show lines stay in, and so does a `[CONFIRM]` line at the top, since it's a question for the coach).
- **The statics:** `statics.zip`, and say which ad each file belongs to.
- **The dashboard:** take `assets/dashboard.html` and replace `{{DATA}}` with the JSON below. Save it as `your-ads.html` and show it as an HTML artifact. Don't change anything else in the template.
- **The business file:** save `my-business.md`.
- **Check both files:** the same command on `your-ads.md`, with `--dashboard your-ads.html` added. Fix anything it lists.
- **Then one short message:** which three to five to launch first and why, and the test plan from `references/launch.md` in three lines. Nothing else: no pitch, no links.

The dashboard data:

```json
{
  "mode": "ads",
  "coach": "their first name or brand, if they gave it",
  "source": "what the batch was made from, e.g. your offer, or your post about X, which did 4 times your usual views",
  "note": "",
  "buyer": {
    "questions": ["the angles, one per line: the reason, for whom, at what stage"],
    "objections": ["what stays the same across the batch: the proven opening, the free thing, the call to action"],
    "words": ["the ads to launch first, one per line, with why"],
    "want": "how to read the first week, in one line"
  },
  "posts": [
    {"day": "ad 1", "type": "video", "title": "the angle", "answers": "the person, and the stage they're at",
     "hook": "the opening this ad runs (the proven opening, or its own picked hook)", "on_screen": "the on-screen text",
     "body": "the other two hooks, then the script, the filming note, the primary text and the headline"},
    {"day": "ad 8", "type": "static", "title": "the angle", "answers": "the person, and the stage they're at",
     "hook": "the words on the image", "body": "the file name, then the primary text and the headline"}
  ],
  "clips": [{"start": "ad8.png", "end": "the style", "hook": "the words on the image", "why": "the angle"}]
}
```

## If something's missing
- **No result yet:** write the ads without proof, leaning on the mechanism and the objection formats, and leave the "number" static out. Never borrow a result from anyone else.
- **No posts with numbers:** you can't find a proven opening from words alone. Use the offer route.
- **A niche that Meta treats as special** (money, health, weight, housing, jobs, credit): read the special cases at the end of `references/meta-rules.md` before writing.
