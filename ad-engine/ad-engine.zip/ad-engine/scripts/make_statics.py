#!/usr/bin/env python3
"""Render static ads as finished PNG files, ready to upload to Meta.

Usage:
    python3 scripts/make_statics.py statics.json --out statics/

statics.json:
{
  "brand": {"name": "Dana Reyes", "handle": "@dana.clinics", "accent": "#1F4E79"},
  "ads": [
    {"id": "s1", "style": "headline", "label": "free live training", "headline": "...", "sub": "...", "button": "save your seat"},
    {"id": "s2", "style": "notes", "title": "...", "lines": ["...", "..."]},
    {"id": "s3", "style": "post", "text": "...", "button": "optional"},
    {"id": "s4", "style": "number", "number": "$131K", "headline": "...", "sub": "...", "footnote": "One client. Results vary.",
     "button": "optional"}
  ]
}

Styles: headline (a bold claim card), notes (a phone notes-app list), post (a social post card in
the coach's own name), number (one big real number). Every ad is 1080x1350 (4:5, the feed size).
Text that won't fit at the smallest size stops the run with the ad's id, so it can be shortened.
It also writes contact-sheet.png with every ad side by side, to look over at once.
Needs Pillow. The fonts (Inter, SIL Open Font License) ship in assets/fonts.
"""
import argparse
import json
import os
import sys

from PIL import Image, ImageDraw, ImageFont

W, H = 1080, 1350
M = 84  # side margin
HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "..", "assets", "fonts")
BOLD = os.path.join(FONTS, "Inter-Bold.ttf")
MED = os.path.join(FONTS, "Inter-Medium.ttf")
INK, MUTED, FIELD = "#0B0B0C", "#6B6B70", "#FFFFFF"


class TooLong(Exception):
    pass


def font(path, size):
    return ImageFont.truetype(path, size)


def wrap(draw, text, fnt, width):
    lines = []
    for para in str(text).split("\n"):
        words, cur, start = para.split(), "", len(lines)
        for w in words:
            test = (cur + " " + w).strip()
            if draw.textlength(test, font=fnt) <= width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = w
        lines.append(cur)
        # no lone word on a paragraph's last line: bring one word down with it
        if len(lines) - start >= 2 and len(lines[-1].split()) == 1 and len(lines[-2].split()) >= 3:
            prev = lines[-2].split()
            joined = prev[-1] + " " + lines[-1]
            if draw.textlength(joined, font=fnt) <= width:
                lines[-2], lines[-1] = " ".join(prev[:-1]), joined
    return lines


def byline(d, brand, y):
    text = " ".join(x for x in (brand.get("name"), brand.get("handle")) if x)
    if text:
        d.text((M, y), text, font=font(MED, 28), fill=MUTED)


def button(d, label, accent, bottom):
    fb = font(BOLD, 40)
    d.rounded_rectangle((M, bottom - 110, W - M, bottom), radius=55, fill=accent)
    tw = d.textlength(label, font=fb)
    d.text(((W - tw) / 2, bottom - 80), label, font=fb, fill=FIELD)


def fit(draw, text, path, width, max_h, start, minimum, spacing=1.15):
    """The biggest size, from start down to minimum, at which text fits the box."""
    size = start
    while size >= minimum:
        f = font(path, size)
        lines = wrap(draw, text, f, width)
        h = int(len(lines) * size * spacing)
        if h <= max_h and all(draw.textlength(l, font=f) <= width for l in lines):
            return f, lines, size
        size -= 4
    raise TooLong


def draw_lines(draw, xy, lines, fnt, size, fill, spacing=1.15):
    x, y = xy
    for l in lines:
        draw.text((x, y), l, font=fnt, fill=fill)
        y += int(size * spacing)
    return y


def hex_ok(c, default):
    c = str(c or "").strip()
    return c if len(c) in (4, 7) and c.startswith("#") else default


def block_h(lines, size, spacing):
    return int(len(lines) * size * spacing)


def style_headline(ad, brand, accent):
    img = Image.new("RGB", (W, H), FIELD)
    d = ImageDraw.Draw(img)
    top = M + 10
    label = ad.get("label")
    if label:
        f = font(MED, 32)
        tw = d.textlength(label, font=f)
        d.rounded_rectangle((M, top, M + tw + 48, top + 62), radius=31, fill=accent)
        d.text((M + 24, top + 13), label, font=f, fill=FIELD)
        top += 120
    bottom = H - M - 60
    if ad.get("button"):
        button(d, ad["button"], accent, bottom)
        bottom -= 150
    room = bottom - top
    sub = ad.get("sub")
    fh, hl, hs = fit(d, ad["headline"], BOLD, W - 2 * M, int(room * (0.68 if sub else 1)), 120, 56, 1.06)
    hh = block_h(hl, hs, 1.06)
    if sub:
        fs, sl, ss = fit(d, sub, MED, W - 2 * M, room - hh - 40, 46, 30, 1.25)
        sh = block_h(sl, ss, 1.25) + 40
    else:
        sh = 0
    y = top + max(0, int((room - hh - sh) * 0.42))
    y = draw_lines(d, (M, y), hl, fh, hs, INK, 1.06)
    if sub:
        draw_lines(d, (M, y + 40), sl, fs, ss, MUTED, 1.25)
    byline(d, brand, H - M - 30)
    return img


def style_notes(ad, brand, accent):
    img = Image.new("RGB", (W, H), "#FFFFFF")
    d = ImageDraw.Draw(img)
    amber = "#D9A21B"
    d.text((M - 24, M - 14), "< Notes", font=font(MED, 42), fill=amber)
    d.text((W - M - 64, M - 22), "...", font=font(BOLD, 44), fill=amber)
    y = M + 110
    ft, tl, ts = fit(d, ad["title"], BOLD, W - 2 * M, 330, 84, 48, 1.1)
    y = draw_lines(d, (M, y), tl, ft, ts, INK, 1.1) + 44
    items = [str(t) for t in ad.get("lines", [])]
    if not items:
        raise KeyError("lines")
    room = H - y - M - 30
    size = 62
    while size >= 32:
        f = font(MED, size)
        num_w = d.textlength(f"{len(items)}.  ", font=f)
        wrapped = [wrap(d, t, f, W - 2 * M - num_w) for t in items]
        total = sum(block_h(w, size, 1.3) for w in wrapped) + int(size * 0.75) * (len(items) - 1)
        if total <= room:
            break
        size -= 4
    else:
        raise TooLong
    for i, w in enumerate(wrapped):
        d.text((M, y), f"{i + 1}.", font=f, fill=amber)
        y = draw_lines(d, (M + num_w, y), w, f, size, INK, 1.3) + int(size * 0.75)
    return img


def style_post(ad, brand, accent):
    img = Image.new("RGB", (W, H), "#EFEFF2")
    d = ImageDraw.Draw(img)
    x0, x1 = M - 30, W - M + 30
    pad = 60
    if len(str(ad["text"]).split()) > 35:
        raise TooLong
    has_button = bool(ad.get("button"))
    ft, tl, ts = fit(d, ad["text"], MED, x1 - x0 - 2 * pad, H - 2 * M - 260 - (150 if has_button else 0), 66, 34, 1.32)
    text_h = block_h(tl, ts, 1.32)
    card_h = pad + 96 + 54 + text_h + pad
    y0 = (H - card_h - (150 if has_button else 0)) // 2
    if has_button:
        button(d, ad["button"], accent, y0 + card_h + 150)
    d.rounded_rectangle((x0, y0, x1, y0 + card_h), radius=40, fill="#FFFFFF")
    cx, cy = x0 + pad, y0 + pad
    d.ellipse((cx, cy, cx + 96, cy + 96), fill=accent)
    name = brand.get("name") or "your name"
    initials = "".join(p[0] for p in name.split()[:2]).upper()
    fi = font(BOLD, 40)
    tw = d.textlength(initials, font=fi)
    d.text((cx + 48 - tw / 2, cy + 24), initials, font=fi, fill=FIELD)
    d.text((cx + 124, cy + 8), name, font=font(BOLD, 38), fill=INK)
    if brand.get("handle"):
        d.text((cx + 124, cy + 54), brand["handle"], font=font(MED, 30), fill=MUTED)
    draw_lines(d, (cx, cy + 96 + 54), tl, ft, ts, INK, 1.32)
    return img


def style_number(ad, brand, accent):
    img = Image.new("RGB", (W, H), FIELD)
    d = ImageDraw.Draw(img)
    room = H - 2 * M - 160 - (150 if ad.get("button") else 0)
    fn, nl, ns = fit(d, ad["number"], BOLD, W - 2 * M, 340, 300, 120, 1.0)
    fh, hl, hs = fit(d, ad["headline"], BOLD, W - 2 * M, 400, 76, 44, 1.1)
    parts = [(nl, fn, ns, accent, 1.0, 36), (hl, fh, hs, INK, 1.1, 28)]
    if ad.get("sub"):
        fs, sl, ss = fit(d, ad["sub"], MED, W - 2 * M, 240, 42, 28, 1.25)
        parts.append((sl, fs, ss, MUTED, 1.25, 0))
    total = sum(block_h(p[0], p[2], p[4]) + p[5] for p in parts)
    if total > room:
        raise TooLong
    y = M + int((room - total) * 0.42)
    for lines, f, size, fill, sp, gap in parts:
        y = draw_lines(d, (M, y), lines, f, size, fill, sp) + gap
    if ad.get("footnote"):  # the label sits right under the claim it labels
        d.text((M, y + 4), ad["footnote"], font=font(MED, 30), fill=MUTED)
    if ad.get("button"):
        button(d, ad["button"], accent, H - M - 90)
    byline(d, brand, H - M - 30)
    return img


STYLES = {"headline": style_headline, "notes": style_notes, "post": style_post, "number": style_number}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("--out", default="statics")
    a = ap.parse_args()
    spec = json.load(open(a.spec, encoding="utf-8"))
    brand = spec.get("brand", {})
    accent = hex_ok(brand.get("accent"), INK)
    os.makedirs(a.out, exist_ok=True)
    made, problems = [], []
    for ad in spec.get("ads", []):
        style = STYLES.get(ad.get("style"))
        if ad.get("label") and ad.get("button") and ad["label"].strip().lower() == ad["button"].strip().lower():
            problems.append(f'{ad.get("id")}: the label and the button say the same thing, so make the label the free thing')
            continue
        if ad.get("style") in ("headline", "notes") and len(str(ad.get("headline", ad.get("title", ""))).split()) > 12:
            problems.append(f'{ad.get("id")}: the headline runs past 12 words, so it reads as a paragraph: shorten it')
            continue
        if not style:
            problems.append(f'{ad.get("id")}: unknown style "{ad.get("style")}" (use {", ".join(STYLES)})')
            continue
        try:
            img = style(ad, brand, accent)
        except TooLong:
            problems.append(f'{ad.get("id")}: the text is too long to fit (a post is 35 words at most), so shorten it')
            continue
        except KeyError as e:
            problems.append(f'{ad.get("id")}: missing field {e}')
            continue
        path = os.path.join(a.out, f'{ad.get("id", "ad")}.png')
        img.save(path)
        made.append((path, img))
    if made:
        cols = min(4, len(made))
        rows = (len(made) + cols - 1) // cols
        tw, th = W // 3, H // 3
        sheet = Image.new("RGB", (cols * tw + (cols + 1) * 20, rows * th + (rows + 1) * 20), "#D9D9DE")
        for i, (_, im) in enumerate(made):
            sheet.paste(im.resize((tw, th)), (20 + (i % cols) * (tw + 20), 20 + (i // cols) * (th + 20)))
        sheet.save(os.path.join(a.out, "contact-sheet.png"))
    for path, _ in made:
        print("made", path)
    for p in problems:
        print("FIX", p)
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
