# Writing each ad

Every line below describes a move. None of it is wording to copy. Build every sentence from `mine.txt`, in the coach's own words.

## Video ads
- **Length:** 20 to 40 seconds, about 50 to 100 spoken words.
- **The coach on camera,** talking. Their own face and voice beat a voiceover over stock footage.
- **The shape:**
  1. **The hook:** a verdict on something the person owns or does, 20 words at most, with the topic in the first half. **The hook or the first frame's text names who it's for, by their work** (what they sell, how they sell it), so the right person knows it's theirs and everyone else scrolls on. Never by their money, health or identity. If naming them in the spoken hook would push it into the third person ("a coach's closer"), name them on screen and keep the spoken hook in the coach's own "you".
  The picked hook is the script's first line, word for word, and it reads as one clean sentence said out loud. Opening on the thing they hate about their week is strong. Never open on a made-up scenario ("say", "imagine").
  2. **The cost,** by about five seconds: what this is costing them right now.
  3. **The one reason:** the mechanism, said plainly. One idea, not three.
  4. **The proof,** if the coach has it: their own result, labelled with who and over how long. The proof line can ride in several ads' bodies, and at least one of the ads launched first carries it, so strangers see it too.
  5. **The call to action:** one fixed line, the same words at the end of every video: the free thing (or the call), the one thing they'll get from it, and what to do. Write it once, before the ads, and don't reword it ad to ad. If the material doesn't say what they walk away with from the free thing, put `[CONFIRM: what do they walk away with?]` at the top rather than guessing. One sentence before it bridges from this ad's point to the step ("so the call starts with someone who's already watched you"), specific to the ad, never a stock lead-in. Pass the fixed line to the checker as `--cta`.
- **Three hooks,** each a different kind (`references/reels.md`) that says a different thing: three ways in, not one line reworded. Put the strongest in the script and list the other two above it. A "cost" hook carries the cost itself, a number or a time from `mine.txt`.
- **Each body carries one thing only this coach has:** a number from `mine.txt`, their own story as they told it, or their method by name.
- **Not all of them straight to camera.** At least two of the videos use another format: text on screen over footage, the coach drawing on a whiteboard or walking through a screen, or two people talking.
- **The on-screen text** follows `references/reels.md`, on two lines: who it's for on the first, the hook's phrase on the second. Never run the two together into one line.
- **No summary line before the call to action** ("That's the order we work in", "That's how we..."). The line before the call to action says why this ad's point makes the call worth booking.
- **If a body has nothing only this coach has,** put their proof line in its primary text.
- **If they said who it isn't for,** one ad's body may say so plainly. Pushing the wrong people away is part of an ad's job.
- **Filming notes use only what they said they can film.**

Write each hook line as the words themselves. Don't name its kind on the line.

**No made-up examples with numbers** ("say 500 people watch..."). In an ad, every number reads as a claim. Use a real number from `mine.txt`, or say it without one.

Under each video's heading, give, in this order:
```
Hook 1: the first hook, written as it's said
Hook 2: the second, a different kind (pick)
Hook 3: the third, a third kind
On screen: the first frame's text
> the script, one spoken line per row
Length: about N seconds
Film: the camera, the place, the format
Primary text:
the hook line
the proof or the mechanism
the call to action
Headline: the words under the video
```

## The primary text
The words above the ad. Three short lines:
1. **The hook,** written to work with the sound off. The same idea as the spoken hook, in different words: never the spoken hook copied.
2. **The proof or the mechanism:** one real, labelled result, or the reason it works.
3. **The call to action:** the free thing and what to do.

Never lead with a question. Never lead with the coach's name or a greeting. Each ad's headline says its own angle: no two headlines alike. The first line is all most people see before "more", so it has to carry the ad by itself. No hashtags.

## The result
If the coach gave a proof line (in `my-business.md` or their message), it's worded that way for a reason.
- **Wherever the result is written** (on screen, on an image, in the primary text), use the proof line word for word, with its label ("results vary") right beside it, never moved or reworded. On a number static, show the biggest figure large as the number, then the whole proof line, in its own order and without changing a word, across the headline and the sub line (the figure appears twice, which is fine), and the label as the footnote. A proof static's text may run past the usual length limits below.
- **Spoken, they can say it naturally,** but never change what the numbers mean: "contracted" stays contracted, a span stays a span ("in the 45 days after", never "was at"), the order stays the same, and every part of the system they credit stays credited.
- **Every qualifier stays with its claim,** wherever it's restated: "about" and "around" stay with their numbers, a span stays with its result, and an "if" stays an "if", on an image too. Under a number static, the headline names the free thing rather than rewording the result.
- **Never tie the result to the viewer** ("a funnel like his", "results like these"). Show it, labelled, and let it stand.
- **The result as its own ad** (the testimonial or the number static) is one angle, used once. As proof inside other ads' bodies, it can appear more than once.

## The headline
The bold line under the image or video. 40 characters at most, counted: it names the free thing by its name, or the specific payoff from this ad's body. "A free training" plus a general topic isn't a headline. No price.

## Statics
Two or three of the ten. `scripts/make_statics.py` renders four styles:
- **headline:** one bold claim, a short line under it, and a button. For direct response.
- **notes:** a phone notes-app list. For a checklist the person recognises from their own week.
- **post:** a post card in the coach's name. For a strong verdict or opinion.
- **number:** one big real number. Only for a real result, with who and over how long in the headline, and "results vary" in the footnote.

Rules for every static:
- **It reads in two seconds on a phone.** One idea per image.
- **The free thing or the call is on the image, or in the headline under it.** The notes and post styles have no button, so their headline carries it.
- **The same rules as the videos:** real numbers only, nothing personal about the viewer, no price.
- **The coach's own point,** never general advice any rival could post.
- **Lengths:** a headline of 12 words at most, a sub line of 25, three to five notes lines of 10 words each, a post of 35 words, a footnote of 8.
- **The headline, number and post styles take a button.** Use it for the call to action. Use the label (headline style) only when there's a real free thing to name, never the same words as the button.
- **A notes list stays true to its title:** every line is an example of what the title says.

`statics.json`:
```json
{
  "brand": {"name": "the coach's name", "handle": "@handle", "accent": "#hex colour"},
  "ads": [
    {"id": "ad8", "style": "headline", "label": "the free thing, in a few words", "headline": "the claim",
     "sub": "who it's for and what they get", "button": "the action"},
    {"id": "ad9", "style": "notes", "title": "the list's title", "lines": ["one", "two", "three"]},
    {"id": "ad10", "style": "post", "text": "the post"},
    {"id": "ad11", "style": "number", "number": "the real number", "headline": "what it was, for whom, over how long",
     "sub": "where they started", "footnote": "results vary"}
  ]
}
```
Under each static's heading in `drafts.md`, give the file name, the words on the image, the primary text and the headline.
