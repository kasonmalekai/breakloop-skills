# Writing ads Meta approves

Meta reviews every ad before it runs. In coaching, most rejections come from four things. Write around all four from the first draft.

## 1. Nothing personal about the viewer
An ad can't say or imply something personal about the person watching: their money, debts, health (body or mind), weight, age, race, religion, sexuality, or that they're struggling.
- **"You" can name their work:** what they sell, how they sell it, what their week looks like.
- **"You" can never name their money, body or identity.** Not "are you broke", not "your debt", not "you're overweight".
- **Talk about the situation instead,** or about the coach's clients: what the people they work with were dealing with before.

## 2. No promised result
- **Never promise the viewer a sum or an outcome:** not "you'll make", not "guaranteed", not "overnight", not "easy money".
- **A real result is fine when it's labelled:** whose result, how much, over how long, and "results vary" beside it. Never call it typical.
- **The result is the coach's or their client's,** with the client's OK. Never anyone else's.

## 3. No before-and-after framed as theirs
A picture or line that shows a body or a bank balance changing, framed as what the viewer will get, gets rejected. Show the work instead.
- **No revenue dashboards, bank screenshots or payment screens** filmed in an ad to strangers. They're the most common reason coaching ads get rejected.
- **Never tie a client's result to the viewer:** not "a funnel like his", not "results like these".

## 4. True when read
"Live", "only 20 seats", a countdown, a date, "free": each goes in only if it's real. If you don't know, mark it `[CONFIRM: ...]`.

## Our own rule on top
**No price in any ad.** The price belongs on the call, where it can be explained.

## If an ad is rejected
Read the reason Meta gives. Rewrite the one line it points at and submit once, or request a review once if the rejection was wrong. **Never resubmit the same ad as several variants:** repeated rejections can restrict the whole ad account.

## Where the ad sends people
The page they land on keeps the ad's promise. If the ad offers a free training, the page offers that training, in the same words.

## Special cases
- **Credit, loans and other financial products, jobs, and housing** are Meta's special ad categories: those ads have to be declared, and the targeting gets narrower.
- **Health, weight and body niches** aren't a special category, but they get stricter review: no before-and-after, nothing that makes the viewer feel bad about their body, and some products are limited to adults.

In either case, write to the stricter standard, and tell the coach to check Meta's advertising standards for their niche before launching.
