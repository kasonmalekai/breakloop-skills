# Finding ten angles

An angle is a reason to buy, for one person, at one stage of awareness. Change any one of the three and you have a new angle. Change only the words, the colours or the music and you have the same angle again, and Meta will treat it that way.

Every line below describes a move. None of it is wording to copy.

## The three parts
- **The reason:** what the buyer gets, or gets away from, in the coach's own terms. It comes from what the coach actually delivers, never from what sounds good.
- **The person:** one specific buyer the coach serves, described by their situation (what they sell, where they're stuck, what they've tried), never by age or demographics.
- **The stage:** how much they already know.
  - **They feel it but haven't named it:** open on the symptom they live with every week.
  - **They know the problem, not the fix:** open on the cause.
  - **They know the usual fixes:** open on why the usual fix keeps failing them.
  - **They know the coach, and they're not ready:** open on the proof, or on the reason they'd say no.

Cold ads mostly live in the first three stages. Keep at least one of the ten for people who already know the coach.

## Where angles come from
Read `mine.txt` for each of these, and list every one you find in `plan.md` under "every angle I found" before choosing. Aim for fifteen or more. The ten come from that list, so the strongest material gets used, not the first that came to mind:
- **Each result the coach delivers,** for each kind of person they deliver it to.
- **Each reason buyers give for not buying:** the time, the money, the "I tried this", the "not yet".
- **The usual fix that fails,** and why it fails for this person.
- **The moment a buyer realises they need help:** what just happened in their week.
- **What the coach does differently,** in their own words.
- **What the buyer stops doing once they buy:** the work that comes off their plate.
- **The terms of the deal,** if the material has them (a guarantee, how the coach gets paid). Mark these `[CONFIRM: ...]`, since terms change.
- **A real result,** told by the client or by the coach with the client's OK.

## The four formats
Spread the ten across all four:
- **The question:** answers a question the person is already asking themselves, said as a verdict, never asked back at them.
- **The objection:** names the reason they'd say no, in their words, and takes it apart.
- **Direct response:** the free thing, plainly: who it's for, what they'll get, what to do.
- **The testimonial:** a real result, labelled. Only if the coach has one. A made-up or composite story is never used.

## The people
Name three to five buyer situations before choosing, each a different person: different in what they sell, how they sell it, how far along they are, or what they've already tried (for example, someone who has never run ads, and someone running them now). Two symptoms of the same person's problem are still one person, so never name a person after the problem the ad is about. Give each a short name in the plan and use it on every angle. Define each by a fact about their business that isn't the ad's topic, and say that fact in the ad's first ten seconds or show it on screen, so the person can tell it's them.

## Make them ten
List the ten as `reason / person / stage / format / promise in five words / the point it ends on / what only this coach has in it`. Then:
- **Two that share the reason and the person are one ad,** however different the words. Two that rest on the same mechanism, or end on the same point, are one ad too. Replace one of them.
- **The statics carry angles no video uses.** A static that repeats a video's angle is the same test twice.
- **The result as its own ad is one angle.** Make it one video or one static, not both. It can still appear as proof inside other ads.
- **At least three of the named people** across the batch.
- **No more than three in the same format.**
- **The rival test:** an angle a rival coach could run unchanged is too broad. Tie it to something only this coach has.

## Rank them
Put first the reasons buyers mention most, for the person the coach serves most often. Write the ten in `plan.md` in rank order, and **launch exactly the top three to five,** never two on the same reason. Say in a few words why each made the top.

Only ads for people who already know the coach are warm: run them to people who've watched the coach's videos or visited their page, and mark them "warm" in the plan. Ads for people who know the usual fixes still run to strangers; at higher revenue, that's most of the cold market.

Rank with the buyer's own questions from `my-business.md` in the order they come up: an angle that answers the first question ranks above one that answers the fifth. If the coach's own outreach or videos lead with something (often the result), that's evidence it works cold. The launch set includes one of the statics, since it can run today while the videos get filmed, and every launch pick says why in a few words.
