# Building on a proven opening

A hook that won is an asset: run it again on a new body. When an opening has already held people, the fastest way to more winning ads is to keep it and change what comes after it.

## Find the winner
- **An ad beats a post.** If they've run ads, their best one is the ad with the lowest cost per lead, or the one that has run longest at a steady cost.
- **For posts, compare each one to their usual.** Work out their typical views (the middle of the posts they gave you, not the average). A post at about twice their usual or more has a proven opening. Saves, shares and comments count too, when they gave them.
- **Use the ratio, never the raw number.** Ten thousand views is a winner for one account and a flop for another.
- **If nothing stands clearly above the rest** (under about one and a half times their usual), say there's no proven opening yet, and use the offer route instead.

Then say why it won, from its words: what its first sentence said the video was about, what pulled the viewer one way, and what pulled them back.

## The proven opening
- **The first five seconds, word for word:** about the first 12 to 15 spoken words, usually the first sentence or two. Never reword it. The exact words are what proved themselves.
- **If the opening only works with the story after it,** take the shortest part that stands on its own.
- **Its on-screen text stays too,** if they gave it.
- **Check it against `references/meta-rules.md` before you keep it.** An organic post can say things an ad can't. If it says something personal about the viewer's money, health or identity ("you're not paying yourself" names their pay), or promises a result, keep every word except the phrase that breaks it, and change that phrase as little as you can, usually by moving it off "you" ("a full schedule and still no salary"). Put `[CONFIRM: ...]` at the top of the ads saying what changed and why, and keep the original wording in the plan so they can compare.
- Write it once under `## The proven opening` in `drafts.md`.

## The batch behind it
Seven or eight videos, and two or three statics:
- **About three in four of the videos keep the opening** with a new body. Each starts its script with `> [THE PROVEN OPENING]`.
- **The rest test a new opening on the strongest body, word for word,** so the opening is the only thing that changes and the result means something. They follow the hook rules in `references/reels.md`, each a different kind of hook. Head them `## Ad 7, video (new opening on ad 1): <angle>`. Each counts as its own test (of the opening), so it doesn't break "ten different ads". A test opening points at the same thing the body's first line pays off, so the test measures the opening and not how well it fits. Pick the one whose first sentence has both the pull and the turn.
- **Warm ads don't run the proven opening.** People who already know the coach have likely seen the post it came from, so a warm ad opens on the proof or on the reason they'd say no.
- **The statics:** at least one carries the opening's claim as words on the image (it's the one static allowed to share an angle with the videos, since it tests the claim as text). The others carry angles no video uses.

## Each new body
- **It pays off the opening.** The first sentence after the opening carries the cost or the verdict the opening points at: it repeats the opening's key word, or gives its cost as a number from this coach's material. Read the opening and that sentence aloud together: they should sound like one person making one point.
- **A new reason has to come through the opening's problem.** If the opening blames one thing and the body is about another, add the line that connects them ("the reimbursement problem starts at the front desk"), or use that body for a new-opening ad instead. A body that doesn't follow from the opening breaks the ad, however good it is.
- **Nothing points back to what the opening never said.** "That week" or "that call" only works if the opening described it.
- **One reason, for one person,** as in `references/angles.md`. Every body brings a different reason or a different person.
- **It ends on the call to action.**

## Make them look different
Meta groups ads that look alike, so vary the wrapping across the batch:
- **The place:** the desk, the car, a walk outside, the kitchen, a whiteboard, the studio.
- **The camera:** selfie, a tripod at eye level, a screen recording, talking over a screenshot.
- **The format:** talking to camera, text on screen over footage, two people talking, a notes-app list.
- **The edit:** captions style, cuts, pace.

No two videos share the same place and the same camera.
