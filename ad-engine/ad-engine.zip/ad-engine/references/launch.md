# Launching the batch

## Which to launch first
Exactly the top three to five of the ranking among the ads for strangers, never two on the same reason, and one of them a static so something can run today. On the proven-opening route, launch the proven opening on its strongest two bodies, plus one new opening on the strongest body to test against it. Ads marked "warm" go to people who've already watched or visited, once there are enough of them, and don't count toward the three to five.

## Before the first dollar
Write down the most they can pay for each booked call: their price times their close rate on calls, less the margin they want to keep. That number is the line every ad is judged against.

## Reading the first week
- **Judge each ad on its own job.** An ad that sends people to a call is judged on its cost per booked call. One that sends them to a free training is judged on its cost per sign-up, and then on how many of those sign-ups book.
- **Give each new ad about 48 hours of spend before judging it.** Early numbers swing.
- **A new hook has won** when that number is at least 20% better than the ad it was tested against. If there aren't enough results yet to count, use the click-through rate the same way.
- **Turn off single ads that clearly lose.** Never judge the whole campaign on one week: a lead from week one often buys in week three. Read it on cash at 30 days.

## When a winner slows down
As the same people see a winning ad again and again, its cost per lead climbs. Change it in this order:
1. **A new opening** on the same body.
2. **A new place or way of filming** the same script.
3. **A new body** behind the same opening.

The angle keeps running while it still pays.

## Keep it fed
About ten new angles a month keeps an account from going stale. Run this skill again with the next ten reasons and people, and keep the winners running.
