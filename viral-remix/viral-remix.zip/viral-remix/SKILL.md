---
name: viral-remix
description: Paste the words of any reel that blew up, from any niche. Get why it worked, beat by beat, and your own version ready to film, built for your offer and your buyer.
---

# Viral remix

A reel that blew up in another niche has already been tested on millions of strangers. Its words belong to someone else, but its shape doesn't: the way it opens, the turn it takes, the feeling it runs on, the order it pays things off. This skill pulls that shape out and rebuilds it around the coach's own offer, buyer and point, so they film something proven that's entirely theirs.

The person using this is busy and not technical. Ask little, work fast, and hand back something they can film today.

## What to hand back
1. **Why it worked:** the hook, the format, the structure beat by beat, the feeling it runs on, and what transfers and what doesn't.
2. **Version 1, ready to film:** three hook options, the on-screen text, the full script in their voice with rough timings, a shot list, and their call to action.
3. **Versions 2 and 3:** the same shape aimed at two other reasons to care, each with its hook, on-screen text and the script's beats.
4. **The dashboard** (`assets/dashboard.html`, filled in, in remix mode).
5. **Their business file** (`my-business.md`), so next time nothing gets asked twice.

## Steps

### 1. Get the reel's words
- If they've only pasted a link, tell them in one line that you can't watch a video from a link, and ask for its words: paste what's said (and the on-screen text), or upload 2-4 screenshots if the words are burned into the video. Use whatever they give you.
- Ask for the reel's views and the creator's follower count if they know them. A reel with 3 or more times the creator's followers in views is a real outlier, and you can say so. If it's under that, say so in one line, then remix it anyway: it still did well, but an outlier is the safer bet next time. If they don't know, carry on.
- Save the reel's words, exactly as given, as `original.txt`. Note its length in seconds: from the last timestamp if there are any, otherwise from the word count (about 2.5 spoken words a second).

### 2. Get what you need about them, and nothing more
Read `references/business-file.md` and follow it. Use `my-business.md` if they dropped it in. Otherwise ask, in one message, only what's missing: what they sell and who buys it, their call to action, and (optional) 3-5 of their own posts or a short voice note transcript so it sounds like them. Never ask for revenue.

Save everything they told you about their own business, their posts and their real numbers as `mine.txt`. This is the only material a remix may take facts from.

**If what they've told you is thin** (no result, no story, nothing specific about how they work), ask two short questions before writing anything: one real result a client got (or a belief their buyers hold that they disagree with), and what they do differently from others in their space. Wait for the answers unless they tell you to go ahead without them. A remix built on thin input ends up borrowing the original's argument or inventing things about their offer, which is exactly what it must never do.

### 3. Decode why it worked
Follow `references/decode.md`. Write the breakdown under a `## Why it worked` heading in `drafts.md`.

### 4. Build the voice card
Follow `references/voice.md`, using their posts or voice note. For a remix, a voice sample is optional: if they gave none, don't hold the remix up for it. Write plainly in short spoken sentences, and say at the end that a few of their posts would make it sound more like them.

### 5. Rebuild it as theirs
Follow `references/rebuild.md` and `references/reels.md`. Write the three versions into `drafts.md`, each under its own heading (`## Version 1, reel: <title>`), with every spoken line starting with `> `.

**The rules that matter most:**
- **Take the shape, never the words or the advice.** No line, phrase or claim from the original goes into a version. The point each version makes comes from the coach's own material and offer, not from what the original was teaching.
- **Never borrow their numbers or their results.** The original's views, money and stories are someone else's. A number in a version is the coach's own, or `[YOUR NUMBER]`.
- **Never name or credit the original creator** in the remix, and never say it's a remix.
- **No claims the coach can't back:** no "most coaches", no invented results, no timing that isn't real.

### 6. Check it before they see it
Save their voice lines as `voice.txt`. If they gave none, leave `--voice voice.txt` out of every command below. Then run:

```
python3 scripts/check.py drafts.md --source mine.txt --buyer original.txt --voice voice.txt --cta "<their call to action>" --proof "<their proof line, if they gave one>" --avoid avoid.txt --max-seconds <the original's length in seconds x 1.3> --frame-limit 1
```

Here `--buyer original.txt` catches any wording copied from the original, `--avoid avoid.txt` catches its central picture, `--source mine.txt` means every number has to be theirs, and `--max-seconds` keeps each reel close to the original's length. The "it isn't X, it's Y" move is allowed once across all three versions. Fix every failure and run it again, three rounds of fixes at most (the later checks after the edit don't count toward the three).

**Then edit like a strategist.** For each version:
1. **Does it pass the thesis test** in `references/rebuild.md`? If Version 1 is the original's argument with new nouns, rewrite it from the coach's own thesis.
2. **Does it keep what made the original work?** Check the same kind of hook, the same turn at the same moment, the same feeling, and the payoff in the same place. If the rebuild lost the mechanism, it isn't a remix, it's a new reel with a borrowed topic. Put the mechanism back.
3. **Cut what a rival could post.** Any sentence that would work unchanged for another coach gets made specific with something only this coach has.
4. **Read the logic aloud.** Each sentence follows from the last.
5. **Would a stranger in their market stop for the first sentence and stay for the second?** If not, rewrite those two first.

Then run the checker once more.

### 7. Hand it over
- **The scripts:** save the breakdown and the three versions as `your-remix.md`, ready to read from on camera, with no working notes (the thesis test and checker notes stay out; each version's Length and Show lines stay in).
- **The dashboard:** take `assets/dashboard.html` and replace `{{DATA}}` with the JSON below. Save it as `your-remix.html` and show it as an HTML artifact. Don't change anything else in the template.
- **The business file:** save `my-business.md`.
- **Check both files:** `python3 scripts/check.py your-remix.md --source mine.txt --buyer original.txt --voice voice.txt --cta "<their call to action>" --proof "<their proof line, if they gave one>" --avoid avoid.txt --max-seconds <as above> --frame-limit 1 --dashboard your-remix.html`. Fix anything it lists.
- **Then one short message:** film Version 1 first, and one line on what to watch for in the first three seconds. Nothing else: no pitch, no links.

The dashboard data:

```json
{
  "mode": "remix",
  "coach": "their first name or brand, if they gave it",
  "source": "a reel with about 2M views in the business-buying niche",
  "note": "",
  "buyer": {
    "questions": ["what made it work, one point per line"],
    "objections": ["what to keep: the parts that transfer"],
    "words": ["what to swap: the parts that belong to the original's niche"],
    "want": "the feeling it runs on, in one line"
  },
  "posts": [
    {"day": "version 1", "type": "reel", "title": "...", "answers": "the reason to care it aims at",
     "hook": "the picked hook", "on_screen": "the on-screen text", "body": "the other two hooks, then the full script and the shot list, with no working notes (no Length:, Show:, Answers: lines)"}
  ],
  "clips": []
}
```

## If something's missing
- **Only a caption, no spoken words:** decode the caption and the on-screen text, and say the breakdown is thinner without the script.
- **The original isn't really a reel** (a long video, a carousel, a tweet): work with its words the same way, and say which parts won't carry over to a reel.
- **It went viral for a reason that can't transfer** (a celebrity, a news moment, an animal): say so plainly in the breakdown, and remix the part that can.
