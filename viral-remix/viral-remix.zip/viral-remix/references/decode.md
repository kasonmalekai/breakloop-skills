# Decoding why it worked

Work out the mechanism, not the topic. A reel about buying laundromats and a reel about closing sales calls can run on exactly the same mechanism. The topic is what gets swapped. The mechanism is what gets kept.

## Pull these out, in order
1. **The hook, in three parts:**
   - **Context:** what it said the video was about, and how early. The first half of the first sentence is where it belongs.
   - **The lean:** what pulled the viewer one way (a number, a named pain or result, something unexpected).
   - **The snapback:** what pulled them the other way (a belief broken, a reversal).
   Quote the opening line and label each part.
2. **The on-screen text in the first frame,** and what it added beyond the spoken words.
3. **The format:** talking head, green screen, a list, a story, a breakdown of something on screen, a this-against-that, a reaction. Say how it was filmed if the words make it clear.
4. **The structure, beat by beat,** with rough seconds if you can tell them: the hook, the lock-in (what kept them in the first 5 seconds), each turn, each re-hook, the payoff, the ending. Mark where the viewer gets a new reason to stay.
5. **The feeling it runs on:** the one emotion that carries it (curiosity, fear of missing out, relief, being let in on something, status, being seen, surprise, mild outrage). Say where in the script that feeling peaks.
6. **The payoff:** what the viewer walks away with, and whether it lands at the end or is held back.
7. **The call to action,** if there is one, and how it's set up.

8. **The thesis, in one line:** the argument the original makes ("generic content gets buried as a niche fills up").
9. **The central picture, in one line:** the image or metaphor it hangs that argument on ("a red line rising up a pyramid").
10. **How the viewer takes part:** does the reel make the viewer experience the technique as it teaches it (it does the trick on them), or does it only describe it?

## Then sort it
- **What made it work:** the three or four things that did the heavy lifting, most important first. Be specific: "the number in the first four words" beats "a strong hook".
- **What to keep:** the parts that transfer to any niche, which are the shape, the turns, the feeling, the timing and the format.
- **What to swap:** the parts that belong to the original, which are its topic, its examples, its proof, its numbers, its words and its advice.
- **What can't transfer.** There's always something: the creator's own authority and audience trust, a famous face, a news moment, a story only they have. Name it, and never answer "nothing".
- **The thesis and the picture always go on the swap list.** The remix makes its own argument with its own picture.

If the views and follower count are known, say how big an outlier it is (views divided by followers).

Write the breakdown in plain sentences. No jargon the coach would need explained.
