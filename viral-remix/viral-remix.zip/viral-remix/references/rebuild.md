# Rebuilding it as theirs

## The test of a good remix
A stranger who saw both reels wouldn't think one copied the other. Someone who studies reels would see that they're built the same way.

## The thesis test (do this before writing)
Write the original's thesis and central picture in one line each (from the breakdown). Then write the coach's own thesis and their own picture, from their offer and their world, in one line each. Version 1 fails if it can be restated as the original's thesis with the nouns swapped, or if it uses the original's picture in any form. **Replace the picture, never just drop it.** The coach's own picture does the same job at the same moment (if the original's picture sorted viewers onto one side or the other, theirs does too), drawn from their own field: for a clinic coach, insurance pay rates, a first cash patient, a lease. Put 2-5 specific words or short phrases naming the original's picture in `avoid.txt` (for example "red line", "rising bar"), never everyday words, so the checker can catch them.

**If their material is too thin** to give them a thesis of their own, ask for one real result, story or belief their buyers hold. If you can't ask, write `[YOUR RESULT]` or `[YOUR STORY]` where it goes. Never fill the gap by stretching the original's point.

## How to build Version 1
0. **If the original ends by handing over the thing it revealed** (a template, a checklist, a tool: "comment X and I'll send you..."), build backward from the coach's call to action: Version 1's reveal is the problem their giveaway solves, so the call to action follows the reveal with no bridge sentence. Read the last two lines together: if you need a line explaining why the giveaway fits, the reveal is wrong.
1. **Pick the coach's point first.** From their offer and their own material, pick the one thing their buyer most needs to hear that fits the original's shape. If the original breaks a belief, find the belief their buyer holds. If it counts down a list, find a list the coach really teaches. If it tells a before and after, find one the coach can honestly tell (or leave `[YOUR STORY]`).
2. **Map it beat for beat.** Line up the original's beats and write the coach's version of each one, so the same turn lands at the same moment. 
3. **Rebuild the hook from scratch, as the same type.** A question stays a question, a number stays a number, a verdict stays a verdict, using the coach's own material. Keep the same three parts: context first, a lean, a snapback. Write three options, all of the original's type (here, unlike a week of posts, the three don't need different kinds). The lean is something their buyer wants, a pain they feel or a real number of the coach's, never a neutral habit ("coaches track their close rate"). Run the rival test on the hook and the reveal: what in them could only this coach say? The reel rules in `references/reels.md` apply in full.
4. **Keep the feeling, and how the viewer takes part.** If the original ran on being let in on something, the remix has to let their viewer in on something real from the coach's world. If the original does its technique to the viewer as it teaches it, Version 1 does its technique to the viewer too, rather than describing it.
5. **End where the original ends,** with the coach's call to action in place of the original's. If the original had no call to action, end on the last line of the idea, then add theirs in one short line.
6. **Keep the length.** The spoken script runs within about 30% of the original's length (about 150 spoken words a minute).

Their voice lines are for how it sounds, never for what it's about. Write it said, not written: their own habit words where they'd say them, no pairs of mirrored lines ("A lead who... A buyer who..."), and one "I" or "we" throughout. The topic comes from their offer and the thesis test.

## Every claim about their offer is theirs
Any line about what their program includes, gives or lets buyers do has to trace to their own words, and so does any line about how they work ("I build the webinar first", "we always start with..."). Their proof goes in whole, credit and label included, never cut to the numbers (pass it to the checker with `--proof`). If it doesn't, either cut it or mark it `[CONFIRM: what you'd need them to confirm]`. Then read Version 1 as their most skeptical buyer would: does any line contradict another, or promise something they never said?

## The shot list
For Version 1, one line per beat: what's on screen (face to camera, the screen, a prop, text), and where the on-screen text changes. Keep it to what one person can film alone with a phone.

## Versions 2 and 3
The same shape as the original, beat for beat (not the general reel outline), aimed at two other reasons to care that the coach's buyer has. They must differ from Version 1 in their point, not just their wording, and pass the same thesis test. For each, give the picked hook, the on-screen text and the script's beats (a full script isn't needed).

## Lines that are off limits
- Any phrase from the original, its advice, its examples, its numbers or its results.
- The original creator's name, or any hint that it's a remix.
- A result, a client or a number the coach didn't give you. Use `[YOUR NUMBER]` or `[YOUR STORY]` instead.
