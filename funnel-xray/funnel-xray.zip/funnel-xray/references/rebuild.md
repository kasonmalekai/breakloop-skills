# Building the coach's version

Take the model, never the copy. The coach gets the same stages, the same order, the same kinds of angle and the same job for each page, all built from their own offer, their own buyer and their own proof.

## Three ads
One for each of the competitor's two or three longest-running angles, rebuilt as the coach's own:
- the same kind of reason to buy, aimed at the coach's buyer, in the buyer's own words;
- three hook options, following the hook rules in `references/reels.md`;
- the on-screen text;
- a 20-40 second script;
- where it sends people, which is the same kind of front door as the competitor's (usually the free event).

## The registration page, first screen
- A line naming the exact audience.
- A headline of three lines at most: who it's for, the mechanism, the outcome.
- The date and time if they're real, otherwise `[CONFIRM: date and time]`.
- A two-line subhead.
- What the form asks for, and the reason given for the phone number.
- The button text.

Then three to five "what you'll learn" lines, each one a real thing the coach teaches.

## The thank-you page
- The headline, then what the main video says, as a 30-60 second outline.
- Two or three numbered steps.
- Three short extra video ideas, one per doubt their buyer has before the event (for example, whether it will work for someone like them), each with its first line.

## The no-show ad
For people who signed up and didn't come, a 15-30 second script that gives them a reason to come next time or to watch the replay, written as the coach. It never shames them.

## Lines that are off limits
- Any phrase, claim, story, number or result from the competitor.
- The competitor's name, their offer, their price, or their look.
- A price anywhere.
- A claim that isn't true for the coach ("live", "limited", a date) unless they confirm it. Mark it `[CONFIRM: ...]`.
