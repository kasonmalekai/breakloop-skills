# Building the coach's version

Take the model, never the copy. The coach gets the same stages, the same order, the same kinds of angle and the same job for each page, all built from their own offer, their own buyer and their own proof.

## Three ads
One for each of the competitor's two or three longest-running angles, rebuilt as the coach's own. Name the ad each one is modelled on, with its start date, in the heading (`## Your ad 1: <angle> (modelled on their ad from Aug 11)`). The newest ads are what they're testing; the old ones are what's proven.
- the same kind of reason to buy, aimed at the coach's buyer, in the buyer's own words;
- three hook options, following the hook rules in `references/reels.md`;
- the on-screen text;
- a 20-40 second script;
- where it sends people, which is the same kind of front door as the competitor's (usually the free event).

A tool, platform or detail of the event (Zoom, a date, "live") goes in only if the coach named it; otherwise `[CONFIRM: ...]`. No vague stand-in where a number or an answer belongs ("its first stretch", "something else"): use a fact from their market, or `[YOUR NUMBER]` ("the first [YOUR NUMBER] minutes"), and give every hook its snapback. The three ads never share a line in the same slot.

The picked hook carries something only the coach's market would recognise (their buyer's own situation, the coach's own number), never a line any rival could run. Each script names the fix the coach gives, not only the problem.

## The registration page, first screen
- A line naming the exact audience.
- A headline of three lines at most: who it's for, the mechanism, the outcome.
- The date and time if they're real, otherwise `[CONFIRM: date and time]`.
- A two-line subhead.
- What the form asks for, each question written out, and the reason given for the phone number.
- One line saying who it isn't for, from the coach's own buyer.
- The button text.

Then three to five "what you'll learn" lines, each one a real thing the coach teaches. The free event does the same job as theirs: if the x-ray named a diagnosis of the viewer's own business as the thing doing the most work, the coach's event diagnoses too, it doesn't only teach. Promise only what the coach said they deliver.

## The thank-you page
- The headline, then what the main video says, as a 30-60 second outline.
- Two or three numbered steps.
- Three short extra video ideas, one per doubt their buyer has before the event (for example, whether it will work for someone like them), each with its first line.

## The no-show ad
Only when the front door is an event people register for. For a one-to-one call, a text or DM follow-up does this job; a paid ad to a handful of no-shows has no audience to run on.
For people who signed up and didn't come, a 15-30 second script that gives them a reason to come next time or to watch the replay, written as the coach. It never shames them.

## Lines that are off limits
- Any phrase, claim, story, number or result from the competitor.
- The competitor's name, their offer, their price, or their look.
- A price anywhere.
- A claim that isn't true for the coach ("live", "limited", a date) unless they confirm it. Mark it `[CONFIRM: ...]`.
- Their proof cut short. Wherever a result appears, the whole proof line goes with it, credit and label included (the checker holds you to it when you pass `--proof`).
- One of their questions with the noun swapped ("Will this work for my kind of business?" becoming "...my kind of coaching?"). Ask the coach's own buyer's question.
