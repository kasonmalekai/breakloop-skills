# Reading their ads in Meta's Ad Library

The Ad Library (facebook.com/ads/library) shows every ad a page is running right now, with the date each one started. Nobody pays to keep running an ad that loses money, so **how long an ad has run is the best public proof that it's working.**

## How the coach gets there
1. Open facebook.com/ads/library, set the country, choose "All ads", and search the competitor's name or page.
2. Pick their page, and filter to active ads.
3. Either keep the page open and ask Claude in Chrome to read it, or take screenshots of the ads and upload them here.

Read only the page they have open, for one advertiser. Don't click through hundreds of ads or collect anything beyond what's on that page.

## What to pull from each ad
- **When it started running,** and so how many days it's been live.
- **The format:** talking head, a slideshow, a static image, a testimonial, a screen recording.
- **The hook:** the first line or the headline, quoted.
- **The angle:** the reason to buy it sells, for which person, at what stage. Ads that make the same promise to the same person count as one angle, however different they look.
- **Where it sends people:** a free event, a call, a sales page, a free resource.
- **Whether it chases people who already raised a hand:** words like "you registered", "you missed it", "replay", "last chance", "still thinking about it". These are retargeting, no-show and replay ads.

## How to read the set
- **Longest-running first.** An ad left unchanged for months is the clearest signal in the library.
- **Count them.** About three live ads is a weak signal. Around thirty means an account that's scaling.
- **Find the front door.** On cold traffic, most winning coaching funnels sell a free event, and the event sells the call. Say what theirs sells.
- **Group by angle,** and name the two or three angles carrying the account.
- **Note what they do for people who didn't show.** It's often the most overlooked money in the funnel.
