# Reading their ads in Meta's Ad Library

The Ad Library (facebook.com/ads/library) shows every ad a page is running right now, with the date each one started. Nobody pays to keep running an ad that loses money, so **how long an ad has run is the best public proof that it's working.**

## How the coach gets there
1. Open facebook.com/ads/library, set the country, choose "All ads", and search the competitor's name or page.
2. Pick their page, and filter to active ads.
3. Either keep the page open and ask Claude in Chrome to read it, or take screenshots of the ads and upload them here.

Read only the page they have open, for one advertiser. Don't click through hundreds of ads or collect anything beyond what's on that page.

## What to pull from each ad
- **When it started running,** and so how many days it's been live.
- **The format:** talking head, a slideshow, a static image, a testimonial, a screen recording.
- **The hook:** the first line or the headline, quoted.
- **The angle:** the reason to buy it sells, for which person, at what stage. Ads that make the same promise to the same person count as one angle, however different they look.
- **Where it sends people:** a free event, a call, a sales page, a free resource.
- **Whether it chases people who already raised a hand:** words like "you registered", "you missed it", "replay", "last chance", "still thinking about it". These are retargeting, no-show and replay ads.

## How to read the set
- **Longest-running first.** An ad left unchanged for months is the clearest signal in the library.
- **Read the order with the age.** The Library sorts by impressions by default, so the top of the page is where the money is now. Old and near the top: proven and still funded. New and near the top: what they're pushing right now, often a fresh launch. Old and low: kept on with a small budget.
- **"N ads use this creative"** means N ads running at the same time (other audiences or placements), not later copies. A high count is budget behind that creative.
- **Ads that start on the same day are one push,** even when they point at different places. A free training and an application for the paid program launched together usually means the training feeds the program.
- **What the Library can't show:** spend, targeting, results and who sees which ad. Never claim any of them ("the most budget behind it" is a spend claim), and write one line under their ads saying what you can't see. No retargeting wording in the live ads doesn't mean there's no retargeting.
- **Line the dates up.** Put the ads' start dates beside the event dates on the page and any close date in another ad. Ads that start about ten days before the sessions, and a paid offer that closes right after them, are one launch window.
- **Check every "each" and "every".** Before writing that each ad does something, check each ad. Angle groups add up to the number of creatives. A different audience bar in an ad for a different offer is a different offer, not a leak.
- **Small differences between ads date the copy.** Two revenue figures for the same claim usually mean one ad is older.
- **Count them.** About three live ads is a weak signal. Around thirty means an account that's scaling. Count ads, not creatives: add up the "N ads use this creative" figures (a creative with no count is one ad), and give both numbers.
- **Find the front door.** On cold traffic, most winning coaching funnels sell a free event, and the event sells the call. Say what theirs sells.
- **Group by angle,** and name the two or three angles carrying the account.
- **Note what they do for people who didn't show.** It's often the most overlooked money in the funnel.
