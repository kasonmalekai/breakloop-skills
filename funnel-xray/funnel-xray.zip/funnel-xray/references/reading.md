# Reading the funnel, stage by stage

For each stage, write what they do (with the evidence), why it works, and where it leaks. Leave a stage out only if it doesn't exist, and mark a stage you couldn't see as unseen.

For every stage, also ask the three questions an operator asks:
- **What does it capture that the sales team uses later?** A form or survey's answers are often the real product: they qualify buyers and tell the closer what to say.
- **What in the free part advertises the paid offer?** Named frameworks, a "lite" version of the paid thing, or results from the paid program.
- **Does it lean on fame or a big audience?** Say how much of it would still work for an unknown coach.

Only describe what you saw. A form's questions, a metric or a page you didn't see is unseen, so say what you'd expect and label it as expected. Never name a number or metric the page doesn't show.

## The stages
1. **The ad:** see `references/ads.md`. What does it sell (an event, a call, a page), and to whom?
2. **The registration page.** Its one job is getting the form filled. Look at:
   - the headline (who it's for, the mechanism, the outcome);
   - whether the date and time are exact;
   - whether there's a video, and why;
   - what the form asks for, and whether there's a reason given for the phone number;
   - whether every claim is true ("live", "limited seats", a countdown);
   - the pain section, what they'll learn, and who it's for;
   - how many scrolls it takes.
3. **The thank-you page.** Its one job is making showing up the obvious next thing. Look for:
   - a headline that confirms the sign-up;
   - one main video near the top;
   - two or three clear steps to take;
   - short extra videos answering the buyer's doubts before the event;
   - proof, and a fallback contact.
4. **The show-up sequence:** the emails and texts between sign-up and the event, if you have them. How many, when they go, and what each one is for.
5. **The event:** the promise, how long it runs, the reason to stay to the end, and where the offer comes in.
6. **The offer and the close:** what's sold, how (a call, a checkout, an application), and what urgency they use and whether it's real.
7. **After the event:** the replay, the no-show follow-up and the ads that chase people who didn't show.

## Across the whole funnel
- **One promise:** is it the same promise, in the buyer's words, from the ad to the page to the thank-you page? Where does it change?
- **The one thing doing the most work:** the single choice that makes the rest of the funnel work.
- **Where it leaks:** the stage most likely losing the most people, and why.
- **Fame:** what works because the host is famous or has a big warm audience, and so won't work for a coach without that.
