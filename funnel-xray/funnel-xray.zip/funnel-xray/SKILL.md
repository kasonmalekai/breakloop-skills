---
name: funnel-xray
description: Paste a competitor's funnel (their page, their ads, or screenshots) and see how it turns strangers into sales calls, which ads are paying, then get your own version written.
---

# Funnel x-ray

Somewhere in every coach's niche, someone is already winning with paid traffic. Their funnel is public: the ads sit in Meta's Ad Library, and the pages are a click away. This skill reads it the way an operator would: what each piece does, why it works, which ads are paying, and where it leaks. Then it rebuilds the model around the coach's own offer. It takes the model, never the copy.

The person using this is busy and not technical. Ask little, work fast, and hand back something they can use this week.

## What to hand back
1. **How their funnel works:** every stage from the ad to the call, what each one does, why it works, and the one thing doing the most work.
2. **Their ads, longest-running first,** with the angle each one sells and which ones chase people who didn't show.
3. **Take and never take:** the model to copy (the stages, the order, the angles) and what stays theirs (their words, claims, proof, offer and look).
4. **Your version:** the same model built for the coach's offer, with three ads, the first screen of the registration page, the thank-you page, and the ad for people who didn't show.
5. **The dashboard** (`assets/dashboard.html`, in x-ray mode) and **their business file** (`my-business.md`).

## Steps

### 1. Get the funnel
Ask for whatever they have, and work with what you get:
- **Their pages:** a link to the registration page, the sales page or the webinar page. If you can open links, read the page. If you can't, ask them to paste the page's text or upload screenshots.
- **The thank-you page:** most of the strategy sits behind the sign-up, so the coach can register themselves and paste what they see, including the confirmation emails if they come through.
- **The ads:** read `references/ads.md`. The coach opens the advertiser's page in Meta's Ad Library. With Claude in Chrome, you read the ads on the page they have open. Otherwise they upload screenshots.

Never sign up, click through or browse on their behalf beyond the pages they point you to. Read one advertiser, not the whole library. Save all of the competitor's words exactly as given as `theirs.txt`.

### 2. Get what you need about the coach
Read `references/business-file.md` and follow it. Use `my-business.md` if they dropped it in. Otherwise ask, in one numbered message, only what's missing: what they sell and who buys it, their call to action, and whether they have a free training, webinar or resource (their front door) and what people walk away with from it. Save what they tell you about their own business and any real numbers of theirs as `mine.txt`. If it's thin, ask two short questions before building: one real result a client got, and what they do differently from others in their space. Never invent either.

### 3. X-ray their funnel
Follow `references/reading.md` stage by stage. Write it under a `## How their funnel works` heading in `drafts.md`, and the ads under `## Their ads`. Every claim about their funnel points at what you saw: a quote from the page, an ad's start date, a screenshot. If a stage is hidden (you only have the registration page), say what you'd expect to find there and mark it as unseen.

### 4. Sort it
Under the x-ray, list:
- **What's working,** most important first, specific ("the ad that's run longest sells the event, not the program").
- **Take the model:** the stages, their order, the angles, the formats.
- **Never take:** their copy, their claims, their proof and numbers, their offer and price, and their design.
- **The one thing doing the most work,** in one line.

### 5. Check the front door fits before building
Every funnel turns on its front door: the free thing, or the event, that gets a stranger to raise a hand. Write two lines: what the competitor's front door gives away, and what the coach already has that could do the same job.
- **If the coach has the same kind of thing** (a free training, a webinar, a plan or a resource they already deliver), build around it.
- **If they don't,** say so first, as the decision the whole model depends on: "To run this model you need a free [thing]. You don't have one yet, so build it first, or use the nearest thing you do have." Then build around the nearest real thing they have, and put that gap in one `[CONFIRM: ...]` at the top. Don't scatter it across every piece.

Ask what it costs to run, too. Their front door may be cheap to deliver (automated, or done by AI) while the coach's version is done by hand. If so, say how many a week the coach can realistically do, and suggest the lighter version that keeps the model.

Then check the fit:
- every ad says the free thing out loud;
- their call-to-action word matches what the ad promises;
- every "what you'll get" line could really be produced from what the form collects;
- every line under "take the model" shows up somewhere in the build;
- the build doesn't repeat a leak your own x-ray named in theirs.

**Walk the path end to end:** ad, call to action, page, form, thank-you page. Every promise made along the way can be answered from what the form collects. No step repeats another (nobody is asked to DM the same word twice), and no step contradicts another. Cut or fix any that do.

### 6. Build their version
Follow `references/rebuild.md` and `references/reels.md` (the ads are short videos, so the hook rules apply). Write each piece under its own heading (`## Your ad 1: <angle>`, `## Your registration page`, `## Your thank-you page`, `## Your no-show ad`), with every spoken ad line starting with `> `.

**The rules that matter most:**
- **The model, never the copy.** No phrase, claim, proof or number from the competitor goes into the coach's version. Their headline promise reworded with the nouns swapped is still copying. The coach's promise comes from what the coach actually delivers.
- **Every number and result is the coach's own,** or `[YOUR NUMBER]`.
- **No price** on any ad or page. It belongs on the call.
- **Every claim is true when read.** "Live", "limited seats", a countdown or a date go in only if they're real for the coach, so mark them `[CONFIRM: ...]` if you don't know.
- **One promise, in the buyer's words,** runs through the ads, the page and the thank-you page.

### 7. Check it before they see it
Save the coach's voice lines as `voice.txt` if they gave any (otherwise leave out `--voice`). Then run:

```
python3 scripts/check.py drafts.md --source mine.txt --buyer theirs.txt --voice voice.txt --cta "<their call to action>" --frame-limit 1
```

`--buyer theirs.txt` catches any wording copied from the competitor, and `--source mine.txt` means every number has to be the coach's. Fix every failure and run it again, three rounds of fixes at most.

**Then edit like an operator.** Pick the strongest of each ad's three hooks, not the first one written. The strongest carries a fact only this market knows (a show rate, the first ten minutes of a call, what buyers ask before they book). No line in any script explains these rules to the viewer. Write any "who it's not for" screen from the coach's own buyer, never as a reworded version of theirs. Then, for each piece of their version:
1. **Is the model really kept?** The same stages in the same order, the same kind of ad angle, the same job for each page.
2. **Is it theirs?** Any line a rival could post unchanged gets made specific with something only this coach has.
3. **Does one promise run through it,** from ad to page to thank-you page?
4. **Read it as their most skeptical buyer:** does anything contradict itself or promise what the coach never said?

Then run the checker once more.

### 8. Hand it over
- **The x-ray and the build:** save them as `your-xray.md`, with no working notes (checker notes stay out; each ad's Length and Show lines stay in).
- **The dashboard:** take `assets/dashboard.html` and replace `{{DATA}}` with the JSON below. Save it as `your-xray.html` and show it as an HTML artifact. Don't change anything else in the template.
- **The business file:** save `my-business.md`.
- **Check both files:** `python3 scripts/check.py your-xray.md --source mine.txt --buyer theirs.txt --voice voice.txt --cta "<their call to action>" --frame-limit 1 --dashboard your-xray.html`. Fix anything it lists.
- **Then one short message:** which piece to build first and why (usually the ad angle that's run longest), and that the competitor's copy and claims stay theirs. Nothing else: no pitch, no links.

The dashboard data:

```json
{
  "mode": "xray",
  "coach": "their first name or brand, if they gave it",
  "source": "who you x-rayed and what you saw, e.g. their registration page and 14 active ads",
  "note": "",
  "buyer": {
    "questions": ["what's working, one point per line"],
    "objections": ["take the model: one line each"],
    "words": ["never take: one line each"],
    "want": "the one thing doing the most work"
  },
  "posts": [
    {"day": "ad 1", "type": "reel", "title": "the angle", "answers": "which of their ads it's modelled on",
     "hook": "the picked hook", "on_screen": "the on-screen text", "body": "the other two hooks, then the script, with no working notes"},
    {"day": "page", "type": "caption", "title": "your registration page", "hook": "the headline", "body": "the first screen, top to bottom"}
  ],
  "stages": [{"stage": "the registration page", "seen": true, "what": "what they do, with the evidence", "why": "why it works", "leak": "where it leaks"}],
  "clips": [{"start": "the date it started running", "end": "days running", "hook": "its angle, in a few words", "why": "why it's still running"}]
}
```

## If something's missing
- **No ads at all:** they may run none, or only on another platform. X-ray the pages, and say the ads are unseen. Build the coach's three ads from the promises on the pages instead, and label each angle "inferred from the page". Leave the ads table empty.
- **Only a few ads, all new:** about three live ads is a weak signal, so say it may not be proven yet.
- **A famous name:** a big audience carries a lot of what works for them. Say which parts lean on their fame and won't transfer to a coach without it.
