---
name: call-to-content
description: Turns one sales call or long video transcript into a week of posts in your own voice, answering what your buyers actually asked. Reel scripts, carousels, captions.
---

# Call to content

Every sales call a coach takes is full of content they throw away: the questions buyers ask, the objections that nearly stopped them, the words they use for their problem, and the coach's own best explanations. This skill turns one transcript into a week of posts built from exactly that, in the coach's own speaking voice.

The person using this is busy and not technical. Ask little, work fast, and hand back something they can film today.

## What to hand back
1. **What your buyer told you:** the questions, objections, beliefs and words from the call, ranked.
2. **A week of posts:** 3 reel scripts, 2 carousels, 2 captions or text posts, each tied to one thing the buyer said.
3. **From a long video** (a webinar, YouTube video or podcast over about 20 minutes): **the clip map** as well, the 8-15 moments worth cutting, with timestamps.
4. **The dashboard:** the whole week as one page (`assets/dashboard.html`, filled in).
5. **Their business file** (`my-business.md`) to keep for next time.

## Steps

### 1. Get what you need, and nothing more
- If they haven't pasted or uploaded a transcript yet, ask for one: a sales call, a discovery call, a coaching call, or any long video of theirs. Fathom, Zoom, Otter, YouTube's "show transcript" and Google Meet all export one. Timestamps help but aren't required.
- Read `references/business-file.md` and follow it: use `my-business.md` if they dropped it in; otherwise ask at most the questions the transcript can't answer, in one message.
- **If the material has a client result in it** and `my-business.md` has no proof line, ask for their proof line word for word in the same message (how they always state that result, with its credit and label). A result then always goes out in that wording, never narrowed to the post's topic or stripped of its unit ("contracted") or label.
- Work out who's who. Usually the coach is the one selling or teaching. If you can't tell, ask "which speaker is you?" and nothing else.
- **Settle who's who before you set anything aside.** When they tell you who was on the call, take it: the speaker who isn't the buyer is the coach unless a line plainly can't be theirs. Never drop the coach's lines from the call on a hunch. If you truly can't tell and it would gut the material, ask "which speaker is you?" first.
- **Transcripts often swap the speaker labels.** Before building anything, reassign every turn by what it says (who asks about price and their own situation, who explains the method), and build `source.txt` and `buyer.txt` from the corrected turns.
- **When someone else sells on the call** (a closer, a setter, a team member), the posts are still in the coach's voice, and the closer's words are never put in the coach's mouth as the coach's own claim. Use what the closer said only as a topic, rebuilt from the coach's own material (their posts, a voice memo). For each closer moment that moved the buyer (the turn included), look for the coach's own version of it first and use that. Search their material by meaning, not by matching words: "watch me, then trade it yourself and get corrected" may be "you have me as your guide" in a memo, and "am I smart enough?" may be answered by "my students often end up doing better than me". Only what has no version of the coach's own goes on a "needs the coach's OK" list at the top of the week and in the dashboard's note.

### 2. Protect the buyer before anything else
Read `references/privacy.md` and do the privacy pass on the whole transcript first. Nothing that identifies the buyer may reach a post.

### 3. Mine the call
Follow `references/mining.md`. You end with a ranked list of the buyer's questions, objections, the beliefs behind them, their words for the pain, what they want, what they've tried, and the coach's best explanations, each with where it came from.

### 4. Build the voice card
Follow `references/voice.md`. Pull 8-12 of the coach's own lines (never the buyer's) into `voice.txt`. If the coach's real explanations add up to less than about 300 words (a call that's mostly logistics, "got it" and "talk soon"), tell them the voice is too thin and ask for 3-5 of their posts or a two-minute voice memo transcript. If they'd rather not, write plainly and say the voice match is weak, instead of falling back on slogans.

### 5. Plan the week
Seven posts, each answering one mined item, strongest first. The default mix (adjust to where they post):
- **Day 1, reel:** the question the buyer asked first or most, answered.
- **Day 2, carousel:** the coach's best explanation from the call, as a framework.
- **Day 3, reel:** the belief behind the biggest objection, named and broken.
- **Day 4, caption or text post:** the buyer's pain said back in their own words (paraphrased), and what to do about it.
- **Day 5, reel:** the step between two things the buyer knows that nobody named for them.
- **Day 6, carousel:** what they tried that failed, and why (myth then receipt, or diagnose then prescribe).
- **Day 7, caption or text post:** the turn that makes it click for buyers like this one: the line the coach said that changed the buyer's mind, written as the general situation, never as a story about this buyer. When a closer made that turn, use the coach's own version of it. If they have none, answer the buyer's top fear from the coach's material instead.

**Write the plan into `plan.md` before drafting anything.** One row per post: the day, the type, its one reason to care (one line), the mined item it answers, the moment in the source it comes from, the example or exercise it uses, and the kind of hook it leads with (verdict, cost or broken belief). Then check the plan:
- **The rival test:** for each day, ask whether any other coach or agency in their space could post it unchanged. If they could, swap it for something only this person teaches: their own named step, their own method, their own way of seeing it. Their most distinctive material goes in the week first. The generic version of an idea never makes the cut.
- **Write each post's cause and fix in one sentence each** in the plan. Reject a cause another post already has, a fix that contradicts another post's, and a post whose point argues against its own call to action (a post that says "get off social media" can't end on "follow for more").
- **Each of the buyer's top four questions gets a post,** or a line in the plan saying why not. A top question the coach's material can't answer goes on the OK list as a request ("record 30 seconds on how you pick the stock"), never dropped quietly. Before a post answers a fear, reread the buyer's line around it: "once I make 3,000 I'll spend 6" is about spending creep, not a trading goal. A post's "answers" is one of those listed questions, never a topic of your own.
- **The coach's backstory goes in one post,** not three. Dedupe on the fix as well as the cause, and give any number the coach states one value across the week.
- **A testimonial call** (the client agreed to it): one post can tell the client's result as proof, labelled with who, what changed and over how long, and marked `[CLIENT RESULT, IF CLEARED]` until the coach confirms it can be posted.
- **List the buyer's weight phrases** ("the biggest thing", "really key", "the main", "the hardest", "my fear", "my worry") word for word with where they said them. The top three each get a post, or a line in the plan saying why not. The checker lists any the plan missed.
- **The strongest real number or story leads.** Each post's hook carries the strongest fact from its source moment, never a later slide. The hook is about the viewer's problem: a number in it is their cost or the result they're missing, never the coach's own win told for its own sake.
- **Give each reel a lock-in cost in the plan:** one concrete cost for sentences two and three, from the buyer's pain said generally ("you sold too early and can't get back in while it runs") or a cost fact from the coach. Using a one-line cost in another post is fine; the backstory rule is about stories. Sentences two and three never restate the hook or open with an "if you..." diagnosis. A snapback is proved by a fact inside the post. Sentences two and three each carry something concrete from the material and never restate the hook.
- **Any promise a hook or title makes needs the coach's own fact in the post,** or `[YOUR NUMBER]` and a line on the OK list. If the material has no fact that answers the post's question (how many hours a day it takes), drop the post. Never fill it with a line that sounds like an answer and isn't. The numbers inside one post must agree with each other, and a carousel never names a step the coach doesn't explain in it.
- **Build the cost hooks from the strongest real number** in their material: put it in the plan beside the post. A cost is the viewer's, never the coach's stake, and a dollar figure always comes with what it's out of (the account, the position, the month).
- No two posts share a reason to care, an underlying cause, a mechanism, an example, an exercise or a source moment. Dedupe on the cause, not the topic: two posts that both land on "the call is doing the trust work" are one post. From a long video, the seven posts come from seven different parts of it, and the speaker's own counted list and own exercise get slots first.
- The three reels lead with three different hook kinds.
- The "it isn't X, it's Y" move, in any form ("you don't need X, you need Y", "you're not X, you're Y"), appears twice in the week at most. The checker counts it, so don't write a number into the plan that you haven't checked.
- If the material can't fill seven different posts, make fewer. Six strong posts beat seven where two say the same thing.

### 6. Write
- Reels: `references/reels.md`. Three hook options each, on-screen text, the script in their voice, the call to action.
- Carousels: `references/carousels.md`.
- Captions and text posts: `references/captions.md`.
- Long video: `references/clip-map.md` as well.

Write everything into `drafts.md`, with every spoken reel line starting with `> `.

**The lines between the coach's own lines are where a week starts sounding like a copywriter.** Build them from the coach's own phrasing and connectors ("kinda", "I mean", "you know", whatever they actually say). The checker warns when many spoken sentences share no wording with their material: reread those as them. Never bolt one of their phrases or habit words onto a sentence to make it sound like them ("..., and I average 2 to 3 trades a day"); a sentence either is how they'd say it or gets rewritten. Never close on a balanced maxim ("one trade can't tell you, and a record can", "a loss is just a number you already agreed to"): end on the coach's own line or the plain action.

**Never invent.** No client results, no numbers, no stories that aren't in the transcript. **Every cause and rule in a post comes from the coach.** A line that says why something happens ("that's where the fake moves get you") or states a rule ("mine stops out at 20 to 25%") points to the coach's own line that says it. If it points to the closer or to nothing, cut it. Something that happened once ("twice yesterday") stays told as that one time, never as a rule. Never trim the coach's claim to fit the call to action: if their real point argues against it, pick another post. **A number travels with its condition:** if they said "at least 5-6 months with me as your guide", the condition goes in the post too, and two numbers in one post never contradict each other. If a post needs a number they didn't give, write `[YOUR NUMBER]`. Never name or credit another creator in a post. **Never put a price in a post,** the coach's or anyone's, even if it was said on the call, unless the coach asks for it. Prices belong on the call.
- **If the material promises a count it doesn't deliver** ("five things", then four), don't copy the count. Use what's actually there.
- **The fix in a post is the coach's own fix,** the one they gave or teach in the material. Never add a method, a step or a "first thing I'd do" they didn't say.
- **No claims about "a lot of coaches", "most people" or "everyone"** unless the coach said it. One call is one buyer, so say "someone told me" and not "everyone tells me".
- **The call to action has to fit the post.** If their call to action points at something the material never mentions (a webinar word on a call that never talks about a webinar), ask them about it before writing. If you can't ask, keep their call to action, give each post one short line that bridges to what it offers, and put a one-line warning at the very top of `your-week.md` and in the dashboard's `note` field saying it doesn't match what the material talks about.
- **Never retell the buyer's call as a story about one person** ("someone told me last week..."), and never invent when something happened. Turn what the buyer said into the general situation many buyers are in, in your own words, so the buyer could never recognise herself.
- **Their name** comes from the business file or from what they tell you. A transcript often misspells names, so if you only have the transcript's spelling, leave the name out of the dashboard.

### 7. Check it before they see it
Save the cleaned transcript from step 2 as `source.txt`, with any of the coach's own material they gave you added below it (a voice memo, their posts), so their real numbers count as theirs. Save the buyer's own lines from the call (one per line) as `buyer.txt`. For a solo video there's no buyer, so leave out `--buyer`. Start every post in `drafts.md` with a `## ` heading that names the day and the type (`## Day 1, reel: ...`). Then run:

```
python3 scripts/check.py drafts.md --source source.txt --voice voice.txt --buyer buyer.txt --week-plan plan.md --cta "<their call to action>" --proof "<their proof line, if they have one>" --signature "<their 2 or 3 habit words or check-ins, comma-separated>"
```

Pick the signature words by counting the coach's own lines, never the buyer's: the two or three spoken habits they use most, used where they'd naturally say them, never added to hit a count. It checks each line and the week as a whole: the repeated frame, template lines, claims and timings the material doesn't make, a retold anecdote, a reel whose second sentence starts the lesson, a carousel cover over 16 words or a slide that prints the plan ("Why it sounds right:"), the buyer's weight phrases the plan missed, "their words" in the dashboard the buyer never said, words or numbers copied from the buyer, and two posts sharing a line. Fix every failure, then run it again, three rounds at most. If something still fails after three rounds, say which line and why in one sentence at the end.

**Then edit like a strategist, one post at a time.** A post that only rearranges the transcript reads assembled. For each post:
1. **Find the payoff.** Name the single strongest thing in its source moment: a number that lands, a line that turns the viewer's thinking, a before and after. It has to be in the post, usually as the line it builds to. If the post lost it, put it back.
2. **Cut what a rival could post.** Any sentence that would work unchanged in another coach's post gets cut or made specific with something only this material has.
3. **Make every slide earn its place.** Each carousel slide adds a new fact, step or turn. A slide that restates the cover or an earlier slide goes.
4. **Read the logic aloud.** Each sentence follows from the one before it, and nothing contradicts itself: sentences two and three never say something the post's own example then disproves, never pull a line in from another part of the material, and never use a term ("the holes", "the window") before it's set up. If the source moment ends on a payoff number ("you get 22 and spend nothing more"), the post keeps it.
5. **End on something they can do.** The fix or the last slide names a concrete action the coach actually gives. If the source moment has no action in it, the post can't be a how-to, so make it a different kind of post or drop it.
6. **In a call, anchor the turn.** The line where the buyer's mind changed has to carry a post.

**Then review the whole week yourself.** Put the seven posts side by side against `plan.md`:
- Does any post make another post's point, use its example, or repeat its line? Rewrite or cut one of them.
- Would a stranger know each reel's topic from its first sentence, and want to keep watching after the second?
- Does it sound like the coach on the call, their words included, or like a copywriter?
- Is every fix one the coach actually gave?

Rewrite anything that fails, then run the checker once more.

### 8. Hand it over
- **The scripts:** save the final, checked drafts as `your-week.md`, ready to read from on camera. It holds the posts in day order, each under the same `## Day 1, reel: ...` heading as in the drafts (the checker splits posts on `## `), with the buyer section at the top and no working notes (the plan and checker notes stay out; each reel's Length and Show lines stay in).
- **The dashboard:** take `assets/dashboard.html` and replace `{{DATA}}` with the week as JSON (shape below). Each post's `body` is only what gets posted or said: the other two hook options at the top, then the script or the slides and the caption. Leave out "Answers:", "Length:", "Shape:" and every other working note. Save it as `your-week.html` and show it as an HTML artifact. Don't change anything else in the template. The buyer lists go in by weight, the most important first, not in the order they came up.
- **Check both files once more:** `python3 scripts/check.py your-week.md --source source.txt --voice voice.txt --buyer buyer.txt --week-plan plan.md --cta "<their call to action>" --proof "<their proof line, if they have one>" --signature "<their habit words>" --dashboard your-week.html`. Fix anything it lists.
- **The business file:** save `my-business.md` with the new buyer questions added. Only questions a buyer or the audience actually asked go in, never the coach's own.
- **Then one short message:** which post to film first and why (usually Day 1, because it answers what their buyer asked first), and a reminder to get the buyer's OK before posting anything drawn from a specific call. Nothing else: no pitch, no links.

The dashboard data:

```json
{
  "mode": "call, or video for a solo video",
  "note": "one line for the coach, only if something needs their attention (like a call to action that doesn't fit), otherwise empty",
  "coach": "their first name or brand",
  "week_of": "the date, if you know it",
  "source": "a 40-minute sales call",
  "buyer": {"questions": ["..."], "objections": ["..."], "words": ["..."], "want": "..."},
  "posts": [
    {"day": "day 1", "type": "reel", "title": "...", "answers": "the buyer question it answers",
     "hook": "the hook you'd pick", "on_screen": "the on-screen text", "body": "the full script, with the other two hook options at the top"}
  ],
  "clips": [{"start": "12:31", "end": "13:20", "hook": "...", "why": "..."}]
}
```

Leave `clips` empty for a sales call. For a carousel, `hook` is slide 1 and `on_screen` stays empty. Read every on-screen line once for grammar before it goes in. For a text post, `hook` is the first line and `on_screen` stays empty.

## If something's missing
- **No transcript, only a recording:** they can't upload audio or video here, so tell them how to get a transcript from the tool they recorded with, in one line.
- **A very short call** (under about 1,500 words): make fewer posts from it and don't stretch. Drop any day that has nothing real to build from, say which days are missing, and say that a second call would fill them.
- **A buyer who barely talks:** work from the questions the coach asked and what the buyer's answers reveal (their situation, what's missing, what they want). Label those as coming from the coach's questions.
- **No buyer in it** (a solo video, webinar or podcast): the "buyer" section becomes **what your audience is asking**: the questions the video answers, the beliefs it breaks, and the words it uses for the viewer's pain. Rank the questions the video asks itself first ("the next question is: why are most coaches still stuck?"), then its most repeated idea. The doubts its pitch heads off (budget, risk, who it isn't for) go beside the beliefs it breaks. The week changes too. Day 3 is the strongest belief the video breaks, and Day 7 is the best story the video tells. Every other day stays the same, built from the video's teaching moments.
- **A date you don't know:** leave `week_of` empty.
