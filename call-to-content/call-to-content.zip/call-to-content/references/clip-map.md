# The clip map (long videos only)

A webinar, a YouTube video or a podcast already holds a month of short clips. Most people spend days scrubbing for them. Find them in one pass.

## A good clip
- **Stands alone.** A stranger understands it without what came before. If it needs context, it isn't a clip.
- **Is one complete thought with a payoff,** 15-60 seconds long.
- **Works cold in its first three seconds.** It starts at a full sentence that doesn't open with a connector or refer back ("and", "so", "of", "like I said", "going back to"). If the original opening is slow, start the clip later, or give it a new spoken or on-screen hook.
- **Answers something the audience asks,** or breaks a belief they hold.

## What to hand back
8-15 clips, best first. For each one:
- the start and end time (from the transcript's timestamps; if there are none, quote the first and last few words so they can find it);
- a new hook in three options, using the reel hook rules (`references/reels.md`). Rotate the kinds of hook across the clips, so no opening ("You think...", "Most people...") leads more than three of them;
- the on-screen text;
- why it stands alone, in one line.

Skip anything that needs the slides on screen to make sense, unless the slide is part of the clip.

The clips go in the dashboard's `clips` list. The week of posts is still built as usual, from the video's teaching moments and the questions it answers.
