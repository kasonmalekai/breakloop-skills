# Captions and text posts

## A caption under a reel or carousel
One or two lines that say something the post doesn't. Never retell it. Use one of the buyer's own words for the pain. End with the coach's one call to action from the business file. No walls of hashtags, no em dashes, and no "comment below if you agree".

## A text post (Day 4 and Day 7)
A text post works on Instagram as the caption under a plain text image, or on LinkedIn or X on its own. 80-150 words, written the way the coach talks.
- **Day 4, the buyer's pain said back:** open with the situation in their words, paraphrased ("you've got the followers and the DMs, and the calendar's still empty"). Then name why it happens in one or two lines, and the first thing to do about it.
- **Day 7, the turn that makes it click:** open on the worry buyers like this one carry, written as the general situation (never as a story about this buyer, never "someone told me"). Then give the line the coach said that changes it, in the coach's words, and why it works for anyone in the same spot.

End both with the one call to action.
