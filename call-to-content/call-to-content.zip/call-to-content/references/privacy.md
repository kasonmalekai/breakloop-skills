# The privacy pass

The buyer on the call didn't agree to be in anyone's content. Protect them first, every time, before any writing starts.

1. **List everything that could identify the buyer:** their name and anyone else they name, their business or brand name, their handle, their city or country, their family details, their exact revenue or prices, their follower count, the names of their programs or clients, and any unusual detail someone who knows them would recognize.
2. **Make a cleaned copy of the transcript** with each of those replaced by a role ("the buyer", "their business", "[their niche]") and save it as `source.txt`. Work only from the cleaned copy.
3. **Never quote the buyer word for word in a post, and never retell the call as a story about one person.** Turn what they said into the general situation many buyers are in, in the coach's own words. Even "someone told me last week" points at a real person, and that person might be watching. Their exact words go only in the "what your buyer told you" section, which is for the coach's eyes.
4. **Never use the buyer's numbers** (their revenue, prices, follower count, results) in a post. The coach's own numbers about their own business are fine if the coach said them.
5. **If it's the coach's own client on the call,** be stricter still: nothing from the client's business goes in a post without the client's OK.
6. **A client's result the coach quotes** (in a call or in their own video) only goes in a post if the coach has already shared it publicly or the client agreed. If you can't tell, leave the number out, write `[CLIENT RESULT, IF CLEARED]`, and say so at the end.
7. **At the end,** remind the coach in one line to get the buyer's OK before posting anything drawn from a specific call.
