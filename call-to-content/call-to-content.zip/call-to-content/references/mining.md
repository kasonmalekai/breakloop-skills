# Mining the call

A sales call is the most honest market research a coach owns. The buyer says, in their own words, what they want, what scares them and what they've already tried. Pull all of it out before writing a single post.

## What to pull, with where it came from (a timestamp, or "early, middle, late")
1. **The questions the buyer asked,** in the order they asked them. The first question is usually the one their whole market is asking.
2. **The objections:** every moment they hesitated, pushed back or said "but". Note what they said and what was underneath it.
3. **The belief behind each objection:** the thing they assume is true that makes them hesitate ("I need more followers first", "ads don't work for my niche", "my buyers can't afford it").
4. **Their words for the pain.** The nouns and phrases they used for their problem, exactly as said ("stuck at the same number", "the leads are broke", "I'm still the closer"). These become hooks, because buyers stop scrolling for their own words.
5. **What they want,** in their words, the outcome and the life it buys.
6. **What they've already tried** that didn't work, and why it didn't.
7. **The step nobody named for them:** the missing step between two things they already know ("they know they need content and they know they need calls, and nobody told them about the step in between").
8. **The coach's best explanations:** the moments the coach explained something clearly and the buyer reacted ("oh, that makes sense", a pause, a follow-up question). These are ready-made scripts.
9. **The moment it clicked:** where the buyer's tone changed.

## What doesn't count
- **The coach's own questions** never go under "what they asked". If the buyer asked nothing, leave it empty and work from what their answers reveal.
- **The coach offering terms** (a payment plan, deferring a fee) isn't a buyer hesitation. Only list what the buyer pushed back on.
- **Something said once in passing** that no stranger in the market would recognize.

## How to rank
Put first whatever the buyer themselves called the biggest, the main thing, or the hardest part: their own weight words beat the order things came up in. Then whatever was said more than once, or with the most feeling, then whatever was asked first. Every belief you list needs a quote from the buyer that shows they hold it: if the quote says the opposite, it isn't their belief. Never answer a question only the closer asked. Drop anything only this one buyer would ever care about. The test is whether a stranger in the same market would recognize themselves in it.

## Write it down
List each item with its rank and its source moment in your working notes. The top four questions, the top three objections, the six strongest buyer words and the one-line want go into the dashboard's buyer section.
