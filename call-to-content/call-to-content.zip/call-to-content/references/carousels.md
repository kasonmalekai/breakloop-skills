# Writing the carousels

Pick the shape from the idea, never by rotation. Six shapes cover almost everything:

1. **Counted list:** the cover states the count flat, then one item per slide, weakest first and best last, then all items together as a checklist, then the call to action. Use it when the idea really has parts. It fails when the items are one item said three ways.
2. **Myth then receipt:** the cover is the myth in the buyer's words, then why it sounds right, then the one mechanism that breaks it, then the proof (only real proof from the material), then what to do instead. Use it when the audience holds a belief that's costing them. It fails when nobody actually believes the myth.
3. **Two ways side by side:** name both sides on the cover, then the split, side A, side B, and the one difference that matters. Use it for before and after, or this against that. It fails when the difference is cosmetic.
4. **Walk the thing:** a real process on a real example, one step per slide, in order. Use it only when people actually want to see the process.
5. **One idea deep:** the claim, the situation they're in, the mechanism, what it costs them, and what to do. It's the default shape, so it's the easiest one to reach for lazily. Make sure the idea is worth six slides.
6. **Diagnose then prescribe:** the symptom in their words, what it usually gets blamed on, what it actually is, and a test they can run today. Use it when a problem has more than one likely cause and they're fixing the wrong one.

## Slide rules
- **Slide 1 names the reader's own thing:** their show rate, their DMs, their next hire. It's never about the coach's process or a client's case.
- **Slide 2 works as a second hook** for someone who skipped slide 1.
- One idea per slide, short enough to read in two seconds.
- **The cover states its claim.** A bare question ("where is your webinar leaking?") is weaker than the answer said as a claim.
- No recap slide that only repeats the slides before it.
- End on something the reader can do today, and name the actual action ("count how many minutes of your last five calls went on explaining who you are"), never a direction like "get one thing working". That's what gets saves and sends.
- No invented numbers. A real number from the material is the strongest slide there is. Otherwise use none.

## In each carousel's entry
Give the title, the buyer item it answers, the shape you picked and why in one line, then every slide's text ("Slide 1: ..."), and the caption.
