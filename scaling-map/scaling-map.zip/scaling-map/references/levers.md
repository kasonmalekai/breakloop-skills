# The levers, the order rules, and the mistakes

## The levers, by constraint (do them in this order)
- **Not measured:** set up tracking for that stage first. Take cash from the payment processor, not from what the calendar or the CRM says.
- **The offer:** rewrite what they sell so someone would pay $5K to $10K and a 12-year-old could say it back. Then the bonuses, then the guarantee. Only then the funnel.
- **Opt-in or booking low:** one promise from the ad to the page to the confirmation, the same words all the way. Nothing logistical between "yes" and the calendar. A rate in the low single digits is probably broken, not a test to split.
- **Webinar booking low:** say exactly what the call is and what they get on it, in the buyer's words, then where the link sits and when it's said. Follow up the same day with everyone who stayed to the pitch and didn't book, and with the replay viewers. Use only real scarcity: the actual number of call slots this week.
- **Show rate low:** check the reminders actually send. Then sort the no-shows: were they not excited, not sure about the coach, or was it the time? Then a real reason to be on time. A person confirming within minutes of the booking, and call slots inside 72 hours.
- **Close low:** what buyers watch before the call, then who's booking (lead quality), then how deep the questions on the call go, then whether the price is clear. The script last.
- **Cost per call high:** the creative first, then the message, then the shape of the funnel. The offer last.
- **The seats are full:** raise the price or start a waitlist. Hire before the calendar passes 80%.
- **Every stage at its floor:** more people in, from the channel that already converts. Paid only once the funnel converts without it.

## What comes before what
1. **The offer before the funnel.**
2. **Find the constraint, tighten what's there, then scale spend** once the numbers hold.
3. **Paid multiplies the rate a funnel already has.** If 12% of free leads buy, about 12% of paid leads buy, and the coach pays for the rest. Fix the rate before buying traffic.
4. **One change at a time,** with the result that ends it written down before it starts. Measure again every 30 days.
5. **A call funnel is judged at 30 days at the earliest,** scaled at 60, stopped at 90. A webinar's cash comes in over about 10 to 14 days after the event.
6. **The price only goes up.** A falling close rate means fix the offer or the call, never discount.
7. **One front door until it's full.** Closers with no free seats don't count as full.
8. **Never run a fix at the same time as the upstream fix it depends on.**

## The mistakes to avoid
Pick the one that matches what they told you they tried:
- **Spending more on a funnel that leaks.** Doubling traffic doubles the people falling out of the same hole.
- **Fixing the number that's easiest to see** while the broken one stays.
- **Retraining or replacing closers** before checking what buyers saw before the call and who's booking.
- **Starting with show-up** when another stage is further off: show is rarely the biggest constraint.
- **A new funnel or channel when the seats are full.**
- **Judging on revenue that's contracted, not cash that came in,** or on blended numbers across different traffic.
- **Killing a test on one night or one week,** or changing several things at once.
- **Discounting after a weak close,** or adding a cheap checkout beside a call funnel.
- **Fake urgency:** countdowns and expiring links.
- **Grading their numbers against someone else's kind of traffic.**
