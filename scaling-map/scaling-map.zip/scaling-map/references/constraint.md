# Finding the one constraint

There is one constraint at a time: the stage that, fixed, moves cash the most. Fixing anything else first is busy work.

## The order
1. **Measure first.** A stage with no number can't be judged, so measuring it comes before everything. Bad tracking is the most common hidden constraint.
2. **Anything broken.** A reminder that doesn't send, a dead calendar link, a sequence that stopped: these come before any rate. A number wildly off its target is treated as broken until checked.
3. **The seats.** If the people taking calls are booked past about 80% of what they can take (count bookings, since a no-show still takes the slot), follow-up slips and every lead starts to look bad. More leads won't help until there are more seats or the price goes up. When something broken and the seats are both true, name the broken thing first and the seats as the very next step, and say why in a line.
4. **The stage furthest below its floor,** as a ratio: the floor divided by their rate. 4% against a floor of 20% is 5 times short; 45% against 70% is about 1.6 times. The biggest ratio wins. On a near tie, fix the one upstream first.
5. **Every stage at or above its floor** means the funnel works: the constraint is how many people enter it.

The script does 1, 3, 4 and 5. Number 2 and the offer check are yours, from what they told you.

## Before the funnel: the offer
If nearly every stage is weak, or they're under about $30K to $50K a month with few referrals **and** the close rate is weak too, the constraint is the offer. A strong close means the offer sells to the people who reach the call, and the funnel is the constraint. Two quick tests: would someone pay $5K to $10K for it, and could a 12-year-old say back what it does? Fix the offer before touching the funnel.

## Before more traffic: the backend
Ask: if every ad stopped tomorrow, what revenue would still come in? If the answer is close to nothing and they sell one thing once, what a customer is worth over time is thin, and buying more traffic only buys a thinner margin.

## Reading the targets
- **Grade only against their own kind of traffic.** Strangers from ads, followers and a warm list behave differently, and their targets differ. Never mix them.
- **Their own last month comes first.** A target is a reported number from operators, not a measured norm. Moving up from where they were is the real test.
- **How the show rate is counted matters.** Calls that happened divided by every booking whose date has passed. Divided only by the bookings someone logged, it reads high.
- **Close is on calls that happened,** never on bookings.
