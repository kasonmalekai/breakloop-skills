---
name: scaling-map
description: Paste your numbers and get the math to your next revenue number, the one stage holding your funnel back, the levers in order, and a week-by-week plan.
---

# The scaling map

Most coaches stuck at a number fix the step that's easiest to see: more ads, a new closer, a new funnel. The number that's actually holding them back is usually somewhere else. This skill takes their real numbers, finds the stage furthest below where it should be for their kind of traffic, works out what fixing it is worth, and lays out the next six weeks, one change at a time.

The person using this is busy and not technical. Ask once, do the math with the script, and hand back a plan they can start Monday.

## What to hand back
1. **The math to their next number:** what it takes a month, a week and a day at their current rates.
2. **Their funnel, stage by stage,** against targets for their kind of traffic, with what each weak stage is worth.
3. **The one constraint,** in a sentence, and what fixing it is worth a month.
4. **The levers for it, in order,** with what to do this week.
5. **Six weeks, week by week:** one change at a time, the number to watch, and when to measure again.
6. **The mistake to avoid,** chosen against what they've already tried.
7. **What's likely next,** once this one is fixed.
8. **The dashboard** (`assets/dashboard.html`, in map mode) and **their business file** (`my-business.md`).

## Steps

### 1. Get their numbers
Read `references/business-file.md` and follow it, and read `my-business.md` if they dropped it in. Then ask, in one numbered message, only what you don't have yet:

1. **What you sell, and who buys it.**
2. **Where you are, and the number you want next:** cash collected a month now, and the month you're aiming for. (Put the first in `numbers.json` as `cash_now`: the script checks whether this funnel accounts for it.)
3. **How people buy:** straight to a call (from ads, content or DMs), or a webinar first and then a call?
4. **Where most of them come from:** paid ads to strangers, people who already follow you, or your list, past buyers and referrals?
5. **Your numbers for the last 4 weeks** (and the 4 weeks before, if you have them, so we can see the direction): new leads (opt-ins, registrants or new conversations), calls booked, calls that happened, sales, and the cash that actually came in per sale (not the price). For a webinar: how many attended live, and how many were still there at the pitch. If you run ads: clicks and ad spend.
6. **Who takes the calls,** and how many calls each person can take in a week. If a setter books calls too, how many of the bookings each of you made.
7. **What you've tried in the last 90 days** to grow.
8. **Anything you already know is broken:** a reminder that doesn't send, a calendar link, tracking you don't trust.

Tell them how to count calls that happened: **divide by every booking whose date has passed, and count a booking nobody logged as a no-show.** Other ways of counting make the show rate look better than it is.

Their numbers stay in this chat. Never write them into `my-business.md`, which only keeps what they sell, who buys, how they sell and what they've tried. Save everything they said about their business as `mine.txt`.

If a number is missing, don't guess it: leave it out, and the plan starts by measuring it.

### 2. Do the math with the script
Write their numbers into `numbers.json` (the format is at the top of `scripts/scaling_map.py`) and run:

```
python3 scripts/scaling_map.py numbers.json
```

It grades each stage against the targets for their funnel and traffic, finds the constraint, works out what each weak stage is worth, and works back from their goal to what they need a month, a week and a day. It writes `map.json` and `math.txt`. **Every number in the plan comes from the script, never from your own arithmetic.** If they change a number, run it again. If it prints **CHECK FIRST**, the funnel doesn't account for the cash they said. Stop and ask, in one message, everything still missing at once: where the rest of the cash comes from (payment plans landing from earlier sales, renewals, referrals, a second offer), anything broken, bookings whose date has passed, and what the call itself gives their buyer. If you truly can't wait for the answer, run the script twice (this funnel only, and with `other_cash_a_month` set to the difference, labelled "if"), and mark which numbers move with the answer. Put their answer in `numbers.json` as `other_cash_a_month` and run it again, so the plan only asks this funnel for its share of the goal. Stages marked **an early sign** have fewer than 20 to judge: say "an early sign", never a verdict. If it prints **SEATS AT THE GOAL**, the plan includes when to add seats or raise the price.

### 3. Read the constraint like an operator
Follow `references/constraint.md`. The script applies the order: measure first, then seats, then the stage furthest below its floor. Two checks only you can make, from what they told you:
- **The offer.** If nearly every stage is weak, or they're under about $30K to $50K a month with few referrals, the constraint is the offer, not the funnel. Say so before anything else.
- **Something broken.** Anything they said is broken comes before any rate: a reminder that never sends is the problem, not the show rate.

Write the constraint in one sentence, in their words, with the number that proves it.

### 4. Write the plan
Follow `references/levers.md` for the levers in order, the rules about what comes before what, and the mistakes. Then write `your-map.md`:

- **The math:** the script's backward numbers, in plain words ("about 4 sales a week, so about 20 calls held, so about 43 booked").
- **Your funnel, stage by stage:** each rate against its target, with the target's label exactly as the script gives it. **Targets are reported, not guaranteed,** and their own last month is the first comparison. Say it once, plainly.
- **The one constraint,** and what it's worth a month (from the script).
- **The levers, in order,** and what to do this week.
- **Six weeks, each in the same shape:** a line starting "Week 1", "Week 2"..., then the one change (or "hold": run it unchanged and measure), the number to watch, and "done when" with the result that ends it, as a number. Something to measure or ask (sorting no-shows, counting page visits) runs alongside a change and never takes a week of its own. A fix to the show rate is judged on at least two weeks of bookings, never one. Exactly one change per stage per cycle: two edits to the same step at once is two changes. If they run something on a cadence (a webinar every two weeks), put one change per run, on their real dates. Measure again at 30 days, and never a downstream fix before the upstream one it depends on.
- **Draft the first change for them,** in their buyer's words, from what they told you (what the call gives, who it's for). "Rewrite your invite" is a chore; the new invite is the help.
- **Each lever names who does it in their setup, and with what** (the setter they already pay, their email tool, their calendar). What they tried is evidence: use it ("split the show rate by who booked the call: you or the setter").
- **Every target says "reported"** wherever it's named, the constraint line and the final message included. A stage with no target is "not graded", never "fine", and the dashboard flag is the script's own (below the floor, at or above the floor, not graded, or the constraint).
- **Prove an override with the number.** If you name a different constraint from the script's, give the number that shows why. Never talk about "the script" to them: say what the numbers show.
- **The mistake to avoid:** the one from `references/levers.md` that matches what they tried.
- **What's likely next:** the next-weakest stage, once this one is at its floor. Use the script's "every weak stage at its floor" line to say how much of the gap the funnel can close and how much needs more people.

**Say every rate the way the script says it "in words"** ("30 of your 66 past bookings happened; 36 didn't"), never a percentage with its meaning flipped. Any "done when" for the show rate uses the script's own "done when" line (its two-week or four-week figure), never a target you work out yourself. Put the script's SEATS TRIGGER in the six weeks as a line with its number.

**Every "done when" is a number that can fail,** from the script's numbers (never "or you know...").

**An early sign is never a verdict:** a stage marked an early sign doesn't prove or rule out the offer, and a stage below its floor is never described as working. "Worth" always comes with "at the floor".

**Use the script's words for each stage** ("at or above the floor", "at or above the top of the reported range"), never your own shorthand. **If they gave no earlier period, say so** ("no earlier month given") instead of telling them to beat their last month. **Quote their own words exactly:** "a couple of people" stays a couple, never "two". **What they tried is what they did, not what it caused.** Never state the result of something they tried ("doubling the budget doubled the empty calls") unless they gave numbers from before and after. A stage marked "not graded" can't be called fine, and can't be ruled out as the constraint. Say once in the plan itself that these are their own numbers, unchecked.

Plain words, their numbers, no hype. Never promise a result: this is the math on their own numbers, and the numbers are theirs. Name their business (who they serve, what they sell) so the plan is theirs, not a template. Every share or comparison comes from the script ("closes about 37% of the gap"), never from an estimate. List items in the dashboard carry no numbers of their own: the template numbers them.

### 5. Check it before they see it
Put what they told you and the script's numbers in one file, then run the checker:

```
cat mine.txt math.txt > source.txt
python3 scripts/check.py your-map.md --source source.txt --plan --not-from references --dashboard your-map.html
```

Fix anything it lists, and run the same check on `final-message.md`. **Then read it as a seasoned operator would:**
1. Would they pick the same constraint, given everything the coach said?
2. Does every number trace to `map.json` or to what the coach said?
3. Is it one change at a time, with a number that says when it's done?
4. Is anything promised, or anything said as fact that's really a target?

### 6. Hand it over
- **The plan:** `your-map.md`.
- **The dashboard:** take `assets/dashboard.html` and replace `{{DATA}}` with the JSON below. Save it as `your-map.html` and show it as an HTML artifact. Don't change anything else in the template.
- **The business file:** save `my-business.md`, with no numbers in it.
- **Then one short message:** the constraint in one line, the first thing to do this week, and when to run this again (in 30 days, with the new numbers). Nothing else: no pitch, no links.

The dashboard data:

```json
{
  "mode": "map",
  "coach": "their first name or brand, if they gave it",
  "source": "your last 4 weeks of numbers",
  "note": "your own numbers, unchecked; the targets are reported targets, not guarantees",
  "buyer": {
    "questions": ["where they are: cash a month now, the goal, and the gap, one line each"],
    "objections": ["the levers for the constraint, in order"],
    "words": ["the mistake to avoid, and why it matches what they tried"],
    "want": "the one constraint, in a sentence"
  },
  "stages": [{"stage": "call show", "flag": "the constraint, below the floor, at or above the floor, or not graded", "what": "46% against a target of 50% to 60%",
              "why": "the target's label", "leak": "what reaching the floor is worth a month"}],
  "posts": [{"day": "week 1", "type": "week", "title": "the one change", "hook": "the number to watch, and the result that ends it",
             "body": "what to do, step by step"}],
  "clips": [{"start": "sales", "end": "17 a month", "hook": "3.8 a week", "why": "0.6 a day"}]
}
```

`stages` lists every stage from the script, `posts` has one entry per week, and `clips` is the math to the goal.

## If something's missing
- **No numbers at all:** ask for the four that matter most (calls booked, calls that happened, sales, cash per sale), and say the plan can only be as good as these.
- **A brand-new offer with no sales yet:** this isn't the tool yet. Say the first job is ten sales by hand, and what to track while doing it.
- **Numbers that look impossible** (more sales than calls, a 100% show rate): ask once before running the math.
