#!/usr/bin/env python3
"""The scaling map's math. Every number in the plan comes from here, never from mental arithmetic.

Usage:
    python3 scripts/scaling_map.py numbers.json

numbers.json (leave out what they don't know; a missing stage becomes "measure it first"):
{
  "funnel": "call" or "webinar",
  "class": "cold" (paid strangers), "semi-warm" (people who follow them) or "warm" (their list, past buyers, referrals),
  "period_weeks": 4,                 the weeks these numbers cover
  "goal_cash": 100000,               cash collected a month they want to reach
  "cash_now": 45000,                 optional: cash collected a month, as they told you
  "other_cash_a_month": 15000,       optional: cash from outside this funnel (renewals, referrals, a second offer)
  "cash_per_close": 6000,            cash actually collected per sale (not the sticker price)
  "clicks": 8000,                    optional: clicks to the page
  "leads": 400,                      opt-ins, registrants or new conversations
  "attended": 120, "at_pitch": 96,   webinar only: who showed up live, and who was still there at the pitch
  "booked": 60,                      calls booked
  "booked_past": 55,                 bookings whose date has passed (defaults to booked)
  "held": 33,                        calls that happened
  "closes": 7,                       sales
  "ad_spend": 9000,                  optional, for the period
  "closers": 1, "calls_per_closer_week": 20,  optional: who takes the calls, and how many each can take a week
  "previous": {"leads": 180, "booked": 50, "held": 26, "closes": 5}   optional: the 4 weeks before, same fields
}

Writes map.json (everything computed) and math.txt (every number, for check.py's --source), and
prints the stage table, the constraint, what fixing it is worth, and the math to the goal.
Standard library only.
"""
import json
import math
import sys

WEEKS_PER_MONTH = 4.33

# Targets by funnel and traffic class: (floor, top, label). Every one is a reported target, not a
# measured norm; grade a coach first against their own last cycle, and only against their own class.
BANDS = {
    ("call", "cold"): {"show": (0.50, 0.60, "reported average for paid call funnels"),
                       "close": (0.15, 0.20, "reported for cold paid call funnels")},
    ("call", "semi-warm"): {"show": (0.70, 0.90, "target for followers"),
                            "close": (0.20, 0.30, "target for followers")},
    ("call", "warm"): {"show": (0.85, 0.90, "reported for warm, self-reported"),
                       "close": (0.50, 0.70, "reported for warm, self-reported")},
    ("webinar", "cold"): {"opt_in": (0.20, 0.50, "reported for cold webinar pages"),
                          "attend": (0.20, 0.30, "reported: about 20% average, 30%+ good"),
                          "retention": (0.80, 1.00, "reported: still there at the pitch"),
                          "book": (0.30, 0.40, "reported: of those at the pitch"),
                          "show": (0.70, 0.80, "reported minimum for webinar calls"),
                          "close": (0.35, 0.45, "reported floor on shown calls")},
}
for cls in ("semi-warm", "warm"):  # a warmer webinar room is graded at least as hard as a cold one
    room = {}
    for k, (lo, hi, label) in BANDS[("webinar", "cold")].items():
        call = BANDS[("call", cls)].get(k)
        if call and call[0] > lo:
            room[k] = (call[0], max(hi, call[1]), f"{call[2]} (higher than the cold-webinar floor)")
        else:
            room[k] = (lo, hi, label.replace("reported", "reported for cold webinars; a warmer room should do at least this"))
    BANDS[("webinar", cls)] = room

NAMES = {"opt_in": "page opt-in (leads per click)", "attend": "attendance (attended per registrant)",
         "retention": "retention (at the pitch per attendee)",
         "book": "booking (booked per lead)" , "show": "call show (held per booking whose date has passed)",
         "close": "close (sales per call held)"}


def r(x, d=1):
    return None if x is None else round(x, d)


def pct(x):
    return "unknown" if x is None else f"{100 * x:.0f}%"


def money(x):
    if x is None:
        return "unknown"
    return f"${x:,.0f}"


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    n = json.load(open(sys.argv[1], encoding="utf-8"))
    funnel = n.get("funnel", "call")
    cls = n.get("class", "semi-warm")
    weeks = float(n.get("period_weeks") or 4)
    per_month = WEEKS_PER_MONTH / weeks
    g = lambda k: (float(n[k]) if n.get(k) not in (None, "") else None)
    clicks, leads, attended, at_pitch = g("clicks"), g("leads"), g("attended"), g("at_pitch")
    booked, held, closes, cpc = g("booked"), g("held"), g("closes"), g("cash_per_close")
    booked_past = g("booked_past") or booked
    spend, goal = g("ad_spend"), g("goal_cash")

    def ratio(a, b):
        return (a / b) if (a is not None and b) else None

    rates = {}
    if funnel == "webinar":
        rates = {"opt_in": ratio(leads, clicks), "attend": ratio(attended, leads),
                 "retention": ratio(at_pitch, attended), "book": ratio(booked, at_pitch or attended),
                 "show": ratio(held, booked_past), "close": ratio(closes, held)}
    else:
        rates = {"opt_in": ratio(leads, clicks), "book": ratio(booked, leads),
                 "show": ratio(held, booked_past), "close": ratio(closes, held)}
    entering = {"opt_in": clicks, "attend": leads, "retention": attended, "book": at_pitch or attended or leads,
                "show": booked_past, "close": held}
    if funnel != "webinar":
        entering["book"] = leads
    if funnel == "webinar":
        NAMES["book"] = "booking (booked per attendee at the pitch)"
    bands = BANDS.get((funnel, cls), {})
    order = [k for k in ("opt_in", "attend", "retention", "book", "show", "close") if k in rates]

    cash_period = (closes * cpc) if (closes is not None and cpc) else None
    cash_month = cash_period * per_month if cash_period is not None else None

    stages, missing = [], []
    for k in order:
        actual = rates[k]
        band = bands.get(k)
        short = None
        if actual is None:
            if k != "opt_in" or clicks is not None:
                missing.append(k)
        elif band and actual < band[0]:
            short = band[0] / max(actual, 1e-9)
        # what reaching the floor is worth a month: units entering x the gap x every later actual rate x cash
        worth = None
        if band and actual is not None and actual < band[0] and entering.get(k) and cpc:
            later = 1.0
            for k2 in order[order.index(k) + 1:]:
                if rates[k2] is None:
                    later = None
                    break
                later *= rates[k2]
            if later is not None:
                worth = entering[k] * (band[0] - actual) * later * cpc * per_month
        early = bool(entering.get(k) is not None and entering.get(k) < 20)
        flag = ("not graded" if not band else ("no number" if actual is None else
                ("below the floor" if actual < band[0] else "at or above the floor")))
        stages.append({"stage": k, "name": NAMES[k], "actual": r(actual, 4), "early_sign": early, "flag": flag, "floor": band[0] if band else None,
                       "top": band[1] if band else None, "label": band[2] if band else "no target for this class: "
                       "compare with your own last month", "shortfall": r(short, 2), "worth_a_month": r(worth, 0)})

    # every rate in plain words: "x of y", and the other side of it
    words = {
        "opt_in": ("visitors opted in", leads, clicks), "attend": ("registrants came live", attended, leads),
        "retention": ("of those who came live were still there at the pitch", at_pitch, attended),
        "book": ("booked a call", booked, (at_pitch or attended) if funnel == "webinar" else leads),
        "show": ("of the bookings whose date has passed happened", held, booked_past),
        "close": ("of the calls that happened became a sale", closes, held)}
    for s in stages:
        w = words.get(s["stage"])
        if w and w[1] is not None and w[2]:
            did, of = int(round(w[1])), int(round(w[2]))
            s["in_words"] = (f"{did} of {of} {w[0]} ({pct(did / of)}); {of - did} didn't ({pct((of - did) / of)})")
            if s["stage"] == "show" and of >= 20:
                # two weeks of bookings at this volume: the smallest change that's more than noise (about 2 standard errors)
                p_ = w[1] / w[2]
                per_week = max(0.5, (booked_past or 0) / weeks)
                s["smallest_real_change"] = r(2 * math.sqrt(p_ * (1 - p_) / (per_week * 2)), 2)
                s["smallest_real_change_4_weeks"] = r(2 * math.sqrt(p_ * (1 - p_) / (per_week * 4)), 2)

    # capacity: closers booked past about 80% stop following up, and every lead starts to look bad
    capacity = None
    if g("closers") and g("calls_per_closer_week") and booked is not None:
        seats = g("closers") * g("calls_per_closer_week")
        load = (booked / weeks) / seats
        held_load = ((held or 0) / weeks) / seats
        capacity = {"booked_a_week": r(booked / weeks, 1), "held_a_week": r((held or 0) / weeks, 1), "seats_a_week": seats,
                    "load": r(load, 2), "held_load": r(held_load, 2), "over": load > 0.8,
                    "no_shows_fill_it": load > 0.8 and held_load < 0.6}

    # the one constraint: measurement first, then seats, then the biggest shortfall ratio (upstream wins ties)
    prev = n.get("previous") or {}
    if prev:
        pr = {"book": ratio(prev.get("booked"), prev.get("at_pitch") or prev.get("leads")) if funnel == "webinar"
              else ratio(prev.get("booked"), prev.get("leads")),
              "show": ratio(prev.get("held"), prev.get("booked_past") or prev.get("booked")),
              "close": ratio(prev.get("closes"), prev.get("held")),
              "attend": ratio(prev.get("attended"), prev.get("leads")),
              "retention": ratio(prev.get("at_pitch"), prev.get("attended")),
              "opt_in": ratio(prev.get("leads"), prev.get("clicks"))}
        for s in stages:
            if pr.get(s["stage"]) is not None:
                s["before"] = r(pr[s["stage"]], 4)
    graded = [s for s in stages if s["shortfall"]]
    if missing:
        constraint = {"kind": "measurement", "stage": missing[0],
                      "why": f"no number for {NAMES[missing[0]]}: it can't be judged, so measuring it comes first"}
    elif capacity and capacity["over"] and capacity["no_shows_fill_it"] and rates.get("show") is not None:
        constraint = {"kind": "stage", "stage": "show",
                      "why": f"the calendar is booked at {pct(capacity['load'])} of the seats, but only {capacity['held_a_week']} "
                             f"calls a week happen ({pct(capacity['held_load'])} of the seats): no-shows are filling the calendar, "
                             f"so the show rate ({pct(rates['show'])}) is the constraint, and fixing it frees the seats"}
    elif capacity and capacity["over"]:
        constraint = {"kind": "capacity", "stage": "show",
                      "why": f"the closers are booked at {pct(capacity['load'])} of what they can take; past about 80%, "
                             "follow-up slips and every lead starts to look bad"}
    elif graded:
        top = max(graded, key=lambda s: s["shortfall"])
        close_calls = [s for s in graded if s["shortfall"] >= 0.9 * top["shortfall"]]
        pick = min(close_calls, key=lambda s: order.index(s["stage"]))  # upstream first on a near tie
        constraint = {"kind": "stage", "stage": pick["stage"],
                      "why": f"{NAMES[pick['stage']]} is {pct(pick['actual'])} against a floor of {pct(pick['floor'])} "
                             f"({pick['label']}): {pick['shortfall']}x short, the furthest of any stage"}
    else:
        constraint = {"kind": "volume", "stage": "leads",
                      "why": "every measured stage is at or above its floor, so the limit is how many people enter"}

    # does this funnel account for the cash they say they make?
    stated = g("cash_now")
    gap_note = None
    if stated and cash_month:
        share = cash_month / stated
        if share < 0.75 or share > 1.33:
            gap_note = (f"they say about {money(stated)} a month, but these numbers make about {money(cash_month)}: "
                        "either other income (renewals, a second offer, payment plans landing from earlier sales) or a "
                        "counting gap. Ask which, and say this map covers only this funnel")

    # what each stage would need, working back from the goal
    other = g("other_cash_a_month") or 0
    funnel_goal = (goal - other) if goal else None
    backward = None
    if funnel_goal and cpc:
        need = {"closes": funnel_goal / cpc}
        chain = [("close", "held"), ("show", "booked")]
        if funnel == "webinar":
            chain += [("book", "at_pitch"), ("retention", "attended"), ("attend", "leads"), ("opt_in", "clicks")]
        else:
            chain += [("book", "leads"), ("opt_in", "clicks")]
        last = "closes"
        for stage_key, unit in chain:
            rate = rates.get(stage_key)
            if rate:
                need[unit] = need[last] / rate
                last = unit
            else:
                break
        def tidy(x):
            return int(round(x)) if x >= 10 else r(x, 1)
        backward = {k: {"a_month": (math.ceil(v) if k == "closes" else r(v, 0)), "a_week": tidy(v / WEEKS_PER_MONTH),
                        "a_day": tidy(v / 30)} for k, v in need.items()}

    # what the funnel makes if every weak stage just reaches its floor, and what's left for more people to cover
    flow = [k for k in order if k != "opt_in"]
    at_floors = None
    if leads and cpc and all(rates[k] is not None for k in flow):
        prod_now = prod_floor = 1.0
        for k in flow:
            prod_now *= rates[k]
            prod_floor *= max(rates[k], bands[k][0]) if k in bands else rates[k]
        lift = prod_floor / prod_now if prod_now else 1.0
        cash_floor_month = (cash_month or 0) * lift
        at_floors = {"cash_a_month": r(cash_floor_month, 0)}
        if goal:
            fgoal = goal - (g("other_cash_a_month") or 0)
            chain_floor = 1.0
            for k in flow:
                chain_floor *= max(rates[k], bands[k][0]) if k in bands else rates[k]
            at_floors["leads_a_month_for_goal_at_floors"] = r(fgoal / cpc / chain_floor, 0) if chain_floor else None
            at_floors["leads_a_month_now"] = r(leads * per_month, 0)
            if cash_month is not None and fgoal > cash_month:
                at_floors["share_of_gap_the_floors_close"] = r((cash_floor_month - cash_month) / (fgoal - cash_month), 2)

    economics = {}
    if spend:
        economics["cash_return_on_ad_spend"] = r(cash_period / spend, 2) if cash_period else None
        economics["cost_per_held_call"] = r(spend / held, 0) if held else None
        economics["cost_per_booked_call"] = r(spend / booked, 0) if booked else None
    if cash_period is not None and booked:
        economics["cash_per_booked_call"] = r(cash_period / booked, 0)

    out = {"funnel": funnel, "class": cls, "other_cash_a_month": other or None, "period_weeks": weeks, "cash_now_a_month": r(cash_month, 0),
           "goal_cash": goal, "stages": stages, "capacity": capacity, "constraint": constraint,
           "stated_cash_gap": gap_note, "the_math_to_the_goal": backward, "every_weak_stage_at_its_floor": at_floors, "economics": economics,
           "note": "These are their own reported numbers, unchecked. Targets are reported targets, not measured norms."}
    json.dump(out, open("map.json", "w"), indent=2)

    nums = []
    def walk(x):
        if isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
        elif isinstance(x, (int, float)) and not isinstance(x, bool):
            nums.append(x)
    walk(out)
    walk(n)
    # the rules' own numbers (from references/), so the plan can quote them
    nums += [80, 0.8, 72, 30, 60, 90, 5000, 10000, 30000, 50000, 0.12, 0.7, 0.6]
    lines = [str(int(v)) if float(v).is_integer() else str(v) for v in nums]
    lines += [f"{round(100 * v)}%" for v in nums if isinstance(v, float) and 0 < v <= 1.5]
    lines += [money(v) for v in nums if v and v >= 100]
    open("math.txt", "w").write("\n".join(lines) + "\n")

    print(f"{funnel} funnel, {cls} traffic, {weeks:g} weeks of numbers; cash now about {money(cash_month)} a month")
    for s in stages:
        band = f"{pct(s['floor'])} to {pct(s['top'])}, reported" if s["floor"] is not None else "no target: not graded"
        flag = f"  {s['shortfall']}x short" if s["shortfall"] else ""
        if s.get("early_sign"):
            flag += "  (fewer than 20 to judge: an early sign, not a verdict)"
        worth = f", worth about {money(s['worth_a_month'])} a month at the floor" if s["worth_a_month"] else ""
        before = f", was {pct(s['before'])} the period before" if s.get("before") is not None else ""
        print(f"  {s['name']}: {pct(s['actual'])}{before} (target {band}){flag}{worth}")
        if s.get("in_words"):
            print(f"      in words: {s['in_words']}")
        if s.get("smallest_real_change"):
            print(f"      noise: over two weeks of bookings a change under about {pct(s['smallest_real_change'])} can't be "
                  f"told from chance; over four weeks, about {pct(s['smallest_real_change_4_weeks'])}. Judge a fix over "
                  "the window where the change you're after is bigger than that")
    if capacity:
        no_shows = (capacity["booked_a_week"] or 0) - (capacity["held_a_week"] or 0)
        print(f"      in words: about {capacity['booked_a_week']} calls booked a week, {capacity['held_a_week']} happen and "
              f"about {no_shows:.1f} are no-shows, against {capacity['seats_a_week']:g} seats")
        print(f"  closers: {capacity['booked_a_week']} booked and {capacity['held_a_week']} held a week, of "
              f"{capacity['seats_a_week']:g} seats ({pct(capacity['load'])} booked, {pct(capacity['held_load'])} held)")
    for k, v in economics.items():
        print(f"  {k.replace('_', ' ')}: {v:g}" if isinstance(v, (int, float)) else f"  {k.replace('_', ' ')}: {v}")
    print(f"THE CONSTRAINT: {constraint['why']}")
    if at_floors:
        line = f"with every weak stage at its floor: about {money(at_floors['cash_a_month'])} a month"
        if at_floors.get("leads_a_month_for_goal_at_floors"):
            line += (f"; the goal then needs about {at_floors['leads_a_month_for_goal_at_floors']:,.0f} leads a month "
                     f"(now about {at_floors['leads_a_month_now']:,.0f})")
        if at_floors.get("share_of_gap_the_floors_close") is not None:
            line += f"; fixing the funnel closes about {pct(at_floors['share_of_gap_the_floors_close'])} of the gap"
        print(line)
    if gap_note:
        print(f"CHECK FIRST: {gap_note}")
    if capacity and backward and backward.get("held"):
        need_week = backward["held"]["a_week"]  # calls that happen fill the seats once no-shows are fixed
        trigger = 0.8 * capacity["seats_a_week"]
        print(f"SEATS TRIGGER: when calls held reach about {trigger:g} a week (80% of {capacity['seats_a_week']:g} seats), "
              "add a person on calls or raise the price")
        if need_week > trigger:
            more = "more than all" if need_week > capacity["seats_a_week"] else "past 80% of the"
            print(f"SEATS AT THE GOAL: the goal needs about {need_week:g} calls held a week, {more} "
                  f"{capacity['seats_a_week']:g} seats there are now; plan the hire or the price before you get there")
    if backward:
        print(f"to reach {money(goal)} a month" + (f" ({money(funnel_goal)} from this funnel, with {money(other)} from "
              "elsewhere)" if other else "") + ":")
        for k, v in backward.items():
            print(f"  {k}: {v['a_month']:,.0f} a month, {v['a_week']:,} a week, {v['a_day']:,} a day")
    print("wrote map.json and math.txt")


if __name__ == "__main__":
    main()
